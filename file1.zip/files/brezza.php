<?php
include("co.php");
{
	/*$uname=$_SESSION['username'];
	$upass=$_SESSION['password'];
	//$utype=$_SESSION['utype'];
	$sql="SELECT * FROM  `login_tb` WHERE username =  '$uname'AND PASSWORD =  '$upass'";
	$result=mysqli_query($sql,$con);
	$rowcount=mysqli_num_rows($result);
	if($rowcount !=0 && $utype=='user')
	{*/
$id=$_GET["id"];

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Compare</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
<!--===============================================================================================-->
	<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/sastest.js"></script>

<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.png"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/themify/themify-icons.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/slick/slick.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/lightbox2/css/lightbox.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->

</head>
<body  class="animsition"> <!-- -->
<div style="background-color: 	#DEB887">
	<!-- Header -->
	<header>
		<!-- Header desktop -->
		<div class="wrap-menu-header gradient1 trans-0-4">
			<div class="container h-full">
				<div class="wrap_header trans-0-3">
					<!-- Logo -->
					<div class="logo">
						<a href="uhome.php">
						<img src="images/icons/logo (4).PNG" style="border-radius: 30%">
						</a>
					</div>

					<!-- Menu -->
					<div class="wrap_menu p-l-45 p-l-0-xl">
						<nav class="menu">
							<ul class="main_menu">
								<li><a href="auto-club/home.php">Home</a></li>
									
									<li><a href="cmpr.php">compare</a></li>
									<li><a href="thumber/index.html">Gallery</a></li>
									<li><a href="auto-club/article.html">Services</a></li>
									<li><a href="submit1.html">Shop</a></li>
									<!--<li><a href="contacts.html">Contact</a></li>-->
									<li><a href="about.html">About</a></li>
									<li><a href="login.php">Login</a></li>
							</ul>
						</nav>
					</div>

					<!-- Social -->
					
				</div>
			</div>
		</div>
	</header>

	
		<div class="container">
			<h3 class="tit7 t-center p-b-62 p-t-105">
				Select Your Cars </h3>

	<!-- Booking -->
	<!--section class="section-booking bg1-pattern p-t-100 p-b-110"-->
		<div class="container">
			<div class="row">
				<div class="col-lg-12 p-b-30">
					<!--div class="t-center">
						<span class="tit2 t-center">

						</span>

						<br/>
						<br/>
						<br/>
						<br/>
					</div-->

					
						<div class="row">
							<div class="col-md-4">
									<div class="pic-blo3 size20 bo-rad-10 hov-img-zoom m-r-28">
									</div>
								<!-- name -->
								<br/>
								<div>

								<span class="txt9">
									<b>Select Company</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Select Model</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>	Select Varient</b>
								</span>
								</div>
								<br/>
								<br/>

								<!-- varient -->
								<div>
								<span class="txt9">
									<b>Type</b>
								</span>
								</div>
								<br/>
								<br/>

								<!-- fuel -->
								<div>
								<span class="txt9">
									<b>Fuel Type</b>
								</span>
								</div>
								<br/>
								<br/>

								<!-- cc -->
								<div>
								<span class="txt9">
									<b>Fuel Capacity</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>ARAI Milage</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Displacement</b>
								</span>
								</div>
								<br/>
								<br/>

								<!-- power -->
								<div>
								<span class="txt9">
									<b>Max Power</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Max Torque</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Transmission</b>
								</span>
								</div>
								<br/>
								<br/>
								<div>
								<span class="txt9">
									<b>Gearbox</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Seat</b>
								</span>
								</div>
								<br/>
								<br/>
								
								<div>
								<span class="txt9">
								<b>Ground clearance</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Wheelbase</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
								<b>Kerb Weight</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Boot Space</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Length</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Height</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Width</b>
								</span>
								</div>
								<br/>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Alloy Wheels</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>ABS</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>All Wheel Drive</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Touch Screen Navigation</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Sunroof</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Reverse Camera</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Daytime Running Light</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Cruise Control</b>
								</span>
								</div>
								<br/>
								<br/>

								<div>
								<span class="txt9">
									<b>Ex - Showroom Price (DEL)</b>
								</span>
								</div>
								<br/>
								<br/>
						</div>
							<div class="col-md-4">
							<form action="#" id="resultForm" class="wrap-form-booking" method="post" enctype="multipart/form-data">
							
									<div id="carimage1" draggable="true" style="margin-left: 90px; background-size: cover; " class="pic-blo3 size20 bo-rad-10 hov-img-zoom m-r-28">
									</div>
							<div class="wrap-inputname pos-relative txt10 size12 bo2 bo-rad-10 m-t-3 m-b-23">
							<select class="bo-rad-10 sizefull txt10 p-l-20" id="companydd" name="company"  placeholder="Select Company" onChange="change_company();change_model();" required>
							<option> -- Select Company -- </option>
							<?php 
							$res=mysqli_query($con,"Select * from company");
							while($row=mysqli_fetch_array($res))
							{
								?>
								<option value="<?php echo $row["compid"];?>"><?php echo $row["comp_name"]; ?></option>
								<?php
							}
						?>
               				</select>
								</div>
								<!--<?php /*?><?php
									$sel = mysql_query("select * from mreg_tb where status='approved' ORDER BY `cname` ASC",$con);
									while($row=mysql_fetch_array($sel)){
									?>

									<option value="<?php echo $row['username']; ?>">
										<?php echo $row['cname']; ?>
									</option>
								<?php } ?><?php */?>-->

							<div class="wrap-inputname pos-relative txt10 size12 bo2 bo-rad-10 m-t-3 m-b-23">
							<select class="bo-rad-10 sizefull txt10 p-l-20"  name="model" placeholder="Select Car" id="modeldd" onChange="change_model()" required>
							<option> -- Select Model -- </option>
								<?php /*?><?php
									$selcar = mysql_query("select * from car_tb",$con);
									while($row=mysql_fetch_array($selcar)){
									?>

									<option value="<?php echo $row['cname']; ?>">
										<?php echo $row['carname']; ?>
									</option>
								<?php } ?><?php */?>
									</select>
								</div>


							<div class="wrap-inputname pos-relative txt10 size12 bo2 bo-rad-10 m-t-3 m-b-23">
							<select class="bo-rad-10 sizefull txt10 p-l-20" id="varient" name="varient" placeholder="Select Varient" onChange="getResult()" required>
							<option> -- Select Varient -- </option>
								<?php /*?><?php
									$selcar = mysql_query("select * from car_tb",$con);
									while($row=mysql_fetch_array($selcar)){
									?>

									<option value="<?php echo $row['cid']; ?>">
										<?php echo $row['varient']; ?>
									</option>
								<?php } ?><?php */?>
									</select>
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="type" id="type">
								</div>

								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="fuel" id="fuel">
								</div>

								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="fuel_capacity" id="fuel_capacity">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="milagedisplacementmaxpower" id="milagedisplacementmaxpower">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="displacementmaxpower" id="displacementmaxpower">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="maxpower" id="maxpower">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="maxtorque" id="maxtorque">
								</div>
								
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="transmission" id="transmission">
								</div>

								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="seat" id="seat">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="ground" id="ground">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="wheelbase" id="wheelbase">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="kweight" id="weight">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="boot" id="boot">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="length" id="length">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="height" id="height">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="width" id="width">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="alloy" id="alloy">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="abs" id="abs">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="pw" id="drive">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="touch" id="touch">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="sunroof" id="sunroof">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="awd" id="camera">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="drls" id="drls">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="tube" id="cruise">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="tsn" id="tsn">
								</div>
								<div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
									<input disabled class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="price" id="price">
								</div>
					</div>
				</form>
								
					
				
				


			
	<!--/section-->

			  <div class="row p-t-135">
				<div class="col-sm-8 col-md-4 col-lg-4 m-l-r-auto p-t-30">
					<div class="dis-flex m-l-23">
						<div class="p-r-40 p-t-6">
							<img src="images/icons/map-icon.png" alt="IMG-ICON">
						</div>

						<div class="flex-col-l">
							<span class="txt5 p-b-10">
								Location
							</span>

							<span class="txt23 size38">
								AJCE Kanjirappally
							</span>
						</div>
					</div>
				</div>

				<div class="col-sm-8 col-md-3 col-lg-4 m-l-r-auto p-t-30">
					<div class="dis-flex m-l-23">
						<div class="p-r-40 p-t-6">
							<img src="images/icons/phone-icon.png" alt="IMG-ICON">
						</div>


						<div class="flex-col-l">
							<span class="txt5 p-b-10">
								Call Us
							</span>

							<span class="txt23 size38">
								(+91) 9495762466
							</span>
						</div>
					</div>
				</div>


			</div>
		</div>
	<!--/section-->



	<footer class="bg1">

		<div class="end-footer bg2">
			<div class="container">
				<div class="flex-sb-m flex-w p-t-22 p-b-22">
					<div class="p-t-5 p-b-5">
						<!--a href="#" class="fs-15 c-white"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
						<a href="#" class="fs-15 c-white"><i class="fa fa-facebook m-l-18" aria-hidden="true"></i></a>
						<a href="#" class="fs-15 c-white"><i class="fa fa-twitter m-l-18" aria-hidden="true"></i></a-->
					</div>

					<div class="txt17 p-r-20 p-t-5 p-b-5">
						Copyright &copy; 2019 All Rights Reserved <i class="fa fa-heart"></i>
					</div>
				</div>
			</div>
		</div>
	</footer>


	<!-- Back to top -->
	<div class="btn-back-to-top bg0-hov" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="fa fa-angle-double-up" aria-hidden="true"></i>
		</span>
	</div>

	<!-- Container Selection1 -->
	<div id="dropDownSelect1"></div>
</div>


<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/bootstrap/js/popper.js"></script>
	<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/daterangepicker/moment.min.js"></script>
	<script type="text/javascript" src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/slick/slick.min.js"></script>
	<script type="text/javascript" src="js/slick-custom.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/parallax100/parallax100.js"></script>
	<script type="text/javascript">
        $('.parallax100').parallax100();
	</script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/lightbox2/js/lightbox.min.js"></script>
<!--===============================================================================================-->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAKFWBqlKAGCeS1rMVoaNlwyayu0e0YRes"></script>
	<script src="js/map-custom.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

	<script type="text/javascript">

	</script>
</div>
</body>
</html>

<script type="text/javascript">
	function change_company()
	{	
		var xmlhttp=new XMLHttpRequest();
		var url="getcar.php?company="+document.getElementById("companydd").value;
		xmlhttp.open("GET",url,false);
		xmlhttp.send(null);
		document.getElementById("modeldd").innerHTML=xmlhttp.responseText;
	}

	function change_model()
	{
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.open("GET","getModel.php?model="+document.getElementById("modeldd").value,false);
		xmlhttp.send(null);
		document.getElementById("varient").innerHTML=xmlhttp.responseText;
	}
	function change_company1()
	{
		var xmlhttp=new XMLHttpRequest();
		var url="getcar.php?company="+document.getElementById("companydd1").value;
		xmlhttp.open("GET",url,false);
		xmlhttp.send(null);
		document.getElementById("modeldd1").innerHTML=xmlhttp.responseText;
	}

	function change_model1()
	{
		var xmlhttp=new XMLHttpRequest();
		xmlhttp.open("GET","getModel.php?model="+document.getElementById("modeldd1").value,false);
		xmlhttp.send(null);
		document.getElementById("varient1").innerHTML=xmlhttp.responseText;
	}

	function getResult()
	{
		var xmlhttp=new XMLHttpRequest();
		var query="getResult.php?company="+document.getElementById("companydd").value+"&model="+document.getElementById("modeldd").value+"&varient="+document.getElementById("varient").value;			
			xmlhttp.open("GET",query,false);
			xmlhttp.send(null);
			var dummy=JSON.parse(xmlhttp.responseText);
			var	result=dummy[0];  	
		    var form = document.getElementById("resultForm");
		    var formItems = form.getElementsByTagName("input");
		    for(x in formItems) {
		        if(formItems[x].type == "text") {
		                formItems[x].value = result[x];
		            }
		    }	            		        
		        
	}
	function getResult1()
	{
		var xmlhttp=new XMLHttpRequest();
		var query="getResult.php?company="+document.getElementById("companydd1").value+"&model="+document.getElementById("modeldd1").value+"&varient="+document.getElementById("varient1").value;			
			xmlhttp.open("GET",query,false);
			xmlhttp.send(null);
			var dummy=JSON.parse(xmlhttp.responseText);
			var	result=dummy[0];  	
		    var form = document.getElementById("resultForm1");
		    var formItems = form.getElementsByTagName("input");
		    for(x in formItems) {
		        if(formItems[x].type == "text") {
		                formItems[x].value = result[x];
		            }
		    }	            		        
		        
	}

</script>
<?php
	}
?>
