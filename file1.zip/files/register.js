jQuery.validator.addMethod("noSpace", function(value, element) {
    return value == '' || value.trim().length != 0;
}, "No space please and don't leave it empty");
jQuery.validator.addMethod("customEmail", function(value, element) {
  return this.optional( element ) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test( value );
}, "Please enter valid email address!");



jQuery.validator.addMethod("passstrength", function(value, element) {
    return this.optional(element) || /([0-9])/ && /([a-zA-Z])/ && /([~,!,@,#,$,%,^,&,*,-,_,+,=,?,>,<])/.test(value);});


jQuery.validator.addMethod("alphabetsnspace", function(value, element) {
    return this.optional(element) || /^[a-zA-Z ]*$/.test(value);},"Invalid!");


jQuery.validator.addMethod("phoneno", function(phone_number, element) {
          phone_number = phone_number.replace(/\s+/g, "");
          return this.optional(element) || phone_number.length > 9 && 
          phone_number.match(/^((\+[6-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[1-9]{3,4}?[ \-]*[0-9]{3,4}?$/);
      }, "<br />Please specify phone number");


$.validator.addMethod( "alphanumeric", function( value, element ) {
return this.optional( element ) || /^\w+$/i.test( value );
}, "Letters, and underscores only please" );

var $registrationForm = $('#register-form');
if($registrationForm.length){
  $registrationForm.validate({
      rules:{
          //username is the name of the textbox
          name: {
              required: true,
              //alphanumeric is the custom method, we defined in the above
              alphabetsnspace: true
          },
          state:{
              required: true

          },
          city:{
              required: true,
              alphabetsnspace: true
            },

          contact:{
              required:true,
              phoneno: true,
              number:true,
              maxlength:10,
              minlength:10
            },

          email: {
              required: true,
              customEmail: true
          },

          username: {
              required: true,
              noSpace: true,
              alphanumeric: true
          },

          password: {
              required: true,
              passstrength: true,
              minlength:8
          },
          confirm: {
              required: true,
              equalTo: '#password'
          },
          
      },
      messages:{
          name: {
              //error message for the required field
              required: 'Please enter the name!',
              alphabetsnspace: 'Name must be in character'
          },
          state:{
            required: 'Please enter the state!'
          },
          city:{
            required: 'Please enter the city!'
          },
          contact:{
            required: 'Enter contact number!',
            number: 'Invalid format!',
            minlength: 'Invalid!',
            maxlength: 'Invalid!'
          },
          email: {
              required: 'Please enter email!',
              //error message for the email field
              email: 'Please enter valid email!'
          },
          username: {
              //error message for the required field
              required: 'Please enter username!'
          },
          
          password: {
              required: 'Please enter password!',
              passstrength: 'Weak password!',
              minlength:'Too short!'
          },
          confirm: {
              required: 'Re-enter password!',
              passstrength: 'Weak password!',
              minlength:'Too short!',
              equalTo: 'Same password please!'
          },

      },

  });
}
