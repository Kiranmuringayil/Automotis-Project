function validate()
{ 

   if( document.contactform.textnames.value == "" )
   {
     alert( "Please provide your FirstName!" );
     document.contactform.textnames.focus() ;
     return false;
   }
    if( document.contactform.txtnames.value == "" )
   {
     alert( "Please provide your LastName!" );
     document.contactform.txtnames.focus() ;
     return false;
   }
   var email = document.contactform.email1.value;
  atpos = email.indexOf("@");
  dotpos = email.lastIndexOf(".");
 if (email == "" || atpos < 1 || ( dotpos - atpos < 2 )) 
 {
     alert("Please enter correct email ID")
     document.contactform.email1.focus() ;
     return false;
 }
 if( document.contactform.phone.value == "" ||
           isNaN( document.contactform.phone.value) ||
           document.contactform.phone.value.length != 10 )
   {
     alert( "Please provide a Mobile No in the format 123.upto 10 digit" );
     document.contactform.phone.focus() ;
     return false;
   }
   if( document.contactform.state.value == "-1" )
   {
     alert( "Please provide your Select State!" );
     document.contactform.state.focus() ;
     return false;
   }
   if( document.contactform.district.value == "-1" )
   {
     alert( "Please provide your Select District!" );
    
     return false;
   }   
    if( document.contactform.pin.value == "" ||
           isNaN( document.contactform.pin.value) ||
           document.contactform.pin.value.length != 6 )
   {
     alert( "Please provide a pincode in the format ######." );
     document.contactform.pin.focus() ;
     return false;
   }
   var password=document.contactform.pass.value; 
if(password=="")
{
alert("Please Enter Your Password");
document.contactform.pass.focus();
return false;
}
 if(password.length<6){  
  alert("Password must be at least 6 characters long.");  
  return false;  
  }  
var cpassword=document.contactform.cf.value; 
if(cpassword=="")
{
alert("Please Re-Enter Your Password");
document.contactform.cf.focus();
return false;
}
 
  
  if(password != cpassword)
  {
	  alert("password doesn't match");
	  document.contactform.pass.value='';
	  document.contactform.cf.value='';
	  document.contactform.pass.focus();
	  return false;
  }
return( true );

}