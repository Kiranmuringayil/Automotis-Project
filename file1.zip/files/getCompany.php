<?php
include("co.php");
$sel = mysqli_query($con,"select comp_name from company");
$company=array();
$compid=array();
	$len=0;
	if($sel){
		while($row=mysqli_fetch_array($sel)){
			$len++;
			$compid[$len]=$row['compid'];
			$company[$len]=$row['comp_name'];
		}
	}
if($len==0){
	echo "false";
}
else {
	$json="{ \"size\":\"".$len."\",\"ad\" : [";
	for($i=1;$i<=$len;$i++){

		if($i>=2)
			$json=$json.",";
		$json=$json."{
						\"carid\":\"".$cid[$i]."\",
						\"carname\":\"".$carname[$i]."\"
						}" ;
	}
	$json=$json.']}';



	echo $json;
}
?>
