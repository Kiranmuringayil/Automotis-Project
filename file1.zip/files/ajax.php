<?php
include('co.php');
$company=$_GET["company"];
$model=$_GET["model"];

if ($company!="")
 {

	   $res=mysqli_query($con,"select model from car_models where compid='$company'");
	   echo "$res";
	  echo "<select id='modeldd' onchange='change_model()'>";
	  echo "<option>"; echo "Select"; echo "</option>";
	  while ($row=mysqli_fetch_array($res))
	  {
	  	echo "<option value='$row[id]' selected>"; echo $row ["model"]; echo "</option>";
	  }
	  echo "</select>";
}

if ($model!="")
 {

	   $res=mysqli_query($con,"select varient from car_models where carid=compid");
	  echo "<select> ";
	  echo "<option>"; echo "Select"; echo "</option>";
	  while ($row=mysqli_fetch_array($res))
	  {
	  	echo "<option value='$row[id]' selected>"; echo $row ["varient"]; echo "</option>";
	  }
	  echo "</select>";
}

?>
