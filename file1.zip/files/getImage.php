<?php
include("co.php");
$model=$_GET['model'];
$sel = mysqli_query($con,"select varient from car_models where model='$model'");
$model=array();
	$len=0;
	?>
	<option> -- Select Varient -- </option>
<?php
	if($sel){
		while($row=mysqli_fetch_array($sel)){
			$len++;			
		?>
		<option value=<?php echo $row['varient'];?>><?php echo $row['varient']?></option><?php
		}
	}
if($len==0){
	?>
	<option>No Varients Found</option><?php
}	
?>
	