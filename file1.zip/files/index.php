<!DOCTYPE html>
<html lang="en">
<head>
	<title>Home</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="icon" type="image/png" href="images/icons/favicon.png"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/themify/themify-icons.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/slick/slick.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/lightbox2/css/lightbox.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body class="animsition">

	<!-- Header -->
	<header>
		<!-- Header desktop -->
		<div class="wrap-menu-header gradient1 trans-0-4">
			<div class="container h-full">
				<div class="wrap_header trans-0-3">
					<!-- Logo -->
					<div class="logo">
						<a href="index.php">
							<img src="images/icons/logo (4).png" style="border-radius: 30%" alt="IMG-LOGO" data-logofixed="images/icons/logo (4).png">
						</a>
					</div>

					<!-- Menu -->
					<!--<div class="wrap_menu p-l-45 p-l-0-xl">-->
						<nav class="menu">
							<ul class="main_menu">
								<li>
									<a href="index.php">Home</a>
								</li>

								<li>
									<a href="new-car.php">Cars</a>
								</li>
								

								<li>
									<a href="login.php">Compare</a>
								</li>

								<li>
									<a href="login.php">Used cars</a>
								</li>

								<li>
									<a href="thumber/index.html">Gallery</a>
								</li>

								<li>
									<a href="carlisting/page/about-us.php">About</a>
								</li>
								
								<li>
									<a href="login.php">Login</a>
								</li>
							</ul>
						</nav>
					</div>

				</div>
			</div>
		</div>
	</header>

	
	<!-- Slide1 -->
	<section class="section-slide">
		<div class="wrap-slick1">
			<div class="slick1">
				<div class="item-slick1 item1-slick1" style="background-image: url(pics/benz.jpg);">
					<div class="wrap-content-slide1 sizefull flex-col-c-m p-l-15 p-r-15 p-t-150 p-b-170">
						<span class="caption1-slide1 txt1 t-center animated visible-false m-b-15" data-appear="fadeInDown">
							Welcome to Automotis
						</span>

						<h2 class="caption2-slide1 tit1 t-center animated visible-false m-b-30" data-appear="fadeInUp">
							Find Your Dream
						</h2>

						<div class="wrap-btn-slide1 animated visible-false" data-appear="zoomIn">
							<!-- Button1 -->
							
						</div>
					</div>
				</div>

				<div class="item-slick1 item2-slick1" style="background-image: url(pics/car3.jpg);">
					<div class="wrap-content-slide1 sizefull flex-col-c-m p-l-15 p-r-15 p-t-150 p-b-170">
						<span class="caption1-slide1 txt1 t-center animated visible-false m-b-15" data-appear="rollIn">
							Welcome to Automotis
						</span>

						<h3 class="caption2-slide1 tit1 t-center animated visible-false m-b-30" data-appear="lightSpeedIn">
							Find Your Dream
						</h3>

						<div class="wrap-btn-slide1 animated visible-false" data-appear="slideInUp">
							<!-- Button1 -->
							
						</div>
					</div>
				</div>

				<div class="item-slick1 item3-slick1" style="background-image: url(pics/bgimg1.jpg);">
					<div class="wrap-content-slide1 sizefull flex-col-c-m p-l-15 p-r-15 p-t-150 p-b-170">
						<span class="caption1-slide1 txt1 t-center animated visible-false m-b-15" data-appear="rotateInDownLeft">
							Welcome to Automotis
						</span>

						<h2 class="caption2-slide1 tit1 t-center animated visible-false m-b-30" data-appear="rotateInUpRight">
							Find Your Dream
						</h2>

						<div class="wrap-btn-slide1 animated visible-false" data-appear="rotateIn">
							<!-- Button1 -->
							
						</div>
					</div>
				</div>

			</div>

			<div class="wrap-slick1-dots"></div>
		</div>
	</section>

	<!-- Welcome -->
	<section class="section-welcome bg1-pattern p-t-120 p-b-105">
		<div class="container">
			<div class="row">
				
				<div class="col-md-4 p-t-30">
						<!-- Block1 -->
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/vehicle.php?brand=Maruti Suzuki"><img src="logo/maruti.png" alt="IMG-INTRO"></a>
							</div>
						</div>
					</div>

					<div class="col-md-4 p-t-30">
						<!-- Block1 -->
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/vehicle.php?brand=Hyundai"><img src="logo/hynd.png" alt="IMG-INTRO"></a>
							</div>

						
						</div>
					</div>

                    <div class="col-md-4 p-t-30">
						<!-- Block1 -->
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/vehicle.php?brand=Honda"><img src="logo/honda (1).jpg" alt="IMG-INTRO"></a>
							</div>

							
						</div>
					</div>
					<div class="col-md-4 p-t-30">
						<!-- Block1 -->
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/vehicle.php?brand=Toyota"><img src="logo/toyot.jpg" alt="IMG-INTRO"></a>
							</div>

							
						</div>
					</div>
					<div class="col-md-4 p-t-30">
						<!-- Block1 -->
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/vehicle.php?brand=Kia"><img src="logo/kia.jpg" alt="IMG-INTRO"></a>
							</div>
						</div>
					</div>
					<div class="col-md-4 p-t-30">
						<!-- Block1 -->
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/vehicle.php?brand=	
							    Mahindra"><img src="logo/images.png" alt="IMG-INTRO"></a>
							</div>
						</div>
					</div>
					<div class="col-md-4 p-t-30">
						<!-- Block1 -->
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/vehicle.php?brand=Tata Motors"><img src="logo/tata.png" alt="IMG-INTRO"></a>
							</div>

							
						</div>
					</div>
					<div class="col-md-4 p-t-30">
						<!-- Block1 -->
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/vehicle.php?brand=MG"><img src="logo/mg (1).jpg" alt="IMG-INTRO"></a>
							</div>

							
						</div>
					</div>
					<div class="col-md-4 p-t-30">
						<!-- Block1 -->
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/vehicle.php?brand=Ford"><img src="logo/ford.jfif" alt="IMG-INTRO"></a>
							</div>

							
						</div>
					</div>


				

				
			</div>
		</div>
	</section>

	<!-- Intro --> <section class="section-intro"> <div class="header-intro
	parallax100 t-center p-t-135 p-b-158" style="background-image:
	url(pics/camaro.jpg);"> <span class="tit2 p-l-15 p-r-15"> Discover </span>

			<h3 class="tit4 t-center p-l-15 p-r-15 p-t-3">
				Your Cars
			</h3>
		</div>
		<!-- Welcome -->
	<section class="section-welcome bg1-pattern p-t-120 p-b-105">
		<div class="container">
			<div class="row">
				<div class="col-md-6 p-t-45 p-b-30">
					<div class="wrap-text-welcome t-center">
						<span class="tit2 t-center">
							Automotis "Find your Dream Car"
						</span>

						<h3 class="tit3 t-center m-b-35 m-t-5">
							About us
						</h3>

						<p class="t-center m-b-22 size3 m-l-r-auto">
							Automotis is a complete auto mart.
						</p>

						<a href="carlisting/page/about-us.php" class="txt4">
							Our Story
							<i class="fa fa-long-arrow-right m-l-10" aria-hidden="true"></i>
						</a>
					</div>
				</div>

				<div class="col-md-6 p-b-30">
					<div class="wrap-pic-welcome size2 bo-rad-10 hov-img-zoom m-l-r-auto">
						<img src="pics/audi2.jpg" alt="IMG-OUR">
					</div>
				</div>
			</div>
		</div>
	</section>

		<!--<div class="content-intro bg-white p-t-77 p-b-133">
			<div class="container">
				<div class="row">
					<div class="col-md-4 p-t-30">
						
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/category.php?category=SUV"><img src="pics/ford.jpeg" alt="IMG-INTRO"></a>
							</div>

							<div class="wrap-text-blo1 p-t-35">
								<a href="carlisting/page/category.php?category=SUV"><h4 class="txt5 color0-hov trans-0-4 m-b-13">
									SUV
								</h4></a>

								<p class="m-b-20">
									
								</p>

								
							</div>
						</div>
					</div>

					<div class="col-md-4 p-t-30">
						
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/category.php?category=MUV"><img src="pics/Innova.jpg" alt="IMG-INTRO"></a>
							</div>

							<div class="wrap-text-blo1 p-t-35">
								<a href="carlisting/page/category.php?category=MUV"><h4 class="txt5 color0-hov trans-0-4 m-b-13">
									MUV
								</h4></a>

								<p class="m-b-20">
									
								</p>

								
							</div>
						</div>
					</div>


						<div class="col-md-4 p-t-30">
						
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/category.php?category=Sedan"><img src="pics/Ciaz.jpg" alt="IMG-INTRO"></a>
							</div>

							<div class="wrap-text-blo1 p-t-35">
								<a href="carlisting/page/category.php?category=Sedan"><h4 class="txt5 color0-hov trans-0-4 m-b-13">
									SEDAN
								</h4></a>

								<p class="m-b-20">
									
								</p>

								
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</section-->


	


	
	<!-- Footer -->
	<footer class="bg1">
		<div class="container p-t-40 p-b-70">
			<div class="row">
				<div class="col-sm-6 col-md-4 p-t-50">
					<!-- - -->
					<h4 class="txt13 m-b-33">
						Contact Us
					</h4>

					<ul class="m-b-70">
						

						<li class="txt14 m-b-14">
							<i class="fa fa-phone fs-16 dis-inline-block size19" aria-hidden="true"></i>
							automotis-compare.com
						</li>

						<li class="txt14 m-b-14">
							<i class="fa fa-envelope fs-13 dis-inline-block size19" aria-hidden="true"></i>
							(+91) 9495762466
						</li>

					</ul>

					<!-- - -->

				</div>

				
				<div class="col-sm-6 col-md-4 p-t-50">
					<!-- - -->
					<h4 class="txt13 m-b-38">
						Gallery
					</h4>

					<!-- Gallery footer -->
					<div class="wrap-gallery-footer flex-w">
						<a class="item-gallery-footer wrap-pic-w" href="pics/Harrier.jpg" data-lightbox="gallery-footer">
							<img src="pics/Harrier.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/fortuner.jpg" data-lightbox="gallery-footer">
							<img src="pics/fortuner.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Alturas.jpg" data-lightbox="gallery-footer">
							<img src="pics/Alturas.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/pajero-sport.JPG" data-lightbox="gallery-footer">
							<img src="pics/pajero-sport.JPG" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Hector.jpg" data-lightbox="gallery-footer">
							<img src="pics/Hector.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/XL6.jpg" data-lightbox="gallery-footer">
							<img src="pics/XL6.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/kia.jpg" data-lightbox="gallery-footer">
							<img src="pics/kia.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Ciaz.jpg" data-lightbox="gallery-footer">
							<img src="pics/Ciaz.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/ford-endeavour-1.jpg" data-lightbox="gallery-footer">
							<img src="pics/ford-endeavour-1.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/nios.jpg" data-lightbox="gallery-footer">
							<img src="pics/nios.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/p10.jpg" data-lightbox="gallery-footer">
							<img src="pics/p10.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Duster.jpg" data-lightbox="gallery-footer">
							<img src="pics/Duster.jpg" alt="GALLERY">
						</a>
					</div>

				</div>
			</div>
		</div>

		<div class="end-footer bg2">
			<div class="container">
				<div class="flex-sb-m flex-w p-t-22 p-b-22">
					<div class="p-t-5 p-b-5">
						<!--a href="#" class="fs-15 c-white"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
						<a href="#" class="fs-15 c-white"><i class="fa fa-facebook m-l-18" aria-hidden="true"></i></a>
						<a href="#" class="fs-15 c-white"><i class="fa fa-twitter m-l-18" aria-hidden="true"></i></a-->
					</div>

					<div class="txt17 p-r-20 p-t-5 p-b-5">
						Copyright &copy; 2020 All Rights Reserved<i class="fa fa-heart"></i>
					</div>
				</div>
			</div>
		</div>
	</footer>


	<!-- Back to top -->
	<div class="btn-back-to-top bg0-hov" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="fa fa-angle-double-up" aria-hidden="true"></i>
		</span>
	</div>

	<!-- Container Selection1 -->
	<div id="dropDownSelect1"></div>

	<!-- Modal Video 01-->
	<div class="modal fade" id="modal-video-01" tabindex="-1" role="dialog" aria-hidden="true">

		<div class="modal-dialog" role="document" data-dismiss="modal">
			<div class="close-mo-video-01 trans-0-4" data-dismiss="modal" aria-label="Close">&times;</div>

			<div class="wrap-video-mo-01">
				<div class="w-full wrap-pic-w op-0-0"><img src="pics/marazzo.jpg" alt="IMG"></div>
				<div class="video-mo-01">
					<iframe src="https://www.youtube.com/watch?v=S4aw2_8ToRA" allowfullscreen></iframe>
				</div>
			</div>
		</div>
	</div>



<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/bootstrap/js/popper.js"></script>
	<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/daterangepicker/moment.min.js"></script>
	<script type="text/javascript" src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/slick/slick.min.js"></script>
	<script type="text/javascript" src="js/slick-custom.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/parallax100/parallax100.js"></script>
	<script type="text/javascript">
        $('.parallax100').parallax100();
	</script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/lightbox2/js/lightbox.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>
<!--http://localhost/car%20comp/carlisting/page/new-car.html