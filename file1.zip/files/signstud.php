<?php
session_start();

// initializing variables
$name = "";
$state    = "";
$city = "";
$contno = "";
$emailid = "";
$username = "";
$password = "";
$errors = array(); 

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'automotis');
if($db)
  {
    echo '<script language="javascript">';
    echo 'alert("connected to db")';
    echo '</script>';
  }
  else
  {
    echo '<script language="javascript">';
    echo 'alert("error")';
    echo '</script>';
  }
  	


// REGISTER USER
if (isset($_POST['submit']))
{
  // receive all input values from the form
  $name = mysqli_real_escape_string($db, $_POST['name']);
  $state = mysqli_real_escape_string($db, $_POST['state']);
  $city = mysqli_real_escape_string($db, $_POST['city']);
  $contno = mysqli_real_escape_string($db, $_POST['contact']);
  $emailid = mysqli_real_escape_string($db, $_POST['email']);
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $password = mysqli_real_escape_string($db, $_POST['password']);
echo $name,$state,$city,$contno,$emailid,$username,$password;
   
  // Finally, register user if there are no errors in the form
  if (count($errors) == 0) 
  {
  	$pass = md5($password);//encrypt the password before saving in the database
   $query="INSERT INTO `register_tb`(`userid`, `name`, `state`, `city`, `contno`, `emailid`, `username`, `password`, `status`) VALUES (NULL,'$name','$state','$city','$contno','$emailid','$username','$pass',0)";
  $res=	mysqli_query($db, $query);
  if($res)
  {
    echo '<script language="javascript">';
    echo 'alert("Success inserted")';
    echo '</script>';
    // $_SESSION['username'] = $username;
  	// $_SESSION['success'] = "You are now logged in";
  	// header('location: index.php');
  }
  else
  { 
     
    echo '<script language="javascript">';
    echo 'alert("error not inserted")';
    echo '</script>';
  }
  
  }
  else
  {
    echo '<script language="javascript">';
    echo 'alert("there are errors")';
    echo '</script>';
  }

}
else
{
  echo '<script language="javascript">';
    echo 'alert("post error")';
    echo '</script>';
}
?>