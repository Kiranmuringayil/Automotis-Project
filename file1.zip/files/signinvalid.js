function valid()
{ 


   
 	if(document.getElementById('username').value=="")
		 {
		 	alert("Enter a username");
		 	document.signin.u_id.focus() ;
		 	return false;
		 }
     alert("Please enter correct username")
     
     return false;
 }

var password=document.signin.u_pass.value; 
if(password=="")
{
alert("Please Enter Your Password");
document.signin.pass.focus();
return false;
}
 if(password.length<8){  
  alert("Password must be at least 8 characters long.");  
  return false;  
  }  

return( true );

}