<?php
  include 'dbconnect.php';
  if(isset($_POST['submit']))
  {

    $em=$_POST['email'];
    


 

    $sq2="select username from login where username='$em'";
    $result=mysqli_query($con,$sq2);
    
if($result)
{
    
if($result->num_rows > 0)
{


    $result="";
    $t=time();
    $timestamp = strtotime($t) + 60*60*2; 
    $time = date('H:i', $timestamp);

    $link="http://localhost/project/forget_get.php?email=".$em;
$maild='milkystore90@gmail.com';
require 'phpmailer/PHPMailerAutoload.php'; 
$mail = new PHPMailer(true);

$mail->isSMTP();// Set mailer to use SMTP
$mail->CharSet = "utf-8";// set charset to utf8
$mail->SMTPAuth = true;// Enable SMTP authentication
$mail->SMTPSecure = 'tls';// Enable TLS encryption, `ssl` also accepted

$mail->Host = 'smtp.gmail.com';// Specify main and backup SMTP servers
$mail->Port = 587;// TCP port to connect to
$mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
        );
$mail->isHTML(true);// Set email format to HTML
$mail->Username='milkystore90@gmail.com';//send cheyyunna mail id
$mail->Password='Milky@1990';//ayinte password

$mail->setFrom($maild);
$mail->addAddress($em);//receiverinte mail
$mail->addReplyTo($maild);//thirich reply theranam engil a mail

$mail->isHTML(true);//html code mail ayakkan true akki iduka
$mail->Subject='Reset Your Password';//mail subject
$mail->Body="<h1>Hai User</h1><br><a href=".$link.">Click This Link To Reset Your Password</a>";//body



$mail->send();
if(!$mail->send())
{
$result="Something went wrong";
echo $result;

}
else
{
    /*$result="Mail went successfully";  
    echo $result;*/
    echo " <script>
    alert('Please Check Your Mail, Reset your Password Using that link');
    window.location='home.php'
    </script> ";
}
}
else{
    
    echo " <script>
    alert('Please Check Your Entered Email and Re-enter a Valid E-mail');
    window.location='forgot_sent.php'
    
    </script> ";

}
}
 

  }
  ?>