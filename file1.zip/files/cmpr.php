

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Compare cars</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">


<!--===============================================================================================-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
<!--===============================================================================================-->
	<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/sastest.js"></script>
<!--===============================================================================================-->

	<link rel="icon" type="image/png" href="images/icons/favicon.png"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/themify/themify-icons.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/slick/slick.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/lightbox2/css/lightbox.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body class="animsition">

<header>
		<!-- Header desktop -->
		<div class="wrap-menu-header gradient1 trans-0-4">
			<div class="container h-full">
				<div class="wrap_header trans-0-3">
					<!-- Logo -->
					<div class="logo">
						<a href="index.php">
							<img src="images/icons/logo (4).png" style="border-radius: 30%" alt="IMG-LOGO" data-logofixed="images/icons/logo (4).png">
						</a>
					</div>

					<!-- Menu -->
					<!--<div class="wrap_menu p-l-45 p-l-0-xl">-->
						<nav class="menu">
							<ul class="main_menu">
								<li>
									<a href="index.php">Home</a>
								</li>

								<li>
									<a href="new-car.php">CARS</a>
								</li>

								<li>
									<a href="cmpr.php">COMPARE</a>
								</li>
								
								<li>
									<a href="cmpr.php">Used cars</a>
								</li>

								<li>
									<a href="thumber/index.html">Gallery</a>
								</li>

								<li>
									<a href="carlisting/page/about-us.php">About</a>
								</li>
								
								<li>
									<a href="login.php">Login</a>
								</li>
							</ul>
						</nav>
					</div>

				</div>
			</div>
		</div>
	</header>


	
	<div style="background-color: #B4B4A4">

<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<div>
<div >
				<center><h3 style="font-family: TimesNewRoman;">Sorry you need to signup for this service</h3></center>
<br/>
<br/>
<br/>

				<center><h5 style="font-family: TimesNewRoman;"><a href="http://localhost/car%20comp/register/ureg.php">Click here to signup</a></h5></center>
	<br/>
	<br/>
	<br/>
	<br/>
	<br/>
	<br/>
	<br/>
</div>
</div>
</div>






		


	<!-- Back to top -->
	<div class="btn-back-to-top bg0-hov" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="fa fa-angle-double-up" aria-hidden="true"></i>
		</span>
	</div>

	<!-- Container Selection1 -->
	<div id="dropDownSelect1"></div>

	<!-- Modal Video 01-->
	<div class="modal fade" id="modal-video-01" tabindex="-1" role="dialog" aria-hidden="true">

		<div class="modal-dialog" role="document" data-dismiss="modal">
			<div class="close-mo-video-01 trans-0-4" data-dismiss="modal" aria-label="Close">&times;</div>

			<div class="wrap-video-mo-01">
				<div class="w-full wrap-pic-w op-0-0"><img src="pics/marazzo.jpg" alt="IMG"></div>
				<div class="video-mo-01">
					<iframe src="https://www.youtube.com/watch?v=S4aw2_8ToRA" allowfullscreen></iframe>
				</div>
			</div>
		</div>
	</div>

<!-- Footer -->
	<footer class="bg1">
		<div class="container p-t-40 p-b-70">
			<div class="row">
				<div class="col-sm-6 col-md-4 p-t-50">
					<!-- - -->
					<h4 class="txt13 m-b-33">
						Contact Us
					</h4>

					<ul class="m-b-70">
						

						<li class="txt14 m-b-14">
							<i class="fa fa-phone fs-16 dis-inline-block size19" aria-hidden="true"></i>
							(+91) 9495762466
						</li>

						<li class="txt14 m-b-14">
							<i class="fa fa-envelope fs-13 dis-inline-block size19" aria-hidden="true"></i>
							automotis compare.com
						</li>
					</ul>

					<!-- - -->

				</div>

				
				<div class="col-sm-6 col-md-4 p-t-50">
					<!-- - -->
					<h4 class="txt13 m-b-38">
						Gallery
					</h4>

					<!-- Gallery footer -->
					<div class="wrap-gallery-footer flex-w">
						<a class="item-gallery-footer wrap-pic-w" href="pics/Harrier.jpg" data-lightbox="gallery-footer">
							<img src="pics/Harrier.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/fortuner.jpg" data-lightbox="gallery-footer">
							<img src="pics/fortuner.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Alturas.jpg" data-lightbox="gallery-footer">
							<img src="pics/Alturas.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/pajero-sport.JPG" data-lightbox="gallery-footer">
							<img src="pics/pajero-sport.JPG" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Hector.jpg" data-lightbox="gallery-footer">
							<img src="pics/Hector.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/XL6.jpg" data-lightbox="gallery-footer">
							<img src="pics/XL6.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/kia.jpg" data-lightbox="gallery-footer">
							<img src="pics/kia.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Ciaz.jpg" data-lightbox="gallery-footer">
							<img src="pics/Ciaz.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/ford-endeavour-1.jpg" data-lightbox="gallery-footer">
							<img src="pics/ford-endeavour-1.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/nios.jpg" data-lightbox="gallery-footer">
							<img src="pics/nios.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/p10.jpg" data-lightbox="gallery-footer">
							<img src="pics/p10.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Duster.jpg" data-lightbox="gallery-footer">
							<img src="pics/Duster.jpg" alt="GALLERY">
						</a>
					</div>

				</div>
			</div>
		</div>

		<div class="end-footer bg2">
			<div class="container">
				<div class="flex-sb-m flex-w p-t-22 p-b-22">
					<div class="p-t-5 p-b-5">
						<!--a href="#" class="fs-15 c-white"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
						<a href="#" class="fs-15 c-white"><i class="fa fa-facebook m-l-18" aria-hidden="true"></i></a>
						<a href="#" class="fs-15 c-white"><i class="fa fa-twitter m-l-18" aria-hidden="true"></i></a-->
					</div>

					<div class="txt17 p-r-20 p-t-5 p-b-5">
						Copyright &copy; 2019 Kiran Thomas<i class="fa fa-heart"></i>
					</div>
				</div>
			</div>
		</div>
	</footer>


<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/bootstrap/js/popper.js"></script>
	<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/daterangepicker/moment.min.js"></script>
	<script type="text/javascript" src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/slick/slick.min.js"></script>
	<script type="text/javascript" src="js/slick-custom.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/parallax100/parallax100.js"></script>
	<script type="text/javascript">
        $('.parallax100').parallax100();
	</script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/lightbox2/js/lightbox.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>
