<?php
include("co.php");
$username=$_GET['username'];
$password=md5($_GET['password']);
$sel = mysqli_query($con,"update register_tb set password='$password' where username='$username';");
$sel1 = mysqli_query($con,"update login_tb set password='$password' where username='$username';");
?>
	