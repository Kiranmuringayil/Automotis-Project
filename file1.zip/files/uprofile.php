<?php
session_start();
if(isset($_SESSION['username']))
			{
				//echo "<script>alert('welcome $_SESSION[username]')</script>";
include("co.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 <style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
	<title>Profile</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">


<!--===============================================================================================-->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
<!--===============================================================================================-->
	<script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/sastest.js"></script>
<!--===============================================================================================-->

	<link rel="icon" type="image/png" href="images/icons/favicon.png"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/themify/themify-icons.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/slick/slick.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/lightbox2/css/lightbox.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body class="animsition">
	<div style="background-color: #BDB76B">

	<!-- Header -->
	<header>
		<!-- Header desktop -->
		<div class="wrap-menu-header gradient1 trans-0-4">
			<div class="container h-full">
				<div class="wrap_header trans-0-3">
					<!-- Logo -->
					<div class="logo">
						<a href="uhome.php">
							<img src="images/icons/logo (4).png" style="border-radius: 30%" alt="IMG-LOGO" data-logofixed="images/icons/logo (4).png">
						</a>
					</div>

					<!-- Menu -->
					<div class="wrap_menu p-l-45 p-l-0-xl">
						<nav class="menu">
							<ul class="main_menu">
								<li>
									<a href="uhome.php">Home</a>
								</li>								

								<li>
									<a href="ucompare.php">Compare </a>
								</li>

								<li>
									<a href="carlisting/page/usedcar.php">USED CARS</a>
								</li>

								<li>
									<a href="carlisting/page/bill.php">My Bookings</a>
								</li>

								<li>
									<a href="feedback.php">FeedBack</a>
								</li>
								
								
								<form action="carlisting/car/search.php?se=<?php echo $row['carid'];?>">
                            <input type="text" placeholder="Search.." name="search">
                            <button type="submit"><i class="fa fa-search" name="submit"></i></button>
                            </form>
							</ul>
						</nav>
					</div>

					<!-- Social -->
					<div class="social flex-w flex-l-m p-r-20">
						<!--a href="#"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
						<a href="#"><i class="fa fa-facebook m-l-21" aria-hidden="true"></i></a>
						<a href="#"><i class="fa fa-twitter m-l-21" aria-hidden="true"></i></a-->

						<button class="btn-show-sidebar m-l-20 trans-0-4"></button>
					</div>
				</div>
			</div>
		</div>
	</header>

	<!-- Sidebar -->
	<aside class="sidebar trans-0-4">
		<!-- Button Hide sidebar -->
		<button class="btn-hide-sidebar ti-close color0-hov trans-0-4"></button>

		<!-- - -->
		<ul class="menu-sidebar p-t-95 p-b-70">
			<li class="t-center m-b-13">
				<a href="uhome.php" class="txt19">Home</a>
			</li>
			

			<li class="t-center">
				<!-- Button3 -->
				<a href="logout.php" class="btn3 flex-c-m size13 txt11 trans-0-4 m-l-r-auto">
					Logout
				</a>
			</li>
		</ul>

		<!-- - -->
		<div class="gallery-sidebar t-center p-l-60 p-r-60 p-b-40">
			<!-- - -->
			<h4 class="txt20 m-b-33">
						Gallery
					</h4>

			<!-- Gallery -->
			<div class="wrap-gallery-footer flex-w">
						<a class="item-gallery-footer wrap-pic-w" href="pics/Harrier.jpg" data-lightbox="gallery-footer">
							<img src="pics/Harrier.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/fortuner.jpg" data-lightbox="gallery-footer">
							<img src="pics/fortuner.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Alturas.jpg" data-lightbox="gallery-footer">
							<img src="pics/Alturas.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/pajero-sport.JPG" data-lightbox="gallery-footer">
							<img src="pics/pajero-sport.JPG" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Hector.jpg" data-lightbox="gallery-footer">
							<img src="pics/Hector.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/XL6.jpg" data-lightbox="gallery-footer">
							<img src="pics/XL6.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/kia.jpg" data-lightbox="gallery-footer">
							<img src="pics/kia.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Ciaz.jpg" data-lightbox="gallery-footer">
							<img src="pics/Ciaz.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/ford-endeavour-1.jpg" data-lightbox="gallery-footer">
							<img src="pics/ford-endeavour-1.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/nios.jpg" data-lightbox="gallery-footer">
							<img src="pics/nios.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/p10.jpg" data-lightbox="gallery-footer">
							<img src="pics/p10.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Duster.jpg" data-lightbox="gallery-footer">
							<img src="pics/Duster.jpg" alt="GALLERY">
						</a>
					</div>
		</div>
	</aside>

	
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<div>
<div >
  <div class="container">
    <div class="row">
      <div class="col-lg-12 p-b-30">

  <form class="wrap-form-booking" method="post" enctype="multipart/form-data">

    <div class="row">
      <div class="col-md-4">

<?php

$sel=mysqli_query($con,"select * from register_tb,state where register_tb.stateid=state.stateid and register_tb.username='$_SESSION[username]'");
    if($sel->num_rows>0) {
    	while ($row=$sel->fetch_assoc()) {
/*$prof=mysqli_query($con,"SELECT * from register_tb WHERE username='$_SESSION(username)'");
$row=mysqli_fetch_array($prof);
$name=$row['name'];
$state=$row['stateid'];
$city=$row['city'];
$contact=$row['contno'];
$email=$row['emailid'];
$username=$row['username'];
$password=$row['password'];*/

?>


  <span class="txt9">
    Name
  </span>
  <div class="wrap-inputvarient size12 bo2 bo-rad-10 m-t-3 m-b-23">

    <input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="name" id="name" value="<?php echo $row['name'];?>" disabled>
  </div>
  <!-- fuel -->
  <span class="txt9">
    State
  </span>

  <div class="wrap-inputphone size12 bo2 bo-rad-10 m-t-3 m-b-23">
    <input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="state" id="state" value="<?php echo $row['state']; ?>" disabled>
  </div>

  <!-- cc -->
  <span class="txt9">
    City
  </span>
  <div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
    <input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="city" id="city" value="<?php echo $row['city']; ?>" disabled>
  </div>

<div class="row">
  <span class="txt9">
    Contact
  </span>
</div>

  <div class="wrap-inputemail size12 bo2 bo-rad-10 m-t-3 m-b-23">
    <input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="contact" id="contact" value="<?php echo $row['contno']; ?>" disabled>
  </div>
  <span class="txt9">
    Email
  </span>

  <div class="wrap-inputemail size12 bo2 bo-rad-10 m-t-3 m-b-23">
    <input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="email" id="email" value="<?php echo $row['emailid']; ?>" disabled>
  </div>
</div>
  <div class="col-md-4">
  <!-- power -->
  <span class="txt9">
    Username
  </span>

  <div class="wrap-inputemail size12 bo2 bo-rad-10 m-t-3 m-b-23">
    <input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="username" id="username" value="<?php echo $row['username']; ?>" disabled>
  </div>

  <span class="txt9">
     Change Password
  </span>

  <div class="wrap-inputemail size12 bo2 bo-rad-10 m-t-3 m-b-23">
    <input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="password" id="password">
  </div>

  <span class="txt9">
    Confirm Password
  </span>

  <div class="wrap-inputemail size12 bo2 bo-rad-10 m-t-3 m-b-23">
    <input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="cpassword" id="cpassword">
  </div>
  <div class="wrap-btn flex-c-m m-t-6">
    <!-- Button3 -->
    <button type="button" name="submit" class="btn3 flex-c-m size13 txt11 trans-0-4" onclick="changePass()">
      Update Password
    </button>
  </div>
  <span class="txt9" id="alertBox">    
  </span>
</div>
</div>
</div>

</body>
</html>



  <!--span class="txt9">
    password
  </span>

  <div class="wrap-inputemail size12 bo2 bo-rad-10 m-t-3 m-b-23">
    <input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="password" id="password" value="<?php echo $row['password']; ?>" disabled>
  </div-->
  <?php
}
?>
  <!--div class="wrap-btn flex-c-m m-t-6">
   
    <button type="submit" name="submit" class="btn3 flex-c-m size13 txt11 trans-0-4">
      Update Details
    </button>
  </div-->


</form>
</div>
</div>
</div>



</div>
</div>
</div>

	<!-- Footer -->
	<footer class="bg1">
		<div class="container p-t-40 p-b-70">
			<div class="row">
				<div class="col-sm-6 col-md-4 p-t-50">
					<!-- - -->
					<h4 class="txt13 m-b-33">
						Contact Us
					</h4>

					<ul class="m-b-70">
						

						<li class="txt14 m-b-14">
							<i class="fa fa-phone fs-16 dis-inline-block size19" aria-hidden="true"></i>
							Automotis-compare.com
							
						</li>

						<li class="txt14 m-b-14">
							<i class="fa fa-envelope fs-13 dis-inline-block size19" aria-hidden="true"></i>
							(+91) 9495762466
						</li>
					</ul>

					<!-- - -->

				</div>

				
				<div class="col-sm-6 col-md-4 p-t-50">
					<!-- - -->
					<h4 class="txt13 m-b-38">
						Gallery
					</h4>

					<!-- Gallery footer -->
					<div class="wrap-gallery-footer flex-w">
						<a class="item-gallery-footer wrap-pic-w" href="pics/Harrier.jpg" data-lightbox="gallery-footer">
							<img src="pics/Harrier.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/fortuner.jpg" data-lightbox="gallery-footer">
							<img src="pics/fortuner.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Alturas.jpg" data-lightbox="gallery-footer">
							<img src="pics/Alturas.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/pajero-sport.JPG" data-lightbox="gallery-footer">
							<img src="pics/pajero-sport.JPG" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Hector.jpg" data-lightbox="gallery-footer">
							<img src="pics/Hector.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/XL6.jpg" data-lightbox="gallery-footer">
							<img src="pics/XL6.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/kia.jpg" data-lightbox="gallery-footer">
							<img src="pics/kia.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Ciaz.jpg" data-lightbox="gallery-footer">
							<img src="pics/Ciaz.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/i30.jpg" data-lightbox="gallery-footer">
							<img src="pics/i30.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/nios.jpg" data-lightbox="gallery-footer">
							<img src="pics/nios.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/honda-accord.jpg" data-lightbox="gallery-footer">
							<img src="pics/honda-accord.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Duster.jpg" data-lightbox="gallery-footer">
							<img src="pics/Duster.jpg" alt="GALLERY">
						</a>
					</div>

				</div>
			</div>
		</div>

		<div class="end-footer bg2">
			<div class="container">
				<div class="flex-sb-m flex-w p-t-22 p-b-22">
					<div class="p-t-5 p-b-5">
						<!--a href="#" class="fs-15 c-white"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
						<a href="#" class="fs-15 c-white"><i class="fa fa-facebook m-l-18" aria-hidden="true"></i></a>
						<a href="#" class="fs-15 c-white"><i class="fa fa-twitter m-l-18" aria-hidden="true"></i></a-->
					</div>

					<div class="txt17 p-r-20 p-t-5 p-b-5">
						Copyright &copy; 2019 <i class="fa fa-heart"></i>
					</div>
				</div>
			</div>
		</div>
	</footer>


	<!-- Back to top -->
	<div class="btn-back-to-top bg0-hov" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="fa fa-angle-double-up" aria-hidden="true"></i>
		</span>
	</div>

	<!-- Container Selection1 -->
	<div id="dropDownSelect1"></div>

	<!-- Modal Video 01-->
	<div class="modal fade" id="modal-video-01" tabindex="-1" role="dialog" aria-hidden="true">

		<div class="modal-dialog" role="document" data-dismiss="modal">
			<div class="close-mo-video-01 trans-0-4" data-dismiss="modal" aria-label="Close">&times;</div>

			<div class="wrap-video-mo-01">
				<div class="w-full wrap-pic-w op-0-0"><img src="pics/marazzo.jpg" alt="IMG"></div>
				<div class="video-mo-01">
					<iframe src="https://www.youtube.com/watch?v=S4aw2_8ToRA" allowfullscreen></iframe>
				</div>
			</div>
		</div>
	</div>



<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/bootstrap/js/popper.js"></script>
	<script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/daterangepicker/moment.min.js"></script>
	<script type="text/javascript" src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/slick/slick.min.js"></script>
	<script type="text/javascript" src="js/slick-custom.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/parallax100/parallax100.js"></script>
	<script type="text/javascript">
        $('.parallax100').parallax100();
	</script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/lightbox2/js/lightbox.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>
<?php
	}
}
	else
	{
		header("location:err.php");
	}
?>
<script>
	function changePass(){
		var password=document.getElementById("password").value;
		var cpassword=document.getElementById("cpassword").value;
		if(password==cpassword)
		{
			var xmlhttp=new XMLHttpRequest();
			var url="changePass.php?password="+document.getElementById("password").value+"&username="+document.getElementById("username").value;
			xmlhttp.open("GET",url,false);
			xmlhttp.send(null);
			document.getElementById("alertBox").innerHTML="Password Successfully Changed!!";
			setTimeout(function(){document.getElementById("alertBox").innerHTML="";},2000);	
		}
		else
		{
			document.getElementById("alertBox").innerHTML="Passwords Don't Match!!";
			setTimeout(function(){document.getElementById("alertBox").innerHTML="";},2000);
		}
		
		
	}
</script>
