<!DOCTYPE html>
<html lang="en">
<head>
	<title>Home</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

<body class="animsition">
<div class="wrap-gallery-footer flex-w">
						<a class="item-gallery-footer wrap-pic-w" href="pics/Harrier.jpg" data-lightbox="gallery-footer">
							<img src="pics/Harrier.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/fortuner.jpg" data-lightbox="gallery-footer">
							<img src="pics/fortuner.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Alturas.jpg" data-lightbox="gallery-footer">
							<img src="pics/Alturas.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/pajero-sport.JPG" data-lightbox="gallery-footer">
							<img src="pics/pajero-sport.JPG" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Hector.jpg" data-lightbox="gallery-footer">
							<img src="pics/Hector.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/XL6.jpg" data-lightbox="gallery-footer">
							<img src="pics/XL6.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/kia.jpg" data-lightbox="gallery-footer">
							<img src="pics/kia.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Ciaz.jpg" data-lightbox="gallery-footer">
							<img src="pics/Ciaz.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/i30.jpg" data-lightbox="gallery-footer">
							<img src="pics/i30.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/nios.jpg" data-lightbox="gallery-footer">
							<img src="pics/nios.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/honda-accord.jpg" data-lightbox="gallery-footer">
							<img src="pics/honda-accord.jpg" alt="GALLERY">
						</a>

						<a class="item-gallery-footer wrap-pic-w" href="pics/Duster.jpg" data-lightbox="gallery-footer">
							<img src="pics/Duster.jpg" alt="GALLERY">
						</a>
					</div>


</body>
</html>
