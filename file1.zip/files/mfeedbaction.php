<?php
session_start();
include("co.php");
	$uname=$_SESSION['username'];
	$upass=$_SESSION['password'];
	//$utype=$_SESSION['utype'];
	$sql="SELECT * FROM login_tb WHERE username =  '$uname'AND PASSWORD =  '$upass'";
	$result=mysqli_query($sql,$con);
	$rowcount=mysqli_num_rows($result);
				if(isset($_POST['submit']))
		{
		$user =mysqli_query($con,"select name from register_tb where username = '$uname'");
		$row = mysqli_fetch_array($user);
		$name=$row['name'];
		$feedback = $_POST['feedback'];
			$sql=mysqli_query($con,"INSERT INTO feedback_tb VALUES('$uname','$feedback')");


		header("location:mfeedback.php?succ=success");
		}
	}
