function validateform()
{
var x=document.forms["myform"]["name"].value;
if(x=="")
{
alert("Please fill name");
return false;
}
if( document.myform.phone.value == "" ||
           isNaN( document.myform.phone.value) ||
           document.myform.phone.value.length != 10 )

   {
     alert( "Please provide a 10 digit mobile no" );
     document.myform.phone.focus() ;
     return false;
   }
   if((document.myform.phone.value.charAt(0)!=9) && 
    (document.myform.phone.value.charAt(0)!=8) && 
    (document.myform.phone.value.charAt(0)!=7))
   {
     alert( "Please provide a valid 10 digit mobile no. start with '9' or '8' or'7'" );
     document.myform.phone.focus() ;
     return false;
   }
   
var b=document.forms["myform"]["city"].value;
if(b=="")
{
alert("Please enter a city");
return false;
}

if(myform.uname.value == "") {
      alert("Error: Username cannot be blank!");
      myform.uname.focus();
      return false;
    }
    

    if(myform.uname.value.length < 6) {
        alert("Error: username must contain at least six characters!");
        myform.uname.focus();
        return false;
      }
      
   
   

    if(myform.pass.value != "" && myform.pass.value == myform.pass.value) {
      if(myform.pass.value.length < 6) {
        alert("Error: Password must contain at least eight characters!");
        myform.pass.focus();
        return false;
      }
      
      re = /[0-9]/;
      if(!re.test(myform.pass.value)) {
        alert("Error: password must contain at least one number (0-9)!");
        myform.pass.focus();
        return false;
      }
      re = /[a-z]/;
      if(!re.test(myform.pass.value)) {
        alert("Error: password must contain at least one lowercase letter (a-z)!");
        myform.pass.focus();
        return false;
      }
      re = /[A-Z]/;
      if(!re.test(myform.pass.value)) {
        alert("Error: password must contain at least one uppercase letter (A-Z)!");
        myform.pass.focus();
        return false;
      }
    } else {
      alert("Error: Please check that you've entered and confirmed your password!");
      myform.pass.focus();
      return false;
    }

    return true;
 }