<?php
include('co.php');
if(isset($_POST['submit']))
{
$user=$_POST['username'];
$pass=$_POST['pass'];
$confirm=$_POST['confirm'];

if($pass!=$confirm)
{
  header("location:forgot2.php?eror=passwords are not matching");
}

$npass=md5($_POST['pass']);
$cpass=md5($_POST['confirm']);

$re=mysqli_query($con,"select username from login_tb where username='$user'");
if(mysqli_num_rows($re)>0)
                    {
                        
                        if ($npass==$cpass)
                        { 


$upq2=mysql_query("update register_tb set password='$npass' where username='$user'",$con);
$upq1=mysql_query("update login_tb set password='$npass' where username='$user'",$con);
}
}
}
//header("location: login.php?error=Password Changed Successfully");
?>
        