<?php
session_start();
if(isset($_SESSION['username']))
            {
                //echo "<script>alert('welcome $_SESSION[username]')</script>";
include("co.php");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box;}

body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #e9e9e9;
}

.topnav a {
  float: left;
  display: block;
  color: black;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #2196F3;
  color: white;
}

.topnav .search-container {
  float: right;
}

.topnav input[type=text] {
  padding: 6px;
  margin-top: 8px;
  font-size: 17px;
  border: none;
}

.topnav .search-container button {
  float: right;
  padding: 6px 10px;
  margin-top: 8px;
  margin-right: 16px;
  background: #ddd;
  font-size: 17px;
  border: none;
  cursor: pointer;
}

.topnav .search-container button:hover {
  background: #ccc;
}

@media screen and (max-width: 600px) {
  .topnav .search-container {
    float: none;
  }
  .topnav a, .topnav input[type=text], .topnav .search-container button {
    float: none;
    display: block;
    text-align: left;
    width: 100%;
    margin: 0;
    padding: 14px;
  }
  .topnav input[type=text] {
    border: 1px solid #ccc;  
  }
}
</style>
    <title>Profile</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">


<!--===============================================================================================-->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet">
<!--===============================================================================================-->
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/sastest.js"></script>
<!--===============================================================================================-->

    <link rel="icon" type="image/png" href="images/icons/favicon.png"/>
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="fonts/themify/themify-icons.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/slick/slick.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="vendor/lightbox2/css/lightbox.min.css">
<!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body class="animsition">
    <div style="background-color: #B4B4A4">

    <!-- Header -->
    <header>
        <!-- Header desktop -->
        <div class="wrap-menu-header gradient1 trans-0-4">
            <div class="container h-full">
                <div class="wrap_header trans-0-3">
                    <!-- Logo -->
                    <div class="logo">
                        <a href="uhome.php">
                            <img src="images/icons/logo (4).png" style="border-radius: 30%" alt="IMG-LOGO" data-logofixed="images/icons/logo (4).png">
                        </a>
                    </div>

                    <!-- Menu -->
                    <div class="wrap_menu p-l-45 p-l-0-xl">
                        <nav class="menu">
                            <ul class="main_menu">
                                <li>
                                    <a href="uhome.php">Home</a>
                                </li>                               

                                <li>
                                    <a href="ucompare.php">Compare</a>
                                </li>

                                <li>
                                    <a href="carlisting/page/usedcar.php">USED CARS</a>
                                </li>

                                <li>
                                    <a href="uprofile.php">Profile</a>
                                </li>
                                <form action="carlisting/car/search.php?se=<?php echo $row['carid'];?>">
                            <input type="text" placeholder="Search.." name="search">
                            <button type="submit"><i class="fa fa-search"></i></button>
                            </form>

                                
                            </ul>
                        </nav>
                    </div>
<!-- Social -->
                    <div class="social flex-w flex-l-m p-r-20">
                        <!--a href="#"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-facebook m-l-21" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-twitter m-l-21" aria-hidden="true"></i></a-->

                        <button class="btn-show-sidebar m-l-20 trans-0-4"></button>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Sidebar -->
    <aside class="sidebar trans-0-4">
        <!-- Button Hide sidebar -->
        <button class="btn-hide-sidebar ti-close color0-hov trans-0-4"></button>

        <!-- - -->
        <ul class="menu-sidebar p-t-95 p-b-70">
            <li class="t-center m-b-13">
                <a href="uhome.php" class="txt19">Home</a>
            </li>
            

            <li class="t-center">
                <!-- Button3 -->
                <a href="logout.php" class="btn3 flex-c-m size13 txt11 trans-0-4 m-l-r-auto">
                    Logout
                </a>
            </li>
        </ul>

        <!-- - -->
        <div class="gallery-sidebar t-center p-l-60 p-r-60 p-b-40">
            <!-- - -->
            <h4 class="txt20 m-b-33">
                        Gallery
                    </h4>

            <!-- Gallery -->
            <div class="wrap-gallery-footer flex-w">
                        <a class="item-gallery-footer wrap-pic-w" href="pics/Harrier.jpg" data-lightbox="gallery-footer">
                            <img src="pics/Harrier.jpg" alt="GALLERY">
                        </a>

                        <a class="item-gallery-footer wrap-pic-w" href="pics/fortuner.jpg" data-lightbox="gallery-footer">
                            <img src="pics/fortuner.jpg" alt="GALLERY">
                        </a>

                        <a class="item-gallery-footer wrap-pic-w" href="pics/Alturas.jpg" data-lightbox="gallery-footer">
                            <img src="pics/Alturas.jpg" alt="GALLERY">
                        </a>

                        <a class="item-gallery-footer wrap-pic-w" href="pics/pajero-sport.JPG" data-lightbox="gallery-footer">
                            <img src="pics/pajero-sport.JPG" alt="GALLERY">
                        </a>

                        <a class="item-gallery-footer wrap-pic-w" href="pics/Hector.jpg" data-lightbox="gallery-footer">
                            <img src="pics/Hector.jpg" alt="GALLERY">
                        </a>

                        <a class="item-gallery-footer wrap-pic-w" href="pics/XL6.jpg" data-lightbox="gallery-footer">
                            <img src="pics/XL6.jpg" alt="GALLERY">
                        </a>

                        <a class="item-gallery-footer wrap-pic-w" href="pics/kia.jpg" data-lightbox="gallery-footer">
                            <img src="pics/kia.jpg" alt="GALLERY">
                        </a>

                        <a class="item-gallery-footer wrap-pic-w" href="pics/Ciaz.jpg" data-lightbox="gallery-footer">
                            <img src="pics/Ciaz.jpg" alt="GALLERY">
                        </a>

                        <a class="item-gallery-footer wrap-pic-w" href="pics/ford-endeavour-1.jpg" data-lightbox="gallery-footer">
                            <img src="pics/ford-endeavour-1.jpg" alt="GALLERY">
                        </a>

                        <a class="item-gallery-footer wrap-pic-w" href="pics/nios.jpg" data-lightbox="gallery-footer">
                            <img src="pics/nios.jpg" alt="GALLERY">
                        </a>

                        <a class="item-gallery-footer wrap-pic-w" href="pics/p10.jpg" data-lightbox="gallery-footer">
                            <img src="pics/p10.jpg" alt="GALLERY">
                        </a>

                        <a class="item-gallery-footer wrap-pic-w" href="pics/Duster.jpg" data-lightbox="gallery-footer">
                            <img src="pics/Duster.jpg" alt="GALLERY">
                        </a>
                    </div>
        </div>
    </aside>

    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
<br/>


    <body >
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <form role="form" method="post" id="reused_form" >
                        <div class="form-group">
                            <label class="tit7 t-center p-b-30 p-t-105">Feedback</label>
                            <textarea class="form-control" type="textarea" name="feed" id="feedback" placeholder=" Enter Your Feedback Here"rows="10"></textarea>
                        </div>
                        <button type="submit" name="submit" class="btn3 flex-c-m size13 txt11 trans-0-4">
      Submit Feedback </button>
    <?php
    if (isset($_POST['submit'])) {
        # code...
        $feedback=$_POST['feed'];
        $date=date('Y-m-d');
        $id=$_SESSION['username'];
        //echo $id;
        $sel = mysqli_query($con,"insert into feedback_tb(loginid,feedback,date) values('$id','$feedback','$date')");
if($sel)
{
    echo "Your Feedback Registerd Successfully";
    //header("location:uhome.php");
}
    }
    ?>
				    
                    <div >
                   
                </div>
            </div>
        </div>
      <!-- Footer -->
   <!--/section-->

              <div class="row p-t-135">
                <div class="col-sm-8 col-md-4 col-lg-4 m-l-r-auto p-t-30">
                    <div class="dis-flex m-l-23">
                        <div class="p-r-40 p-t-6">
                            <img src="images/icons/map-icon.png" alt="IMG-ICON">
                        </div>

                        <div class="flex-col-l">
                            <span class="txt5 p-b-10">
                                Location
                            </span>

                            <span class="txt23 size38">
                                AJCE Kanjirappally
                            </span>
                        </div>
                    </div>
                </div>

                <div class="col-sm-8 col-md-3 col-lg-4 m-l-r-auto p-t-30">
                    <div class="dis-flex m-l-23">
                        <div class="p-r-40 p-t-6">
                            <img src="images/icons/phone-icon.png" alt="IMG-ICON">
                        </div>


                        <div class="flex-col-l">
                            <span class="txt5 p-b-10">
                                Call Us
                            </span>

                            <span class="txt23 size38">
                                (+91) 9495762466
                            </span>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    <!--/section-->



    <footer class="bg1">

        <div class="end-footer bg2">
            <div class="container">
                <div class="flex-sb-m flex-w p-t-22 p-b-22">
                    <div class="p-t-5 p-b-5">
                        <!--a href="#" class="fs-15 c-white"><i class="fa fa-tripadvisor" aria-hidden="true"></i></a>
                        <a href="#" class="fs-15 c-white"><i class="fa fa-facebook m-l-18" aria-hidden="true"></i></a>
                        <a href="#" class="fs-15 c-white"><i class="fa fa-twitter m-l-18" aria-hidden="true"></i></a-->
                    </div>

                    <div class="txt17 p-r-20 p-t-5 p-b-5">
                        Copyright &copy; 2019 All Rights Reserved <i class="fa fa-heart"></i>
                    </div>
                </div>
            </div>
        </div>
    </footer>


    <!-- Back to top -->
    <div class="btn-back-to-top bg0-hov" id="myBtn">
        <span class="symbol-btn-back-to-top">
            <i class="fa fa-angle-double-up" aria-hidden="true"></i>
        </span>
    </div>

    <!-- Container Selection1 -->
    <div id="dropDownSelect1"></div>
</div>


<!--===============================================================================================-->
    <script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
    <script type="text/javascript" src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
    <script type="text/javascript" src="vendor/bootstrap/js/popper.js"></script>
    <script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
    <script type="text/javascript" src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
    <script type="text/javascript" src="vendor/daterangepicker/moment.min.js"></script>
    <script type="text/javascript" src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
    <script type="text/javascript" src="vendor/slick/slick.min.js"></script>
    <script type="text/javascript" src="js/slick-custom.js"></script>
<!--===============================================================================================-->
    <script type="text/javascript" src="vendor/parallax100/parallax100.js"></script>
    <script type="text/javascript">
        $('.parallax100').parallax100();
    </script>
<!--===============================================================================================-->
    <script type="text/javascript" src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
    <script type="text/javascript" src="vendor/lightbox2/js/lightbox.min.js"></script>
<!--===============================================================================================-->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAKFWBqlKAGCeS1rMVoaNlwyayu0e0YRes"></script>
    <script src="js/map-custom.js"></script>
<!--===============================================================================================-->
    <script src="js/main.js"></script>

    <script type="text/javascript">

    </script>
    
</div>
</body>
</html>
<?php
    
}
    else
    {
        header("location:err.php");
    }
?>