<?php
include("co.php");
$feedback=$_GET['feedback'];
$loginid=$_GET['loginid'];
$date=$_GET['date'];
$sel = mysqli_query($con,"insert into feedback_tb values(feedback_id,$loginid,'$feedback',$date);");
if($sel)
{
	echo 1;
}
else
{
	echo 2;
}
?>
	