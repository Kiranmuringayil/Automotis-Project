<?php
session_start();
if (isset($_SESSION['loginid'])){
 $db = mysqli_connect('localhost', 'root', '', 'water');
?>
 <!DOCTYPE html>
<html>
<head>
<title>New Feedbacks</title>
  
    
	<style>
	th {
    background-color: rgb(112, 196, 105);
    color: white;
    font-weight: normal;
    padding: 20px 30px;
    text-align: center;
  }
  td {
    background-color: rgb(238, 238, 238);
    color: rgb(111, 111, 111);
    padding: 20px 30px;
  }
</style>
</head>
<body>
 
 <h1 align="center">WATER AUTHORITY MANAGEMENT SYSTEM</h1><br>
<table border="2" cellpadding="12" width="100%" class="table table-striped" >
    <tr >
	<th>First Name</th>
	<th>Last Name</th>
	<th>Gender</th>
    <th>Address</th>
	<th>phone number</th>
	<th>Emailid</th>
	<th>Feedback</th>
    <th>Date</th>
	<th>Action</th>
	
    
  </tr>
  <?php
  
  

$sel="SELECT a.log_id,a.f_name,a.l_name,a.gender,a.address,a.phone,a.email,b.feedback,b.date from userregs a JOIN feedback b ON a.log_id=b.log_id  and b.status=0 ";;
$res=mysqli_query($db,$sel);
while($row=mysqli_fetch_array($res,MYSQLI_ASSOC))
{
	
	$lid=$row['log_id'] ;
	
	$sq=mysqli_query($db,"select email from login where log_id='$lid' ");
	$r=mysqli_fetch_array($sq,MYSQLI_ASSOC);
	$em=$r['email'];

?>
<tr>
<td> 
   <?php 
        echo $row['f_name'];
    ?>
  </td>
  <td> 
   <?php 
        echo $row['l_name'];
    ?>
  </td>
<td>
<?php
echo $row['gender'];
?>
</td>
<td>
<?php
echo $row['address'];
?>
</td>
<td>
<?php
echo $row['phone'];
?>
</td>
<td>
<?php
echo $row['email'];
?>
</td>
<td>
<?php
echo $row['feedback'];
?>
</td>
<td>
<?php
echo $row['date'];
?>
</td>

<td>
<a href="?id=<?php echo $lid; ?>">Reply</a>
</td>
</tr>
<?php
}
?>
</body>
</html>
<?php
}
else
{
echo "<script>window.location.href='home-login/index.html'</script>";
}
?>
 