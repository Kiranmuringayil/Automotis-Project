<!DOCTYPE html>
<html lang="en">
<head>
	<!--<script type="text/javascript" src="valid1.js"></script>-->
	<title>Signup</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
<script type="text/javascript">
	
</script>
</head>
<body class="animsition"> <!-- -->
	

		<div class="container">
			<h3 class="tit7 t-center p-b-62 p-t-105">
				SIGNUP
			</h3> 

			<form  action="usereg.php" method="post" id="register-form" class="wrap-form-reservation size22 m-l-r-auto" autocomplete="off">

				<center>
					<div class="row">
						<div class="col-md-5 text-right pt-3"><b>Name</b></div>
						<div class="col-md-4" style="display: inline-blo">
						<div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
						<input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="name" placeholder="Name" id="name" required>
						</div>
						</div>
					</div>
					<br/>

					<!--    ......     -->

					<div class="row">
						<div class="col-md-5 text-right pt-3"><b>State</b></div>
						<div class="col-md-4" style="display: inline-block">
						<div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
						<input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="state" placeholder="State" id="state" required>
						</div>
						</div>
					</div>
					<br/>
					<!--    ......     -->

					<div class="row">
						<div class="col-md-5 text-right pt-3"><b>City</b></div>
						<div class="col-md-4" style="display: inline-block">
						<div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
						<input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="city" placeholder="City" id="city" required>
						</div>
						</div>
					</div>
					<br/>
					<!--    ......     -->

					<div class="row">
						<div class="col-md-5 text-right pt-3"><b>Contact number</b></div>
						<div class="col-md-4" style="display: inline-block" style>
						<div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
						<input class="bo-rad-10 sizefull txt10 p-l-20" type="number" name="contact" placeholder="Contact Number" id="contact" pattern="[6-9]{1}[0-9]{9}" required title="enter a valid mobile number">
						</div>
						</div>
					</div>
					<br/>
					<!--    ......     -->

					<div class="row">
						<div class="col-md-5 text-right pt-3"><b>E-mail id</b></div>
						<div class="col-md-4" style="display: inline-block">
						<div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
						<input class="bo-rad-10 sizefull txt10 p-l-20" type="email" name="email" placeholder="Email" id="email" required>
						</div>
						</div>
					</div>
					<br/>
					<!--    ......     -->

					<div class="row">
						<div class="col-md-5 text-right pt-3"><b>Username</b></div>
						<div class="col-md-4" style="display: inline-block">
						<div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
						<input class="bo-rad-10 sizefull txt10 p-l-20" type="username" name="username" placeholder="Username" id="username" required>
						</div>
						</div>
					</div>
					<br/>
					<!--    ......     -->

					<div class="row">
						<div class="col-md-5 text-right pt-3"><b>Password</b></div>
						<div class="col-md-4" style="display: inline-block">
						<div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
						<input class="bo-rad-10 sizefull txt10 p-l-20" type="password" name="password" placeholder="Password" id="password"  pattern=".{8,}"required title="minimum 8 characters in password">
						</div>
						</div>
					</div>
					<br/>
					<!--    ......     -->

					<div class="row">
						<div class="col-md-5 text-right pt-3"><b>Confirm Password</b></div>
						<div class="col-md-4" style="display: inline-block">
						<div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
						<input class="bo-rad-10 sizefull txt10 p-l-20" type="password" name="confirm" placeholder="Confirm Password" id="confirm" required>
						</div>
						</div>
					</div>
					<!--    ......     -->

					<div class="wrap-btn-booking flex-c-m m-t-13">
					<input type="submit" name="submit" class="btn3 flex-c-m size36 txt11 trans-0-4">
					<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="../register.js"></script>

				</div>
				<br/>
				<br/>


				</center>
			</form>

			
 


<!--===============================================================================================-->
	<!--<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/animsition/js/animsition.min.js"></script>

<!--===============================================================================================-->
	<script src="js/main.js"></script>

	

	<!--<script type="text/javascript">
	$("#name").on("blur", function(e)
	{
		e.preventDefault();

		
	if(document.getElementById('name').value=="")
		{
			alert("Enter your name");
			return false;
		}

		$(this).unbind().submit();
	});


	$("#state").on("blur", function(e)
	{
		e.preventDefault();

	if(document.getElementById('state').value=="")
		{
			alert("Enter the state");
			return false;
		}
		$(this).unbind().submit();
	});

	$("#city").on("blur", function(e)
	{
		e.preventDefault();

	if(document.getElementById('city').value=="")
		{
			alert("Enter the city");
			return false;
		}
		$(this).unbind().submit();
	});

	$("#contact").on("blur", function(e)
	{
		e.preventDefault();

		if ((document.getElementById('contact').value.length<10) || (document.getElementById('contact').value.length>12))
		 	{
		 		alert("Enter a valid contact number");
		 		return false;
		 	}
		 	$(this).unbind().submit();
	});

	$("#email").on("blur", function(e)
	{
		e.preventDefault();

		if(document.getElementById('email').value=="")
		 	{
		 		alert("Enter your email id");
		 		return false;
		 	}
		 	$(this).unbind().submit();
	});
	$("#username").on("blur", function(e)
	{
		e.preventDefault();

		if(document.getElementById('username').value=="")
		 {
		 	alert("Enter a username");
		 	return false;
		 }
		 $(this).unbind().submit();
	});

	$("#password").on("blur", function(e)
	{
		e.preventDefault();

		if(document.getElementById('password').value=="")
		 {
		 	alert("Enter a password");
		 	return false;
		 }
		 $(this).unbind().submit();
	});

	$("#confirm").on("blur", function(e)
	{
		e.preventDefault();

		if(document.getElementById('confirm').value=="")
		 {
		 	alert("Please confirm your password");
		 	return false;
		 }
		 $(this).unbind().submit();
	});

	$("#confirm").on("blur", function(e)
	{
		e.preventDefault();

		if(document.getElementById('password').value != document.getElementById('confirm').value)
		 {
		 	alert("Passwords are not matching");
		 	return false;
		 }
		 $(this).unbind().submit();
	});



	</script>-->

</body>
</html>
