<?php
session_start();
include('co.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript" src="signinvalid.js"></script>
	<title>Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>


<body class="animsition">

	<header>
		<!-- Header desktop -->
		<div class="wrap-menu-header gradient1 trans-0-4">
			<div class="container h-full">
				<div class="wrap_header trans-0-3">
					<!-- Logo -->
					<div class="logo">
						<a href="index.php">
							<img src="images/icons/logo (4).png" style="border-radius: 30%" alt="IMG-LOGO" data-logofixed="images/icons/logo (4).png">
						</a>
					</div>

					<!-- Menu -->
					<!--<div class="wrap_menu p-l-45 p-l-0-xl">-->
						<nav class="menu">
							<ul class="main_menu">
								<li>
									<a href="index.php">Home</a>
								</li>

								<li>
									<a href="new-car.php">Cars</a>
								</li>

								<li>
									<a href="carlisting/page/usedcar.php">Used cars</a>
								</li>

								<li>
									<a href="cmpr.php">Compare</a>
								</li>

								<li>
									<a href="thumber/index.html">Gallery</a>
								</li>

								<li>
									<a href="carlisting/page/about-us.php">About</a>
								</li>
								
								<li>
									<a href="login.php">Login</a>
								</li>
							</ul>
						</nav>
					</div>

				</div>
			</div>
		</div>
	</header>

	
	<section class="bg-title-page flex-c-m p-t-160 p-b-80 p-l-15 p-r-15" style="background-image: url(pics/bmw1.jpg);">


		<div class="container">
			<!--h3 class="tit7 t-center p-b-62 p-t-10">
				Login to Wheelei
			</h3-->
<h2 class="tit6 t-center">
			Login
			<br/>
		</h2>

			<form action="signin.php" name="signin" method="post" onsubmit="return valid()" class="wrap-form-reservation size22 m-l-r-auto" autocomplete="off">

				<center>
					<div class="col-md-4">


						<div class="wrap-inputname size12 bo2 bo-rad-10 m-t-3 m-b-23">
							<input class="bo-rad-10 sizefull txt10 p-l-20" type="text" name="u_id" onsubmit="return valid()" placeholder="Username" required>
						</div>
					</div>


					<div class="col-md-4">
						<div class="wrap-inputemail size12 bo2 bo-rad-10 m-t-3 m-b-23">
							<input class="bo-rad-10 sizefull txt10 p-l-20" type="password" name="u_pass" placeholder="Password" required>

						</div>
					</div>



				<div class="wrap-btn-booking flex-c-m m-t-13">

					<button type="submit" name="submit" value="login" class="btn3 flex-c-m size36 txt11 trans-0-4">
						<b>LOGIN</b>
					</button>
				</div>
				

				<?php
				if(isset($_POST['submit']))
				{
					$u_id=$_POST['u_id'];
					$u_pass=$_POST['u_pass'];
					$sel=mysqli_query($con,"select * from login_tb where username='$u_id' and password='$u_pass'");
					if($sel->num_rows>0)
					{
						while ($row=$sel->fetch_assoc())
						{
							$_SESSION["Admin_user"]=$row['username'];
							if(isset($_SESSION["Admin_user"]))
							{
								echo "<script>alert('Welcome $row[name]')</script>";
							}
						}
					}
				}
				?>
			<!--div>
				<a href="forgot.php">Forgot password</a>
		</div>
											<div style="color: red; font-size:18px"><?php

								if(isset($_GET['error']))
								{
									echo($_GET['error']);
								}
							?>
							</div-->
				<br/>




				<div>
					<a href="http://localhost/car%20comp/register/ureg.php"  style="font-family: Times New Roman; color: aliceblue"><h4>Not a user Click here to register</h4></a>
				</div>
				</center>
			</form>

			<div class="row p-t-135">
				<div class="col-sm-8 col-md-4 col-lg-4 m-l-r-auto p-t-30">
					<div class="dis-flex m-l-23">
						<div class="p-r-40 p-t-6">
							<img src="images/icons/map-icon.png" alt="IMG-ICON">
						</div>

						
					</div>
				</div>

				<div class="col-sm-8 col-md-3 col-lg-4 m-l-r-auto p-t-30">
					<div class="dis-flex m-l-23">
						<div class="p-r-40 p-t-6">
							<img src="images/icons/phone-icon.png" alt="IMG-ICON">
						</div>


						<div class="flex-col-l">
							<span class="txt5 p-b-10">
								Call Us
							</span>

							<span class="txt23 size38">
								(+91) 9495762466
							</span>
						</div>
					</div>
				</div>


			</div>
		</div>
	</section>




<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="vendor/animsition/js/animsition.min.js"></script>

<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>
