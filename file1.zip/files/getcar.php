<?php
include("co.php");
$company=$_GET['company'];
$sel = mysqli_query($con,"select model from car_models where compid='$company'");
$model=array();
	$len=0;
	?>
	<option> -- Select Model -- </option>
<?php	if($sel){
		while($row=mysqli_fetch_array($sel)){
			$len++;			
		?>
		<option value=<?php echo $row['model'];?>><?php echo $row['model']?></option><?php
		}
	}
if($len==0){
	?>
	<option>No Models Found</option><?php
}	
?>
	