<?php 
include 'co.php'; 
if(isset($_POST['submit']))
{
  $a=$_POST['name'];
  $b=$_POST['state'];
  $c=$_POST['city'];
  $d=$_POST['contact'];
  $e=$_POST['email'];
  $g=$_POST['username'];
  $h=$_POST['password'];
  //$pass=md5($h);
   //echo "<script>alert('$g');</script>";
$sq="insert into login_tb(username,password)values('$g','$h')";
if(mysqli_query($con,$sq))
{
  $s=mysqli_query($con,"select loginid from login_tb where username='$g'");
  $r=mysqli_fetch_array($s,MYSQLI_ASSOC);
  $lid=$r['loginid'];
  //echo "<script>alert('$lid');</script>";
$sql="insert into register_tb(loginid,name,state,city,contno,emailid,username,password,status)values('$lid','$a','$b','$c','$d','$e','$g','$h',0)";
 $ch=mysqli_query($con,$sql);
if($ch)
{?>
   <script>
 alert("Registration Successfull");
 window.location='../login.php';
</script>
  <?php
}
else
{
  echo"error:".$sql."<br>".mysqli_error($con);
}
}
}
mysqli_close($con);
?>
