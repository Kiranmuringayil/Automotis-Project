<?php 
session_start(); 
//echo "";

include("co.php");
if(isset($_POST['submit']))
{
	$uname = ($_POST['u_id']);
	$pass = ($_POST['u_pass']);
	$pas = md5($pass);
//echo $u_pass;
//$pa=md5($pass);
	$sql="select * from login_tb where username='$uname' and password='$pas'";
//echo $sql;

	$result=mysqli_query($con,$sql);
	$rowcount=mysqli_num_rows($result);
	if($rowcount!=0)
	{

		while($row=mysqli_fetch_array($result))
		{
			$dbu_uname=$row['username'];
			$dbu_pass=$row['password'];


			if($dbu_uname==$uname && $dbu_pass==$pas)
			{
			//$_SESSION['uname']=$dbu_name;
            //$_SESSION['u_pass']=$dbu_pass;
		     //echo $dbu_type;

				//$_SESSION['type']="Admin";
				$_SESSION["username"]=$row['username'];
				if(isset($_SESSION['username']))
				{
					

					switch ($row['usertype']) {
						case '1':
						echo "<script>alert('admin')</script>";
						header("location: genesis/");
							# code...
							break;
						
						case '0':

						echo "<script>alert('user')</script>";
						header("location: uhome.php");
							# code...
							break;

						default:
							# code...
						echo "<script>alert('$row[username]')</script>";
							break;
					}

					/*if ($row['usertype'] = '1') {
						echo "<script>alert('admin')</script>";
					}
					if ($row['usertype'] = '0') {
						echo "<script>alert('user')</script>";
					}*/
				//header("location: uhome.php");
               	//echo"<script>window.location='uhome.php';</script>";
				}




			}
			
			else
			{

			//header("location:login.php?error=wrong password");
         // echo "Invalid login";
			}
		}
	}
	else
	{
 
		echo '<script type="text/javascript">';
		echo 'alert("Invalid login")';
		echo '</script>';
		{
			?>
			<script>
				window.location='login.php';
			</script>
			<?php
		}
	}
			//header('location:login.php');
			//header("location:../car comp/login.php?error=User Not Found");
			//echo "not found";	
}


?>