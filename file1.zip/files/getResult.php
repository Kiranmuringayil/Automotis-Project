<?php
include("co.php");
$company=$_GET['company'];
$model=$_GET['model'];
$varient=$_GET['varient'];
$sel = mysqli_query($con,"select * from car_models where compid='$company' and model='$model'and varient='$varient'");
$result=array();
	$len=0;
	if($sel){
		while($row=mysqli_fetch_array($sel)){
			
			for($i=4;$i<30;$i++){					
				
				if($i==4){	
					$typeid=$row['type'];				
					$query=mysqli_query($con,"select type from type where typeid=$typeid");
					$the=mysqli_fetch_assoc($query);
					$row[$i]=$the['type'];
				}
				if($i==5){
					$fuelid=$row['fuel'];
					$query=mysqli_query($con,"select fuel_type from fuel where fuelid=$fuelid");
					$the=mysqli_fetch_assoc($query);
					$row[$i]=$the['fuel_type'];
				}
				if($i==11){
					$transid=$row['transmission'];
					$query=mysqli_query($con,"select transmission from transmission where transid=$transid");
					$the=mysqli_fetch_assoc($query);
					$row[$i]=$the['transmission'];
				}
				$result[$len][$i-4]=$row[$i];
			}
			$len++;			
		}
	}
$myJson = json_encode($result);
if($len!=0){
	echo $myJson; 
}
?>
