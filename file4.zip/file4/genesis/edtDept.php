 <?php
 session_start();
if (isset($_SESSION['username'])) {
 include('head.php');
 ?>
 <div class="app-main__outer">
    <div class="app-main__inner">

        <div class="row">
            <div class="col-md-8">
                <div class="main-card mb-3 card">
                    <div class="card-body"><h5 class="card-title">Edit Department</h5>
                        <form method="post">
                            <?php
                            if (isset($_GET['key'])) {
                                $id =$_GET['key'];
                                $idsel=mysqli_query($con,"select * from dept_tbl where dept_id='$id' ");
            //echo $_GET['id'];
                                while ($idrow=$idsel->fetch_assoc()) {
                                    ?>
                                    <div class="position-relative form-group">
                                        <label for="deptName"> Department Name </label>
                                        <input id="deptName" name="deptname" value="<?php echo $idrow['dept_name']; ?>" type="text" class="form-control"></div>
                                        <div class="position-relative form-group">
                                            <label for="deptLoc" >Location</label>
                                            <input id="deptLoc" name="deptloc" value="<?php echo $idrow['dept_loc']; ?>" type="text" class="form-control"></div>
                                            <?php
                                        }

                                    }
                                    else{
                                        header("location:index.php");
                                    }
                                    ?>

                                    <button class="mt-1 mb-2 mr-2 btn btn-outline-success" name="btnedt"> Update </button>
                                    <button class="mt-1 mb-2 mr-2 btn btn-outline-danger" name="btndel"> Delete </button>
                                    <?php

                                    
                                    if (isset($_POST['btnedt'])) {
                                        //$status='1';
                                        $dept_name = mysqli_escape_string($con,$_POST['deptname']);
                                        $dept_loc = mysqli_real_escape_string($con,$_POST['deptloc']);

                                        $updt=mysqli_query($con,"update dept_tbl set dept_name='$dept_name' , dept_loc = '$dept_loc' where dept_id ='$id'");
                                        if (!$updt) {
                                            echo "Not updated";
                                        }
                                        header("location:newDept.php");
                                    }

                                    if (isset($_POST['btndel'])) {
                                        //$status='1';
                                        $dept_name = mysqli_escape_string($con,$_POST['deptname']);
                                        $dept_loc = mysqli_real_escape_string($con,$_POST['deptloc']);
                                        $status='0';
                                        $del=mysqli_query($con,"update dept_tbl set dept_status='$status' where dept_id ='$id'");
                                        if (!$del) {
                                            echo "Not deleted";
                                        }
                                        header("location:newDept.php");
                                    }
                                    ?>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!--<div class="col-lg-6">
                        <div class="main-card mb-3 card">
                            <div class="card-body"><h5 class="card-title">Manage Department</h5>
                                <table class="mb-0 table table-hover">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Dept Name</th>
                                            <th>Location</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
    $sel=mysqli_query($con,"select * from dept_tbl order by dept_id");
    if ($sel->num_rows>0) {
        while ($row=$sel->fetch_assoc()) {
            //echo $row['test_name'];
            ?>
        
    <tr>
      <th scope="row"><?php echo $row['dept_id']; ?></th>
      <td><?php echo $row['dept_name']; ?></td>
      <td><?php echo $row['dept_loc']; ?></td>
      <td><a href="edtDept.php?key=<?php echo $row['dept_id'] ?>"><button class="fa fa-pencil mb-1 mr-1 btn btn-outline-danger"></button></a></td>
    </tr>
   <?php
   }
    }
    ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        

                    </div>-->

                </div>



            </div>
        </div>
        <?php
 
       include('foot.php');
}
        else{
  header("location:Login.php");
}
        ?>