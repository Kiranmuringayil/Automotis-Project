 <?php
 session_start();
if (isset($_SESSION['username'])) {
 include('head.php');
 ?>
 <div class="app-main__outer">
    <div class="app-main__inner">

        <div class="row">
            <div class="col-md-6">
                <div class="main-card mb-3 card">
                    <div class="card-body"><h5 class="card-title">Add Faculty Designation</h5>
                        <form method="post" id="myform">
                                <div class="position-relative form-group">
                                    <label for="quali" >Qualification</label>
                                    <input id="quali" name="quali" onerror="sweetfun()"  onblur="facQali(this)" placeholder="Faculty Qualification" type="text" class="form-control" required></div>

                                    <button class="mt-1 mb-2 mr-2 btn btn-outline-primary"  name="btnAdd"> Add </button>
                                    <script type="text/javascript">
                                        function sweetfun(){
                                            Swal.fire('Oops...', 'Something went wrong!', 'error')
                                        }
                                    </script>
                                    <?php
                                    if (isset($_POST['btnAdd'])) {
                                        $quali = mysqli_real_escape_string($con,$_POST['quali']);
                                        $ins=mysqli_query($con,"insert into qualify_tbl(qualify) values('$quali')");
                                        if (!$ins) {
            # code...
                                            echo "Not inserted";
                                        }
                                        header("Refresh:0; url=addQuali.php");
                                    }
                                    ?>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-6">
                        <div class="main-card mb-3 card">
                            <div class="card-body"><h5 class="card-title">Qualification</h5>
                                <table class="mb-0 table table-hover" id="example1">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Qualification</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
    $sel=mysqli_query($con,"select * from qualify_tbl ");
    if ($sel->num_rows>0) {
        while ($row=$sel->fetch_assoc()) {
            
            ?>
    <tr>
      <th scope="row"><?php echo $row['quali_id']; ?></th>
      <td><?php echo $row['qualify']; ?></td>
    </tr>
   <?php
   }
    }
    ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        

                    </div>
                </div>

<script src="myscript.js"></script>

            </div>
        </div>
        <?php
        include('foot.php');
    }
    else{
  header("location:Login.php");
}
        ?>