<?php
session_start();
include('config/conn.php');
?>
<!doctype html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Orca Dashboard | Login </title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no"
    />
    <meta name="description" content="ArchitectUI HTML Bootstrap 4 Dashboard Template">

    <!-- Disable tap highlight on IE -->
    <meta name="msapplication-tap-highlight" content="no">
    <link href="https://fonts.googleapis.com/css?family=Lobster&display=swap" rel="stylesheet">
    <link href="main.cba69814a806ecc7945a.css" rel="stylesheet"></head>

    <body>
        <div class="app-container app-theme-white body-tabs-shadow">
            <div class="app-container">
                <div class="h-100">
                    <div class="h-100 no-gutters row">
                        <div class="d-none d-lg-block col-lg-5">
                            <div class="slider-light">
                                <div class="slick-slider">
                                    <div>
                                        <div class="position-relative h-100 d-flex justify-content-center align-items-center bg-plum-plate" tabindex="-1">
                                            <div class="slide-img-bg" style="background-image: url('assets/images/originals/citydark.jpg');"></div>

                                        </div>
                                    </div>
                                </div>
                            </div>    
                        </div>

                        <div class="h-100 d-flex bg-white justify-content-center align-items-center col-md-12 col-lg-7">
                            <div class="mx-auto app-login-box col-sm-12 col-md-10 col-lg-9">
                                <div class="row">
                                    <img src="https://img.icons8.com/color/69/000000/orca.png"><a style="text-decoration:none;"><div class="logo orca-head" style="font-family:Lobster;font-size:45px;"> Orca | Admin </a>
                                    </div>


                                    <form class="" action="" method="post">
                                     <div class="divider row"></div>
                                     <div class="form-row">

                                        <div class="col-md-6">
                                            <div class="position-relative form-group"><label for="txtuser" class="">User Name</label>
                                                <input required name="txtuser" id="txtuser" placeholder="Enter Credentials 🕴😎" autocomplete="off" type="email" onblur="admUser(this)" class="form-control"></div>
                                            </div>

                                            <div class="col-md-6">
                                                <div class="position-relative form-group"><label for="txtpsswd" class="">Password</label>
                                                    <input required name="txtpsswd" id="txtpsswd" placeholder="Enter Credentials 🕴😎" type="password" class="form-control"></div>
                                                </div>
                                            </div>

                                            <div class="divider row"></div>
                                            <div class="d-flex align-items-center">
                                                <div class="ml-auto">
                                                    <button id="btnsub1" name="btnsub1" type="submit" class="btn btn-primary btn-lg">Login to Dashboard</button>
                                                    <?php
                                                    if (isset($_POST['btnsub1'])) {
                                                        $txtuser=mysqli_real_escape_string($con,$_POST['txtuser']);
                                                        $txtpsswd=mysqli_real_escape_string($con,$_POST['txtpsswd']);
                                                //
                                                        $sel=mysqli_query($con,"select * from admin_tbl where username='$txtuser' and pass='$txtpsswd' ");
                                                        if ($sel->num_rows>0) {
                                                            while ($row=$sel->fetch_assoc()) {
                                                                //echo $row['username'];
                                                                //echo "<script>alert('checked');</script>";
                                                                $_SESSION["username"]=$row['username'];
                                                                if (isset($_SESSION['username'])) {
                                                                    # code...
                                                                    echo "<script>alert('Welcome $row[username]')</script>";
                                                                    header("location:index.php");
                                                                    //echo"<script>window.location.href:index.php</script>";
                                                                }
                                                            }
                                                        }
                                                        else{
                                                            echo "<script>alert('Unauthorised Access');</script>";
                                                        }
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <script src="myscript.js"></script>
                <script type="text/javascript" src="assets/scripts/main.cba69814a806ecc7945a.js"></script>
                <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
                
</body>
</html>
