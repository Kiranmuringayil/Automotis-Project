 <?php
 session_start();
if (isset($_SESSION['username'])) {
 include('head.php');
 $id=$_GET['id'];
 ?>
 <div class="app-main__outer">
    <div class="app-main__inner">

        <div class="row">
            <div class="col-md-8">
                <div class="main-card mb-3 card">
                    
                        
                <div class="card-body"><h5 class="card-title"><center>Edit Car Details</center></h5>
                        
                        <form method="post" enctype="multipart/form-data">
                                    <div class="row">
                                <div class="col-md-6">
                                    <div class="position-relative form-group">
                                    <label for="uprice"> Ex.Showroom price (Del) </label>
                                    <input id="uprice" onblur="textnumCheck(this)" name="uprice" placeholder="Price" type="text" class="form-control">
                                </div></div></div>
                               

                                    <button class="mt-1 mb-2 mr-2 btn btn-outline-success" name="btnedt"> Update </button>
                                    
                                    <?php

                                    if (isset($_POST['btnedt'])) {
                                        //$status='1';
                                        $price = $_POST['uprice'];
                                        $updt=mysqli_query($con,"update car_models set price='$price' where carid ='$id'");
                                        if (!$updt) {
                                            echo "Not updated";
                                        }
                                        
                                    }

                                    ?>
                                

                            </div>
                        </div>

                    </div>
            
                                     
            </div>
        </div>

        <?php
include('foot.php');
}

else{
  header("location:../login.php");
}
?>