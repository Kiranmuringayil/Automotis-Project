</div>
</div>
<div class="app-drawer-overlay d-none animated fadeIn"></div>
<script type="text/javascript" src="node_modules/sweetalert2/dist/sweetalert2.all.min.js"></script>

<script type="text/javascript" src="assets/scripts/main.cba69814a806ecc7945a.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8"></script>


 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        


<script src="web-animations-2.3.1.min.js"></script>
    <script src="hammer-2.0.8.min.js"></script>
    <script src="muuri.js"></script>
    <script src="demo-kanban.js"></script>

    
    <!-- datatable -->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
   <script src="https://code.jquery.com/jquery-3.3.1.js"></script> 
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );

    $(document).ready(function() {
    $('#example1').DataTable( {
    } );
} );

    //ajax 

    function getDept(val){
        $.ajax({
            type: "POST",
            url: "getDept.php",
            data:'dept_id='+val,
            success: function(data){
                $("#dept_list").html(data);
                getBatch();
            }
        });
    }

    function getBatch(val){
        $.ajax({
            type: "POST",
            url: "getBatch.php",
            data: 'batch_id='+val,
            success: function(data){
                $("#batch_list").html(data);
            }
        });
    }
</script>


</body>

</html>
