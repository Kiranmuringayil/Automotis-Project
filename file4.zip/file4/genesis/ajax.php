<?php
include('config/conn.php');

$dept=$_Get["dept"];
if (! $dept) {
	# code...

$sel=mysqli_query($con,"select * from batch_tbl,dept_tbl where dept_tbl.dept_id=batch_tbl.dept_id and batch_tbl.bth_status= dept_tbl.dept_status='1'");

echo "<select>";
 while($row=mysqli_fetch_assoc($sel)) {
 	?>
 	<option value="<?php echo $row["bth_id"]; ?>"><?php echo $row["bth_name"]; ?></option>
<?php
 }
 echo "</select>";

}
echo "<script>alert('not get');</script>";
/*if (! empty($_POST["batch_id"])) {
	$status='1';
	$sel=mysqli_query($con,"select * from batch_tbl,dept_tbl where dept_tbl.dept_id=batch_tbl.dept_id , bth_status= dept_status='$status' and batch_tbl.bth_id = '".$_POST["bth_id"]."'");

	if ($sel->num_rows>0) {	
    ?>
<option value disabled selected>Select Batch</option>
<?php
    while($row=mysqli_fetch_assoc($sel)) {
        ?>
<option value="<?php echo $row["bth_id"]; ?>"><?php echo $row["bth_name"]; ?></option>

<?php
   } 
}*/
?>