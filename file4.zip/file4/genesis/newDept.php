 <?php
 session_start();
if (isset($_SESSION['username'])) {
 include('head.php');
 ?>
 <div class="app-main__outer">
    <div class="app-main__inner">

        <div class="row">
            <div class="col-md-6">
                <div class="main-card mb-3 card">
                    <div class="card-body"><h5 class="card-title">Add Department</h5>
                        <form method="post" id="myform">
                            <div class="position-relative form-group">
                                <label for="deptName"> Department Name </label>
                                <input id="deptName" name="deptName" placeholder="Department Name" type="text" class="form-control" required onblur="textCheck(this)"></div>
                                <div class="position-relative form-group">
                                    <label for="deptLoc" >Location</label>
                                    <input id="deptLoc" name="deptLoc" onblur="textCheck(this)" placeholder="Location" type="text" class="form-control" required></div>

                                    <button class="mt-1 mb-2 mr-2 btn btn-outline-primary" name="btnAdd"> Add </button>
                                    <?php
                                    if (isset($_POST['btnAdd'])) {
                                        $status='1';
                                        $dept_name = mysqli_escape_string($con,$_POST['deptName']);
                                        $dept_loc = mysqli_real_escape_string($con,$_POST['deptLoc']);
                                        $ins=mysqli_query($con,"insert into dept_tbl(dept_name,dept_loc,dept_status) values('$dept_name','$dept_loc','$status')");
                                        if (!$ins) {
            # code...
                                            echo "Not inserted";
                                        }
                                        header("Refresh:0; url=newDept.php");
                                    }
                                    ?>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-6">
                        <div class="main-card mb-3 card">
                            <div class="card-body"><h5 class="card-title">Manage Department</h5>
                                <table class="mb-0 table table-hover" id="example1">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Dept Name</th>
                                            <th>Location</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $status='1';
    $sel=mysqli_query($con,"select * from dept_tbl where dept_status='$status' order by dept_id ");
    if ($sel->num_rows>0) {
        while ($row=$sel->fetch_assoc()) {
            //echo $row['test_name'];
            ?>
        
    <tr>
      <th scope="row"><?php echo $row['dept_id']; ?></th>
      <td><?php echo $row['dept_name']; ?></td>
      <td><?php echo $row['dept_loc']; ?></td>
      <td><a href="edtDept.php?key=<?php echo $row['dept_id'] ?>"><button class="fa fa-pencil mb-1 mr-1 btn btn-outline-danger"></button></a></td>
    </tr>
   <?php
   }
    }
    ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        

                    </div>
                </div>

<script src="myscript.js"></script>

            </div>
        </div>
        <?php
        include('foot.php');
    }
    else{
  header("location:Login.php");
}
        ?>