<?php
session_start();
if (isset($_SESSION['username'])) {
include('head.php');
?>
 <div class="app-main__outer">
    <div class="app-main__inner">
<div class="row">
                            <div class="col-md-8 col-xl-3">
                                <div class="card mb-3 widget-chart widget-chart2 text-left card-btm-border card-shadow-success border-success">
                                    <div class="widget-chat-wrapper-outer">
                                        <div class="widget-chart-content pt-3 pl-3 pb-1">
                                            <div class="widget-chart-flex">
                                                <div class="widget-numbers">
                                                    <div class="widget-chart-flex">
                                                        <div class="fsize-4">
                                                            <small class="opacity-5"></small>
                                                            <span>
                                              <?php
                                              $query="SELECT count(*) AS cc from used_car where status='1'";
                                              $result=mysqli_query($con,$query);
                                              $row=mysqli_fetch_array($result);
                                              echo $row['cc'];
                                                            ?></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <h6 class="widget-subheading mb-0 opacity-5">Total UsedCars</h6></div>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8 col-xl-3">
                                <div class="card mb-3 widget-chart widget-chart2 text-left card-btm-border card-shadow-success border-success">
                                    <div class="widget-chat-wrapper-outer">
                                        <div class="widget-chart-content pt-3 pl-3 pb-1">
                                            <div class="widget-chart-flex">
                                                <div class="widget-numbers">
                                                    <div class="widget-chart-flex">
                                                        <div class="fsize-4">
                                                            <small class="opacity-5"></small>
                                                            <span>
                                              <?php
                                              $query="SELECT count(*) AS cc from carbooking";
                                              $result=mysqli_query($con,$query);
                                              $row=mysqli_fetch_array($result);
                                              echo $row['cc'];
                                                            ?></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <h6 class="widget-subheading mb-0 opacity-5">Booked Cars</h6></div>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-3">
                                <div class="card mb-3 widget-chart widget-chart2 text-left card-btm-border card-shadow-primary border-primary">
                                    <div class="widget-chat-wrapper-outer">
                                        <div class="widget-chart-content pt-3 pl-3 pb-1">
                                            <div class="widget-chart-flex">
                                                <div class="widget-numbers">
                                                    <div class="widget-chart-flex">
                                                        <div class="fsize-4">
                                                            <small class="opacity-5"></small>
                                                            <span>
                                              <?php
                                              $query="SELECT count(*) AS cc from register_tb where status='0'";
                                              $result=mysqli_query($con,$query);
                                              $row=mysqli_fetch_array($result);
                                              echo $row['cc'];
                                                            ?></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <h6 class="widget-subheading mb-0 opacity-5">Total Users</h6></div>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-3">
                                <div class="card mb-3 widget-chart widget-chart2 text-left card-btm-border card-shadow-warning border-warning">
                                    <div class="widget-chat-wrapper-outer">
                                        <div class="widget-chart-content pt-3 pl-3 pb-1">
                                            <div class="widget-chart-flex">
                                                <div class="widget-numbers">
                                                    <div class="widget-chart-flex">
                                                        <div class="fsize-4">
                                                            <small class="opacity-5"></small>
                                                            <span>
                                                <?php
                                              $query="SELECT count(*) AS cc from feedback_tb";
                                              $result=mysqli_query($con,$query);
                                              $row=mysqli_fetch_array($result);
                                              echo $row['cc'];
                                                            ?></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <h6 class="widget-subheading mb-0 opacity-5">Total Feedbacks</h6></div>
                                        
                                    </div>
                                </div>
                            </div>

                        </div>       
    <div class="col-sm-8 col-sm-12">
<div class="col-lg-12">
                        <div class="main-card mb-12 card">
                            <div class="card-body">
                                <table class="table" id="example1">
                                    <thead>
                                        <tr>
                                            
                                            <th>Company</th>
                                            <th>Model</th>
                                            <th>Year</th>
                                            <th>Price</th>
                                            <th>Username</th>
                                            <th>date</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php
                                        $status='1';
    $sel=mysqli_query($con,"select * from carbooking where status='$status'");
    if($sel->num_rows>0) {
        while ($row=$sel->fetch_assoc()) {
            //echo $row['test_name'];
            ?>
          
    <tr>
      <!--<th scope="row"><?php echo $row['ucar_id']; ?></th>
      <td><a href="<?php echo $row['image']; ?>"><img src="<?php echo $row['image']; ?>" width="30px" height="30px" style="border-radius: 12%;"></a></td-->
      <td><?php echo $row['company']; ?></td>
      <td><?php echo $row['model']; ?></td>
      <td><?php echo $row['year']; ?></td>
      <td><?php echo $row['price']; ?></td>
      <td><?php echo $row['username']; ?></td>
      <td><?php echo $row['date']; ?></td>
      

      <!--<td><a href="edtmodel.php?key=<?php echo $row['ucar_id'] ?>"><button title="View Details" class="fa fa-eye mb-1 mr-1 btn btn-outline-success"></button></a></td>-->
    </tr>
   <?php
   }
    }
    //echo "No Data Found";
    ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        

                    
                        
</div>
</div>
                </div>
<?php
include('foot.php');
}
else{
  header("location:../login.php");
}
?>