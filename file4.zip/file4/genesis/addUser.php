 <?php
 session_start();
 if (isset($_SESSION['username'])) {
   include('head.php');                            
   ?>
   <div class="app-main__outer">
    <div class="app-main__inner">
        <div class="row">
            <div class="col-md-3 col-sm-8">
                <div class="card mb-3 widget-chart widget-chart2 text-left card-btm-border card-shadow-success border-success">
                    <div class="widget-chat-wrapper-outer">
                        <div class="widget-chart-content pt-3 pl-3 pb-1">
                            <div class="widget-chart-flex">
                                <div class="widget-numbers">
                                    <div class="widget-chart-flex">
                                        <div class="fsize-4">
                                            <span><?php
                                            $query="SELECT count(*) AS cc from stu_tbl";
                                            $result=mysqli_query($con,$query);
                                            $row=mysqli_fetch_array($result);
                                            echo $row['cc'];

                                            ?></span></div>
                                        </div>
                                    </div>
                                </div>
                                <h6 class="widget-subheading mb-0 opacity-5">Enrolled Students</h6></div>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-sm-8">
                        <div class="card mb-3 widget-chart widget-chart2 text-left card-btm-border card-shadow-success border-danger">
                            <div class="widget-chat-wrapper-outer">
                                <div class="widget-chart-content pt-3 pl-3 pb-1">
                                    <div class="widget-chart-flex">
                                        <div class="widget-numbers">
                                            <div class="widget-chart-flex">
                                                <div class="fsize-4">
                                                    <span><?php
                                                    $query="SELECT count(*) AS cc from stu_tbl where status='0'";
                                                    $result=mysqli_query($con,$query);
                                                    $row=mysqli_fetch_array($result);
                                                    echo $row['cc'];

                                                    ?></span></div>
                                                </div>
                                            </div>
                                        </div>
                                        <h6 class="widget-subheading mb-0 opacity-5">Deleted Students</h6></div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <img src="assets\images\add-image.jpg">
                            </div>
                            <div class="col-md-8">
                                <div class="main-card mb-3 card">
                                    <div class="card-body"><h5 class="card-title">Add Student</h5>
                                        <div class="row">
                                            <div class="col-md-5">
                                                <form method="post">
                                                    <div class="position-relative form-group">
                                                        <label for="deptLoc" class="col-form-label" >Department and Batch</label>
                                                        <select class="form-control" id="selDeptBatch" name="selDeptBatch" required>
                                                            <option selected disabled>Department -- Batch</option>
                                                            <?php
                                                            $status='1';
                                                            $sel=mysqli_query($con,"select * from batch_tbl,dept_tbl where dept_tbl.dept_id=batch_tbl.dept_id and batch_tbl.bth_status='$status'");
                                                            if ($sel->num_rows>0) {
                                                                while ($row=$sel->fetch_assoc()) {
                                                                    $test=$row['dept_name'].' -- '.$row['bth_name'];
                                                                    //.'-'.$row['bth_id']
                                                                    ?>

                                                                    <option value="<?php echo $row['bth_id']; ?>"><?php echo $test; ?></option>
                                                                    <?php
                                                                }
                                                            }

                                                            ?>
                                                        </select>
                                                    </div>
                                                    <div class="position-relative form-group">
                                                        <label for="userName"> Student Name </label>
                                                        <input id="userName" required onblur="textCheck(this)" name="userName" placeholder="Student Name" type="text" class="form-control">
                                                    </div>
                                                    <!--div class="position-relative form-group">
                                                        <label for="regNo"> Register Number </label>
                                                        <input id="regNo" name="regNo" placeholder="Register Number" type="text" class="form-control">
                                                    </div-->
                                                    <div class="position-relative form-group">
                                                        <label for="phone"> Phone Number </label>
                                                        <input id="phone" name="phone" placeholder="Phone Number" min="1111111111" type="number" class="form-control">
                                                    </div>
                                                    <div class="position-relative form-group">
                                                        <label for="email"> Email </label>
                                                        <input id="email" name="email" placeholder="Email" type="email" class="form-control">
                                                    </div>
                                                    <div class="position-relative form-group">
                                                        <label for="dob"> DoB</label>
                                                        <input id="dob" min="2000-01-01" name="dob" type="date" class="form-control">
                                                    </div>

                                                </div>
                                                <div class="col-md-5">

                                                    <div class="position-relative form-group">
                                                        <label for="gender"> Gender </label>
                                                        <fieldset class="position-relative form-group">
                                                            <div class="position-relative form-check">
                                                                <label class="form-check-label">
                                                                    <input name="gender" value="male" type="radio" class="form-check-input"> Male
                                                                </label>
                                                            </div>
                                                            <div class="position-relative form-check">
                                                                <label class="form-check-label">
                                                                    <input name="gender" value="female" type="radio" class="form-check-input"> Female
                                                                </label>
                                                            </div>
                                                        </fieldset>

                                                    </div>
                                                    <div class="position-relative form-group">
                                                        <label for="address"> Address </label>
                                                        <input id="address" name="address" placeholder="Address" type="text" class="form-control"></div>
                                                        <div class="position-relative form-group">
                                                            <label for="city" >City</label>
                                                            <input id="city" name="city" placeholder="City" type="text" class="form-control"></div>
                                                            <div class="row">
                                                                <div class="position-relative form-group col-md-6">
                                                                    <label for="district"> District </label>
                                                                    <select class="form-control" id="district" name="district">
                                                                        <option selected disabled> -- --</option>
                                                                        <option value="Kasargod">Kasargod</option>
                                                                        <option value="Kannur">Kannur</option>
                                                                        <option value="Wayanad">Wayanad</option>
                                                                        <option value="Kozhikode">Kozhikode</option>
                                                                        <option value="Malappuram">Malappuram</option>
                                                                        <option value="Palakkad">Palakkad</option>
                                                                        <option value="Thrissur">Thrissur</option>
                                                                        <option value="Ernakulam">Ernakulam</option>
                                                                        <option value="Idukki">Idukki</option>
                                                                        <option value="Kottayam">Kottayam</option>
                                                                        <option value="Alappuzha">Alappuzha</option>
                                                                        <option value="Pathanamthitta">Pathanamthitta</option>
                                                                        <option value="Kollam">Kollam</option>
                                                                        <option value="Thiruvananthapuram">Thiruvananthapuram</option>
                                                                    </select>
                                                                </div>

                                                                <div class="position-relative form-group col-md-6">
                                                                    <label for="state"> state </label>
                                                                    <input id="state" name="state" placeholder="state" value="Kerala" type="text" class="form-control"></div>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="position-relative form-group col-md-6">
                                                                        <label for="country"> Country </label>
                                                                        <input id="country" name="country" placeholder="country" value="India" type="text" class="form-control"></div>

                                                                        <div class="position-relative form-group col-md-6">
                                                                            <label for="pin"> pin </label>
                                                                            <input id="pin" name="pin" placeholder="pin" type="number" class="form-control"></div>
                                                                        </div>

                                                                        <button class="mt-1 mb-2 mr-2 btn btn-outline-primary" name="btnAdd"> Add </button>
                                                                        <?php
                                                                        if (isset($_POST['btnAdd'])) {
                                                                            $status='1';
                                                                            $userName = mysqli_escape_string($con,$_POST['userName']);
                                                                            

                                                                            //$regNo = mysqli_real_escape_string($con,$_POST['regNo']);
                                                                            $phone = mysqli_real_escape_string($con,$_POST['phone']);
                                                                            $email = mysqli_real_escape_string($con,$_POST['email']);
                                                                            $dob = mysqli_real_escape_string($con,$_POST['dob']);
                                                                            $gender = mysqli_real_escape_string($con,$_POST['gender']);
                                                                            $address = mysqli_real_escape_string($con,$_POST['address']);
                                                                            $city = mysqli_real_escape_string($con,$_POST['city']);
                                                                            $district = mysqli_real_escape_string($con,$_POST['district']);
                                                                            $state = mysqli_real_escape_string($con,$_POST['state']);
                                                                            $country = mysqli_real_escape_string($con,$_POST['country']);
                                                                            $pin = mysqli_real_escape_string($con,$_POST['pin']);
                                                                            $selDeptBatch = mysqli_real_escape_string($con,$_POST['selDeptBatch']);





                                                                            $ins=mysqli_query($con,"INSERT INTO stu_tbl(stu_name,stu_regNo,stu_phone,stu_email,dob,gender,status, stu_Add,stu_city,stu_district,stu_state,stu_country,stu_pin,bth_id) VALUES ('$userName','$regNo','$phone','$email','$dob','$gender','$status','$address','$city','$district','$state','$country','$pin','$selDeptBatch')");
                                                                            if (!$ins) {
            # code...
                                                                                echo "Not inserted";
                                                                        //echo $ins;
                                                                            }
                                                                            header("Refresh:0; url=addUser.php");
                                                                    //echo $ins;
                                                                        }
                                                                        ?>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-lg-12">
                                                    <div class="main-card mb-3 card">
                                                        <div class="card-body table-responsive">
                                                            <table class="mb-0 table table-bordered" id="example1">
                                                                <thead>
                                                                    <tr>
                                                                        <th>#</th>
                                                                        <th>Dept Name</th>
                                                                        <th>Student</th>
                                                                        <th>Reg Number</th>
                                                                        <th>Phone</th>
                                                                        <th></th>
                                                                    </tr>
                                                                </thead>
                                                                <tfoot>
                                                                    <tr>
                                                                       <th>#</th>
                                                                       <th>Dept Name</th>
                                                                       <th>Student</th>
                                                                       <th>Reg Number</th>
                                                                       <th>Phone</th>
                                                                       <th></th>
                                                                   </tr>
                                                               </tfoot>
                                                               <tbody>
                                                                <?php
                                                                $status='1';
                                                                $sel=mysqli_query($con,"SELECT * FROM stu_tbl,batch_tbl,dept_tbl where stu_tbl.bth_id = batch_tbl.bth_id and batch_tbl.dept_id=dept_tbl.dept_id");
                                                                if ($sel->num_rows>0) {
                                                                    while ($row=$sel->fetch_assoc()) {
            //echo $row['test_name'];
                                                                        ?>

                                                                        <tr>
                                                                          <th scope="row"><?php echo $row['bth_id']; ?></th>
                                                                          <td><?php echo $row['dept_name']; ?></td>
                                                                          <td><?php echo $row['stu_name']; ?></td>
                                                                          <td><?php echo $row['stu_regNo']; ?></td>
                                                                          <td><?php echo $row['stu_phone']; ?></td>
                                                                          <td><a href="edtUser.php?key=<?php echo $row['bth_id'] ?>"><button class="fa fa-pencil mb-1 mr-1 btn btn-outline-danger"></button></a></td>
                                                                      </tr>
                                                                      <?php
                                                                  }
                                                              }
    //echo "No Data Found";
                                                              ?>

                                                          </tbody>
                                                      </table>
                                                  </div>
                                              </div>


                                          </div>

                                      </div>

<!--script type="text/javascript">
    function changeDept() {
        xmlhttp = new XMLHttpRequest();
        xmlhttp.open("GET","ajax.php?dept="+documet.getElementById("dept_list"),false);
        xmlhttp.send(null);

        documet.getElementById("batchDiv").innerHTML = xmlhttp.responseText;
        alert(xmlhttp.responseText);
    }
</script-->
<script src="myscript.js"></script>
</div>
</div>
<?php
include('foot.php');
}
else{
  header("location:Login.php");
}
?>

