class Confirm {
  constructor(con) {
    this.confirm = con;
  }
}
//onblur function
function requiredField(input) {
  if (input.value.length < 3) {
      //red border
      input.style.borderColor = "#e74c3c";
      input.value="";
      sweetfun();
      
    } else if (input.type == "email") {
      console.log("this is an email type");
      
      if (input.value.indexOf("@") != -1 && input.value.indexOf(".") != -1) {
          //green border
          input.style.borderColor = "#2ecc71";

        }
        else {
          //red border
          input.style.borderColor = "#e74c3c";
          input.value="";
          sweetfun();
        }

      } else {
      //green border
      input.style.borderColor = "#2ecc71";
    }
  }
  function confirm_password(input) {
   if(input.value.length < 3) {
    input.style.borderColor = "#e74c3c";
    input.value="";
  }else if (input.type == "password") {
    if(input.value == myvar.confirm){
     input.style.borderColor = "#2ecc71";
   }
   else{
    input.style.borderColor = "#e74c3c";
    alert("password mismatch..");
    input.value="";
  }
}
}

function passwordCheck(input) {
  if (input.value.length < 4) {
      //red border
      input.style.borderColor = "#e74c3c";
      input.value="";
    } else if (input.type == "password") {
      console.log("this is a password type");
      var passw = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/;
      if (input.value.match(passw)) {
          //green border
          input.style.borderColor = "#2ecc71";
        }else {
          //red border
          input.style.borderColor = "#e74c3c";
          alert("Input Password and Submit [6 to 20 characters which contain at least one numeric digit, one uppercase and one lowercase letter")
          input.value="";
        }

      } else {
      //green border
      input.style.borderColor = "#2ecc71";
    }
    myvar = new Confirm(input.value);
  }
  function alpha(input) {
    if (input.value.length < 3) {
      input.style.borderColor = "#e74c3c";
      input.value="";
    }else if (input.type == "text") {
      console.log("this is a password type");
      var passw = /^[A-Za-z_-][A-Za-z0-9_-]*$/;
      if (input.value.match(passw)) {
          //green border  /(^[0-9]+[-]*[0-9]+$)/;
          input.style.borderColor = "#2ecc71";
        } else {
          //red border
          input.style.borderColor = "#e74c3c";
          input.value="";
        }

      } else {
      //green border
      input.style.borderColor = "#2ecc71";
    }
  }

 function textnumCheck(input) {
    if (input.value.length < 1) {
      input.style.borderColor = "#e74c3c";
      input.value="";
       sweetfun();
    }else if (input.type == "text") {
      console.log("this is a password type");
      var passw = /^[A-Za-z .\0-9\s]+$/;
      if (input.value.match(passw)) {
          //green border
          input.style.borderColor = "#2ecc71";
        } else {
          //red border
          input.style.borderColor = "#e74c3c";
          input.value="";
          sweetfun();
          
        }

      } else {
      //green border
      input.style.borderColor = "#2ecc71";
    }
  }

  function textCheck(input) {
    if (input.value.length < 3) {
      input.style.borderColor = "#e74c3c";
      input.value="";
       sweetfun();
    }else if (input.type == "text") {
      console.log("this is a password type");
      var passw = /^[A-Za-z\s]+$/;
      if (input.value.match(passw)) {
          //green border
          input.style.borderColor = "#2ecc71";
        } else {
          //red border
          input.style.borderColor = "#e74c3c";
          input.value="";
          sweetfun();
          
        }

      } else {
      //green border
      input.style.borderColor = "#2ecc71";
    }
  }

  function sweetfun(){
    Swal.fire('Enter the fields!')
  }


  function numberCheck(input) {
    if(input.name="phno"){
      var passw = /^[6-9][0-9]+$/;
      if (input.value.match(passw)) {
          //green border
          input.style.borderColor = "#2ecc71";
        } else {
          //red border
          input.style.borderColor = "#e74c3c";
          input.value="";
          sweetfun();
        }
      }
      else if (input.value.length = 10) {
      //green border
      
      input.style.borderColor = "#e74c3c";
      input.value="";
      sweetfun();
    }
    else if (input.id == "phno" || input.id == "phno") {
      console.log("this is a text type");

      if (input.value.indexOf("9") != -1 && input.value.isNumeric) {
          //green border
          input.style.borderColor = "#2ecc71";
        } 
        if (!isNaN(input.value)) {
          //green border
          input.style.borderColor = "#2ecc71";
        } else {
          //green border
          input.style.borderColor = "#e74c3c";
          input.value="";
          sweetfun();
        }

      } else {
      //green border
      input.style.borderColor = "#2ecc71";
    }

//great artical on how to pull the broswer's errors and then display these fields when the end user tries submitting the form https://www.tjvantoll.com/2012/08/05/html5-form-validation-showing-all-error-messages/
}
var createAllErrors = function() {
  var form = $( this ),
  errorList = $( "ul.errorMessages", form );

  var showAllErrorMessages = function() {
    errorList.empty();

            // Find all invalid fields within the form.
            var invalidFields = form.find( ":invalid" ).each( function( index, node ) {

                // Find the field's corresponding label
                var label = $( "label[for=" + node.id + "] "),
                    // Opera incorrectly does not fill the validationMessage property.
                    message = node.validationMessage || 'Invalid value.';

                    errorList
                    .show()
                    .append( "<li><span>" + label.html() + "</span> " + message + "</li>" );
                  });
          };

        // Support Safari
        form.on( "submit", function( event ) {
          if ( this.checkValidity && !this.checkValidity() ) {
            $( this ).find( ":invalid" ).first().focus();
            event.preventDefault();
          }
        });

        $( "input[type=submit], button:not([type=button])", form )
        .on( "click", showAllErrorMessages);

        $( "input", form ).on( "keypress", function( event ) {
          var type = $( this ).attr( "type" );
          if ( /date|email|month|number|search|tel|text|time|url|week/.test ( type )
            && event.keyCode == 13 ) {
            showAllErrorMessages();
        }
      });
      };

      $( "form" ).each( createAllErrors );