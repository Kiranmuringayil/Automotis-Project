 <?php
 session_start();
if (isset($_SESSION['username'])) {
 include('head.php');
 ?>
 <div class="app-main__outer">
    <div class="app-main__inner">

        <div class="row">
            <div class="col-md-6">
                <div class="main-card mb-3 card">
                    <div class="card-body"><h5 class="card-title">Add Company</h5>
                        <form method="post">
                            <div class="position-relative form-group">
                                <label for="company"> Company </label>
                                <select class="form-control" id="company" name="company" required>
                                <option selected disabled>-- Select Company--</option> 
                                <?php
                                            $sqlcategory=mysqli_query($con,"select * from company where status='1'");
                                            $numcategory=mysqli_num_rows($sqlcategory);
                                            ?>
                                            <?php
                                            for ($i=0; $i <$numcategory ; $i++) 
                                            {  
                                            $rowcategory=mysqli_fetch_array($sqlcategory);
                                            ?>
                                        <option value="<?php echo $rowcategory['compid']; ?>"><?php echo $rowcategory["comp_name"]; ?></option>
                                         <?php
                                           }
                                             ?>
                                </select>
                            </div>
                                <div class="position-relative form-group">
                                    <label for="model">Model</label>
                                    <input id="model" onblur="textCheck(this)" name="model" placeholder="Specify Model" required type="text" class="form-control"></div>
                                    <div class="position-relative form-group">
                                <label for="type"> Type </label>
                                <select class="form-control" id="type" name="type" required>
                                <option selected disabled>-- Select Type--</option> 
                                <?php
                                            $sqlcategory=mysqli_query($con,"select * from type where status='1'");
                                            $numcategory=mysqli_num_rows($sqlcategory);
                                            ?>
                                            <?php
                                            for ($i=0; $i <$numcategory ; $i++) 
                                            {  
                                            $rowcategory=mysqli_fetch_array($sqlcategory);
                                            ?>
                                        <option value="<?php echo $rowcategory['typeid']; ?>"><?php echo $rowcategory["type"]; ?></option>
                                         <?php
                                           }
                                             ?>
                                </select>
                            </div>

                                    <div class="position-relative form-group">
                                    <label for="varient">Varient</label>
                                    <input id="varient" onblur="textCheck(this)" name="varient" placeholder="Varient" type="text" class="form-control">
                                </div>

                                    <button class="mt-1 mb-2 mr-2 btn btn-outline-primary" name="btnAdd"> Add </button>
                                    <?php
                                    if (isset($_POST['btnAdd'])) {
                                        $status='1';
                                        $company = mysqli_escape_string($con,$_POST['company']);
                                        $model = mysqli_real_escape_string($con,$_POST['model']);
                                        $varient = mysqli_real_escape_string($con,$_POST['varient']); 
                                        $type = mysqli_real_escape_string($con,$_POST['type']);
                                        $ins=mysqli_query($con,"insert into car_models(compid,model,type,varient,status) values('$company','$model','$type','$varient','$status')");
                                        if (!$ins) {
            # code...
                                            echo "Not inserted";
                                            echo $ins;
                                        }
                                       // header("Refresh:0; url=addBatch.php");
                                    }
                                    ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                    <div class="col-lg-12">
                        <div class="main-card mb-3 card">
                            <div class="card-body">
                                <table class="table" id="example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Company</th>
                                            <th>Model</th>
                                            <th>Type</th>
                                            <th>Varient</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>#</th>
                                            <th>Company</th>
                                            <th>Model</th>
                                            <th>Type</th>
                                            <th>Varient</th>
                                            <th></th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php
                                        $status='1';
    $sel=mysqli_query($con,"select * from car_models,company,type where company.compid=car_models.compid and type.typeid=car_models.type and company.status='$status'");
    if($sel->num_rows>0) {
        while ($row=$sel->fetch_assoc()) {
            //echo $row['test_name'];
            ?>
        
    <tr>
      <th scope="row"><?php echo $row['carid']; ?></th>
      <td><?php echo $row['comp_name']; ?></td>
      <td><?php echo $row['model']; ?></td>
      <td><?php echo $row['type']; ?></td>
      <td><?php echo $row['varient']; ?></td>
      <td><a href="edtBatch.php?key=<?php echo $row['carid'] ?>"><button class="fa fa-pencil mb-1 mr-1 btn btn-outline-danger"></button></a></td>
    </tr>
   <?php
   }
    }
    //echo "No Data Found";
    ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        

                    </div>
                </div>


<script src="myscript.js"></script>
            </div>
        </div>
        <?php
        include('foot.php');
    }
    else{
  header("location:Login.php");
}
        ?>