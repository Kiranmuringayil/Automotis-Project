<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="Muuri is a JavaScript library that creates responsive, sortable, filterable and draggable grid layouts.">
    <meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="author" content="Niklas Rämö">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://fonts.googleapis.comcss?family=Fira+Sans:400,300,300italic,400italic,500,500italic,700,700italic">
    <link rel="stylesheet" href="https://haltu.github.io/muuri/styles/main.css?v=5">
    <link rel="stylesheet" href="https://haltu.github.io/muuri/styles/demo-kanban.css?v=5">
  </head>
  <body>

    <section class="kanban-demo"><br>

      <div class="board">
          <div class="board-column todo">
           <div class="board-column-header"><strong>Category</strong></div>
           <div class="board-column-content">
            <div class="board-item"><div class="board-item-content"><span><a href="category.php">Add Category</a></span></div></div>
            <div class="board-item"><div class="board-item-content"><span><a href="catimg.php">Add Category Image</a></span></div></div>
            <div class="board-item"><div class="board-item-content"><span><a href="viewcategory.php">View Category</a></span></div></div>
           </div>
         </div>
          <div class="board-column working">
          <div class="board-column-header"><strong>Batch</strong></div>
          <div class="board-column-content">
            <div class="board-item"><div class="board-item-content"><span><a href="batch.php">Add Batch</a></span></div></div>
            <div class="board-item"><div class="board-item-content"><span><a href="viewbatch.php">View Batch</a></span></div></div>
          </div>
        </div>
         <div class="board-column todo">
          <div class="board-column-header"><strong>Users</strong></div>
         <div class="board-column-content">
            <div class="board-item"><div class="board-item-content"><span><a href="viewusers.php">View Users</a></span></div></div>
            <div class="board-item"><div class="board-item-content"><span><a href="manageusers.php">Manage Users</a></span></div></div>
            <div class="board-item"><div class="board-item-content"><span><a href="manageusers.php">Mail User</a></span></div></div>
          </div>
        </div>
        <div class="board-column done">
          <div class="board-column-header"><strong>Products</strong></div>
          <div class="board-column-content">
            <div class="board-item"><div class="board-item-content"><span><a href="adcategory.php">Add Products</a></span></div></div>
            <div class="board-item"><div class="board-item-content"><span><a href="proimg.php">Add Product Image</a></span></div></div>
            <div class="board-item"><div class="board-item-content"><span><a href="adviewpro.php">View Products</a></span></div></div>
          </div>
        </div>
        <div class="board-column working">
          <div class="board-column-header"><strong>Flash Sale</strong></div>
          <div class="board-column-content">
            <div class="board-item"><div class="board-item-content"><span><a href="adflash.php">Add Product</a></span></div></div>
            <div class="board-item"><div class="board-item-content"><span><a href="imgflash.php">Add Product Image</a></span></div></div>
            <div class="board-item"><div class="board-item-content"><span><a href="#">Update Stock</a></span></div></div>
            <div class="board-item"><div class="board-item-content"><span><a href="#">Delete Product</a></span></div></div>
          </div>
        </div>
       <div class="board-column working">
          <div class="board-column-header"><strong>Announcements</strong></div>
         <div class="board-column-content">
            <div class="board-item"><div class="board-item-content"><span><a href="#">Add Item</a></span></div></div>
            <div class="board-item"><div class="board-item-content"><span><a href="#">Add Item Details</a></span></div></div>
            <div class="board-item"><div class="board-item-content"><span><a href="#">View Item</a></span></div></div>
          </div>
        </div>
        
        <div class="board-column working">
          <div class="board-column-header">Payments</div>
          <div class="board-column-content">
            <div class="board-item"><div class="board-item-content"><span><a href="#">View Payments</a></span></div></div>
          </div>
        </div>
        <div class="board-column working">
          <div class="board-column-header">Orders</div>
         <div class="board-column-content">
            <div class="board-item"><div class="board-item-content"><span><a href="vieworder.php">View Orders</a></span></div></div>
          </div>
        </div>
        <div class="board-column done">
          <div class="board-column-header">Invoice</div>
         <div class="board-column-content">
            <div class="board-item"><div class="board-item-content"><span><a href="invoice.php">Bill Invoice</a></span></div></div>
          </div>
        </div>

        
        
        

      </div>

    </section>

    <script src="web-animations-2.3.1.min.js"></script>
    <script src="hammer-2.0.8.min.js"></script>
    <script src="muuri.js"></script>
    <script src="demo-kanban.js"></script>

  </body>

</html>
