<?php
include('config/conn.php');

if (! empty($_POST["dept_id"])) {
	$status='1';
	$sel=mysqli_query($con,"select * from dept_tbl where dept_status='$status' and dept_id ='". $_POST["dept_id"] . "'");
	if ($sel->num_rows>0) {

	while($row=mysqli_fetch_assoc($sel)) {
			$resultset[] = $row;
		}		
		if(!empty($resultset))
			return $resultset;
	}
}
	
    //$query = "SELECT * FROM states WHERE countryID = '" . $_POST["country_id"] . "'";
    //$results = $db_handle->runQuery($query);
    ?>
<option value disabled selected>Select Batch</option>
<?php
    foreach ($sel as $val) {
        ?>
<option value="<?php echo $val["bth_id"]; ?>"><?php echo $val["bth_name"]; ?></option>
<?php
    }
}
?>