 <?php
 session_start();
if (isset($_SESSION['username'])) {
 include('head.php');
 ?>
 <div class="app-main__outer">
    <div class="app-main__inner">

        <div class="col-md-4 col-sm-12">
				<div class="car-detail-sidebar">
					<div class="detail-item car-detail-list">
						<h3>Car Details</h3>
						<table>
							<tbody>
								<tr>
									<td><span>Engine</span></td>
									<td>-----</td>
								</tr>
								<tr>
									<td><span>Fuel Type</span></td>
									<td>Diesel</td>
								</tr>
								<tr>
									<td><span>Displacement</span></td>
									<td>1493cc</td>
								</tr>
																 
								<tr>
									<td><span>Body Type</span></td>
									<td>SUV</td>
								</tr>
								<tr>
									<td><span>Transmission</span></td>
									<td>Manual</td>
								</tr>
								
								<tr>
									<td><span>Gearbox</span></td>
									<td>6 speed</td>										
								</tr>
								<tr>
									<td><span>Max Power</span></td>
									<td>114 bhp @ 4000 rpm</td>
								</tr>
								<tr>
									<td><span>Max Torque</span></td>
									<td>250 Nm @ 1500 rpm</td>																		
								</tr>
								<tr>
									<td><span>Milage (ARAI)</span></td>
									<td>20</td>
																																							
								</tr>
								<tr>
									<td><span>Ground Clearance (mm)</span></td>
									<td>190</td>											
								</tr>
								<tr>
									<td><span>Wheelbase (mm)</span></td>
									<td>2610</td>																			
								</tr>
								<tr>
									<td><span>Kerb Weight (kg)</span></td>
									<td>----</td>
																																								
								</tr>
								<tr>
									<td><span>Bootspace (ltrs)</span></td>
									<td>433</td>
																																								
								</tr>
								<tr>
									<td><span>Length (mm)</span></td>
									<td>4315</td>																																								
								</tr>
								<tr>
									<td><span>Height (mm)</span></td>
									<td>1645</td>																																								
								</tr>
								<tr>
									<td><span>Width (mm)</span></td>
									<td>1800</td>												
								</tr>
								<tr>
									<td><span>Tyres</span></td>
									<td>Alloy Wheels</td>
																			
								</tr>
								<tr>
									<td><span>Seats</span></td>
									<td>5</td>
								</tr>
								<tr>
									<td><span>Power Windows</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>ABS</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Central Lock</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>All Wheel Drive</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Touch Screen Navigation</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Sunroof</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Reverse Camera</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Fog Light</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>DRLS</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Cruise Control</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Electric ORVM</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Ex-Showroom price (Del)</span></td>
									<td>14.96 Lakhs</td>
								</tr>
							</tbody>
						</table>
					</div>
					
				</div>
			</div>



            </div>
        </div>
        <?php
        include('foot.php');
    }
    else{
  header("location:Login.php");
}
        ?>