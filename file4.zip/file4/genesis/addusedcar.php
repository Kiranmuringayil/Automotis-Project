 <?php
 session_start();
if (isset($_SESSION['username'])) {
 include('head.php');
 ?>
 <div class="app-main__outer">
    <div class="app-main__inner">

        <div class="row">
            <div class="col-md-12">

                <div class="main-card mb-3 card">
                    <div class="card-body"><h5 class="card-title"><center>Add Usedcar Details</center></h5>
                        <form method="post" enctype="multipart/form-data">

                            <div class="row">
                                <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="company"> Company </label>
                                <select class="form-control" id="company" name="company" required>
                                <option selected disabled>-- Select Company--</option> 
                                <?php
                                            $sqlcategory=mysqli_query($con,"select * from company where status='1'");
                                            $numcategory=mysqli_num_rows($sqlcategory);
                                            ?>
                                            <?php
                                            for ($i=0; $i <$numcategory ; $i++) 
                                            {  
                                            $rowcategory=mysqli_fetch_array($sqlcategory);
                                            ?>
                                        <option value="<?php echo $rowcategory['compid']; ?>"><?php echo $rowcategory["comp_name"]; ?></option>
                                         <?php
                                           }
                                             ?>
                                </select>
                            </div></div>
                            <div class="col-md-6">
                                <div class="position-relative form-group">
                                    <label for="model">Model</label>
                                    <input id="model" onblur="textCheck(this)" name="model" placeholder="Specify Model" required type="text" class="form-control">
                                </div></div></div>

                                    <div class="row">
                                    <div class="col-md-6">
                                    <div class="position-relative form-group">
                                    <label for="kmdriven">Kilometers</label>
                                    <input id="kmdriven" onblur="textCheck(this)" name="kmdriven" placeholder="Kilometers" type="text" class="form-control">
                                </div></div>
                                <div class="col-md-6">
                                    <div class="position-relative form-group">
                                    <label for="location">Location</label>
                                    <input id="location" onblur="textCheck(this)" name="location" placeholder="Location" type="text" class="form-control">
                                </div></div></div>
                                <div class="row">
                                    <div class="col-md-6">
                                    <div class="position-relative form-group">
                                    <label for="year">Year</label>
                                    <input id="year" onblur="textCheck(this)" name="year" placeholder="Year" type="text" class="form-control">
                                </div></div>
                                <div class="col-md-6">
                                    <div class="position-relative form-group">
                                    <label for="colour">Colour</label>
                                    <input id="colour" onblur="textCheck(this)" name="colour" placeholder="Colour" type="text" class="form-control">
                                </div></div></div>
                                    <div class="row">
                                    <div class="col-md-6">
                                    <div class="position-relative form-group">
                                    <label for="owners">No of Owners</label>
                                    <input id="owners" onblur="textCheck(this)" name="owners" placeholder="No of Owners" type="text" class="form-control">
                                </div></div>
                                    <div class="col-md-6">
                                    <div class="position-relative form-group">
                                    <label for="varient">Varient</label>
                                    <input id="varient" onblur="textCheck(this)" name="varient" placeholder="varient" type="text" class="form-control">
                                </div></div></div>

                                <div class="row">
                                <div class="col-md-6">
                                <div class="position-relative form-group">
                                <label for="type"> Type </label>
                                <select class="form-control" id="type" name="type" required>
                                <option selected disabled>-- Select Type--</option> 
                                <?php
                                            $sqlcategory=mysqli_query($con,"select * from type where status='1'");
                                            $numcategory=mysqli_num_rows($sqlcategory);
                                            ?>
                                            <?php
                                            for ($i=0; $i <$numcategory ; $i++) 
                                            {  
                                            $rowcategory=mysqli_fetch_array($sqlcategory);
                                            ?>
                                        <option value="<?php echo $rowcategory['typeid']; ?>"><?php echo $rowcategory["type"]; ?></option>
                                         <?php
                                           }
                                             ?>
                                </select>
                            </div></div>
           
                                <div class="col-md-6">
                                <div class="position-relative form-group">
                                <label for="fuel"> Fuel Type </label>
                                <select class="form-control" id="fuel" name="fuel" required>
                                <option selected disabled>-- Select Fuel--</option> 
                                <?php
                                            $sqlcategory=mysqli_query($con,"select * from fuel where status='1'");
                                            $numcategory=mysqli_num_rows($sqlcategory);
                                            ?>
                                            <?php
                                            for ($i=0; $i <$numcategory ; $i++) 
                                            {  
                                            $rowcategory=mysqli_fetch_array($sqlcategory);
                                            ?>
                                        <option value="<?php echo $rowcategory['fuelid']; ?>"><?php echo $rowcategory["fuel_type"]; ?></option>
                                         <?php
                                           }
                                             ?>
                                </select>
                            </div></div></div>

                                <div class="row">
                                <div class="col-md-6">
                                <div class="position-relative form-group">
                                    <label for="milage"> ARAI Milage (kmpl)</label>
                                    <input id="milage" onblur="textnumCheck(this)" name="milage" placeholder="Milage" type="text" class="form-control">
                                </div></div>

                                <div class="col-md-6">
                                <div class="position-relative form-group">
                                <label for="transmission"> Transmission </label>
                                <select class="form-control" id="transmission" name="transmission" required>
                                <option selected disabled>-- Select Transmission--</option> 
                                <?php
                                            $sqlcategory=mysqli_query($con,"select * from transmission where status='1'");
                                            $numcategory=mysqli_num_rows($sqlcategory);
                                            ?>
                                            <?php
                                            for ($i=0; $i <$numcategory ; $i++) 
                                            {  
                                            $rowcategory=mysqli_fetch_array($sqlcategory);
                                            ?>
                                        <option value="<?php echo $rowcategory['transid']; ?>"><?php echo $rowcategory["transmission"]; ?></option>
                                         <?php
                                           }
                                             ?>
                                </select>
                            </div></div></div>

                                <div class="row">
                                <div class="col-md-6">
                                <div class="position-relative form-group">
                                    <label for="seat"> Seat </label>
                                    <input id="seat" onblur="textnumCheck(this)" name="seat" placeholder="Seat" type="text" class="form-control">
                                </div></div>
                                <div class="col-md-6">
                                <div class="position-relative form-group">
                                    <label for="tyres"> Alloy Wheel </label><br>
                                    <input type="radio" name="alloy" value="yes"> Yes
                                  <input type="radio" name="alloy" value="no"> No<br>
                                </div></div></div>

                                <div class="row">
                                <div class="col-md-6">
                                <div class="position-relative form-group">
                                    <label for="abs"> ABS </label><br>
                                    <input type="radio" name="abs" value="yes"> Yes
                                  <input type="radio" name="abs" value="no"> No<br>
                                </div></div>
                                <div class="col-md-6">
                                <div class="position-relative form-group">
                                    <label for="drive"> All wheel drive </label><br>
                                    <input type="radio" name="drive" value="yes"> Yes
                                  <input type="radio" name="drive" value="no"> No<br>
                                </div></div></div>
                               
                                <div class="row">
                                <div class="col-md-6">
                                <div class="position-relative form-group">
                                    <label for="price"> Price </label>
                                    <input id="price" onblur="textnumCheck(this)" name="price" placeholder="Price" type="text" class="form-control">
                                </div></div>
                                <div class="col-md-6">
                                <div class="position-relative form-group">
                                    <label for="cruise"> Upload Image </label><br>
                                <div class="wrap-inputname pos-relative txt10 size12 bo2 bo-rad-10 m-t-3 m-b-23">
                                    <input class="bo-rad-10 sizefull txt10 p-l-20" type="file" name="image" id="image" placeholder="Car Image" required>

                                </div>
                                
                                </div></div></form>

                                    <button class="mt-1 mb-2 mr-2 btn btn-outline-primary" name="btnAdd"> Add </button>
                                    <?php
                                    if (isset($_POST['btnAdd'])) {
                                        $status='1';
                                        $company = $_POST['company'];
                                        $model = $_POST['model'];
                                        $kmdriven = $_POST['kmdriven'];
                                        $location = $_POST['location'];
                                        $year = $_POST['year'];
                                        $colour = $_POST['colour'];
                                        $owners = $_POST['owners'];
                                        $varient = $_POST['varient']; 
                                        $type = $_POST['type'];
                                        $fuel = $_POST['fuel'];
                                        $milage = $_POST['milage'];
                                        $transmission = $_POST['transmission'];
                                        $seat = $_POST['seat'];
                                        $alloy = $_POST['alloy'];
                                        $abs = $_POST['abs'];       
                                        $drive = $_POST['drive'];
                                        $price = $_POST['price'];
                                        //$image = $_POST['image'];

                                        $v1=rand(1111,9999);
                                        $v2=rand(1111,9999);
                                        $v3=$v1.$v2;
                                        $v3=md5($v3);
                                        $target_dir = "../uploads/";
$target_file = $target_dir . basename($_FILES["image"]["name"]);


$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image

    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "Car added successfully.";
        $uploadOk = 0;
    }

    // Check if file already exists
// if (file_exists($target_file)) {
//     echo "Sorry, file already exists.";
//     $uploadOk = 0;
// }
// Check file size
if ($_FILES["image"]["size"] > 5000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// // Allow certain file formats
// if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
// && $imageFileType != "gif" ) {
//     echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
//     $uploadOk = 0;
// }
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  $imgpath=  "../uploads/".$v3.".".$imageFileType;
    if (move_uploaded_file($_FILES["image"]["tmp_name"],$imgpath)) {
        echo "The file ". basename( $_FILES["image"]["name"]). " has been uploaded."."<br>";
$imgpath=  "../uploads/".$v3.".".$imageFileType;

 $ins=mysqli_query($con,"INSERT INTO used_car(compid,model,kmdriven,Location,Year,colour,owners,varient,type,fuel,milage,transmission,seat,alloy,abs,drive,price,image,status) VALUES('$company','$model','$kmdriven','$location','$year','$colour','$owners','$varient','$type','$fuel','$milage','$transmission','$seat','$alloy','$abs','$drive','$price','$imgpath','1')");


    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

            //                             $ins=mysqli_query($con,"INSERT INTO car_models(compid,model,varient,type,fuel,fuel_capacity,milage,displacement,maxpower,maxtorque,transmission,gearbox,seat,ground,wheelbase,weight,boot,length,height,width,alloy,abs,drive, touch,sunroof,camera,drls,cruise,price,image,status) VALUES('$company','$model','$varient','$type','$fuel','$capacity','$milage','$displacement','$maxpower','$maxtorque','$transmission','$gearbox','$seat','$ground','$wheelbase','$weight','$boot','$length','$height','$width','$alloy','$abs','$drive','$touch','$sunroof','$camera','$drls','$cruise','$price','$imgpath','$status')");

                                        
            //                             if (!$ins) {
            //                                 //echo $ins;
            // # code...
            //                                 //echo "Not inserted";
            //                                 echo $ins;
            //                             }
            //                             echo "inserted";
                                       // header("Refresh:0; url=addBatch.php");
                                    }
                                    ?>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
                    <!--div class="col-lg-12">
                        <div class="main-card mb-3 card">
                            <div class="card-body">
                                <table class="table" id="example">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Company</th>
                                            <th>Model</th>
                                            <th>Type</th>
                                            <th>Varient</th>
                                            <th>Fuel</th>
                                            <th>Fuel Capacity</th>
                                            <th>Milage</th>
                                            <th>Displacement</th>
                                            <th>Max Power</th>
                                            <th>Max Torque</th>
                                            <th>No of Cylinders</th>
                                            <th>Transmission</th>
                                            <th>Gearbox</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php
                                        $status='1';
    $sel=mysqli_query($con,"select * from car_models,company,type,fuel,transmission where company.compid=car_models.compid and type.typeid=car_models.type and fuel.fuelid=car_models.fuel and transmission.transid=car_models.transmission and company.status='$status'");
    if($sel->num_rows>0) {
        while ($row=$sel->fetch_assoc()) {
            //echo $row['test_name'];
            ?>
        
    <tr>
      <th scope="row"><?php echo $row['carid']; ?></th>
      <td><?php echo $row['comp_name']; ?></td>
      <td><?php echo $row['model']; ?></td>
      <td><?php echo $row['type']; ?></td>
      <td><?php echo $row['varient']; ?></td>
      <td><?php echo $row['fuel_type']; ?></td>
      <td><?php echo $row['fuel_capacity']; ?></td>
      <td><?php echo $row['milage']; ?></td>
      <td><?php echo $row['displacement']; ?></td>
      <td><?php echo $row['maxpower']; ?></td>
      <td><?php echo $row['maxtorque']; ?></td>
      <td><?php echo $row['transmission']; ?></td>
      <td><?php echo $row['gearbox']; ?></td>
      <td><?php echo $row['seat']; ?></td>
      <td><?php echo $row['wheelbase']; ?></td>
      <td><?php echo $row['weight']; ?></td>
      <td><?php echo $row['length']; ?></td>
      <td><?php echo $row['height']; ?></td>
      <td><?php echo $row['width']; ?></td>
      <td><?php echo $row['tyres']; ?></td>
      <td><?php echo $row['abs']; ?></td>
      <td><?php echo $row['drive']; ?></td>
      <td><?php echo $row['touch']; ?></td>
      <td><?php echo $row['sunroof']; ?></td>
      <td><?php echo $row['camera']; ?></td>
      <td><?php echo $row['drls']; ?></td>
      <td><?php echo $row['cruise']; ?></td>
      <td><?php echo $row['price']; ?></td>

      <td><a href="edtBatch.php?key=<?php echo $row['carid'] ?>"><button class="fa fa-pencil mb-1 mr-1 btn btn-outline-danger"></button></a></td>
    </tr>
   <?php
   }
    }
    //echo "No Data Found";
    ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        

                    </div-->
                </div>


<!--script src="myscript.js"></script-->
            </div>
        </div>
        <?php
        include('foot.php');
    }
    else{
  header("location:Login.php");
}
        ?>