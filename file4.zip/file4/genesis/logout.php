<?php
session_start();
if (isset($_SESSION['username'])) {
	session_unset();
//session_destroy();
echo "<script>alert('session destroyed');</script>";
//session_start();
header("location:../login.php");
}
else
{
	header("location:../login.php");
}
?>