 <?php
 session_start();
if (isset($_SESSION['username'])) {
 include('head.php');
 ?>
 <div class="app-main__outer">
    <div class="app-main__inner">

        <div class="row">
            <div class="col-md-6">
                <div class="main-card mb-3 card">
                    <div class="card-body"><h5 class="card-title">Add Faculty Designation</h5>
                        <form method="post" id="myform">
                            <div class="position-relative form-group">
                                <label for="deptName"> Department </label>
                                <select class="form-control" id="deptName" name="deptName" required>
                                <option selected disabled>-- Select Department--</option> 
                                <?php
                                            $sqlcategory=mysqli_query($con,"select * from dept_tbl where dept_status='1'");
                                            $numcategory=mysqli_num_rows($sqlcategory);
                                            ?>
                                            <?php
                                            for ($i=0; $i <$numcategory ; $i++) 
                                            {  
                                            $rowcategory=mysqli_fetch_array($sqlcategory);
                                            ?>
                                        <option value="<?php echo $rowcategory['dept_id']; ?>"><?php echo $rowcategory["dept_name"]; ?></option>
                                         <?php
                                           }
                                             ?>
                                </select>
                            </div>
                                <div class="position-relative form-group">
                                    <label for="deptLoc" >Designation</label>
                                    <input id="deptLoc" name="deptLoc" onerror="sweetfun()"  onblur="textCheck(this)" placeholder="Faculty Designation" type="text" class="form-control" required></div>

                                    <button class="mt-1 mb-2 mr-2 btn btn-outline-primary" name="btnAdd"> Add </button>
                                    <script type="text/javascript">
                                        function sweetfun(){
                                            Swal.fire('Oops...', 'Something went wrong!', 'error')
                                        }
                                    </script>
                                    <?php
                                    if (isset($_POST['btnAdd'])) {
                                        $status='1';
                                        $dept = mysqli_escape_string($con,$_POST['deptName']);
                                        $desig = mysqli_real_escape_string($con,$_POST['deptLoc']);
                                        $ins=mysqli_query($con,"insert into desig_tbl(dept_id,desig) values('$dept','$desig')");
                                        if (!$ins) {
            # code...
                                            echo "Not inserted";
                                        }
                                        header("Refresh:0; url=addDesig.php");
                                    }
                                    ?>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-6">
                        <div class="main-card mb-3 card">
                            <div class="card-body"><h5 class="card-title">Department wise Designation</h5>
                                <table class="mb-0 table table-hover" id="example1">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Department</th>
                                            <th>Designation</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
    $sel=mysqli_query($con,"select * from desig_tbl,dept_tbl where desig_tbl.dept_id = dept_tbl.dept_id ");
    if ($sel->num_rows>0) {
        while ($row=$sel->fetch_assoc()) {
            
            ?>
    <tr>
      <th scope="row"><?php echo $row['desig_ig']; ?></th>
      <td><?php echo $row['dept_name']; ?></td>
      <td><?php echo $row['desig']; ?></td>
      <td><a href="edtDesig.php?key=<?php echo $row['desig_ig'] ?>"><button class="fa fa-pencil mb-1 mr-1 btn btn-outline-danger"></button></a></td>
    </tr>
   <?php
   }
    }
    ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        

                    </div>
                </div>

<script src="myscript.js"></script>

            </div>
        </div>
        <?php
        include('foot.php');
    }
    else{
  header("location:Login.php");
}
        ?>