jQuery.validator.addMethod("noSpace", function(value, element) {
    return value == '' || value.trim().length != 0;
}, "No space please and don't leave it empty");
jQuery.validator.addMethod("customEmail", function(value, element) {
  return this.optional( element ) || /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/.test( value );
}, "Please enter valid email address!");



jQuery.validator.addMethod("passstrength", function(value, element) {
    return this.optional(element) || /([0-9])/ && /([a-zA-Z])/ && /([~,!,@,#,$,%,^,&,*,-,_,+,=,?,>,<])/.test(value);});


jQuery.validator.addMethod("alphabetsnspace", function(value, element) {
    return this.optional(element) || /^[a-zA-Z ]*$/.test(value);},"Invalid!");


jQuery.validator.addMethod("phoneno", function(phone_number, element) {
          phone_number = phone_number.replace(/\s+/g, "");
          return this.optional(element) || phone_number.length > 9 && 
          phone_number.match(/^((\+[6-9]{1,4}[ \-]*)|(\([0-9]{2,3}\)[ \-]*)|([0-9]{2,4})[ \-]*)*?[0-9]{3,4}?[ \-]*[0-9]{3,4}?$/);
      }, "<br />Please specify phone number");


$.validator.addMethod( "alphanumeric", function( value, element ) {
return this.optional( element ) || /^\w+$/i.test( value );
}, "Letters, and underscores only please" );

var $registrationForm = $('#register-form');
if($registrationForm.length){
  $registrationForm.validate({
      rules:{
          //username is the name of the textbox
          company:{
              required: true
          },
          model: {
              required: true,
              number:true,
              //alphanumeric is the custom method, we defined in the above
              alphabetsnspace: true
          },
          varient:{
              required: true,
              number:true,
              alphabetsnspace: true
          },
          type:{
              required: true
          },
          fuel:{
              required: true
            },

          fuel_capacity:{
              required:true,
              number:true,
              maxlength:3,
              minlength:1
            },

          milage: {
              required: true,
              number:true
          },

          displacement: {
              required: true,
              noSpace: true,
              number:true,
              maxlength:3,
              minlength:1
          },
          maxpower: {
              required: true,
              noSpace: true,
              number:true
          },
          maxtorque: {
              required: true,
              noSpace: true,
              number:true
          },
          transmission: {
              required: true
            },

          gearbox: {
              required: true,
              noSpace: true,
              number:true,
              maxlength:1,
              minlength:1
          },
          seat: {
              required: true,
              noSpace: true,
              number:true,
              maxlength:2,
              minlength:1
          },
          ground: {
              required: true,
              noSpace: true,
              number:true,
              maxlength:4,
              minlength:2
          },
          wheelbase: {
              required: true,
              noSpace: true,
              number:true,
              maxlength:5,
              minlength:2
          },
          weight: {
              required: true,
              noSpace: true,
              number:true,
              maxlength:5,
              minlength:2
          },
          boot: {
              required: true,
              noSpace: true,
              number:true,
              maxlength:4,
              minlength:2
          },
          length: {
              required: true,
              noSpace: true,
              number:true,
              maxlength:5,
              minlength:2
          },
          height: {
              required: true,
              noSpace: true,
              number:true,
              maxlength:5,
              minlength:2
          },
          width: {
              required: true,
              noSpace: true,
              number:true,
              maxlength:5,
              minlength:2
          },
          alloy: {
              required: true
          },
          abs: {
              required: true
          },
          drive: {
              required: true
          },
          touch: {
              required: true
          },
          sunroof: {
              required: true
          },
          camera: {
              required: true
          },
          drls: {
              required: true
          },
          cruise: {
              required: true
          },
          price: {
              required: true,
              noSpace: true,
              number:true,
              maxlength:7,
              minlength:2
          },
          image: {
              required: true
          },
      },
      messages:{
          company: {
              //error message for the required field
              required: 'Please select the company!'
              //alphabetsnspace: 'Name must be in character'
          },
          model:{
            required: 'Please enter the model!'
          },
          varient:{
            required: 'Please enter the varient!'
          },
          type:{
            required: 'Please select the type!'
            number: 'Invalid format!',
            minlength: 'Invalid!',
            maxlength: 'Invalid!'
          },
          fuel_capacity: {
              required: 'Please enter fuel_capacity!',
          },
          milage: {
              //error message for the required field
              required: 'Please enter milage!'
          },
          
          displacement: {
              required: 'Please enter displacement!',
              number: 'Invalid format!',
              minlength: 'Invalid!',
              maxlength: 'Invalid!'
          },
          maxpower: {
              required: 'Please enter maxpower!',
              number: 'Invalid format!',
              minlength: 'Invalid!',
              maxlength: 'Invalid!'
          },
          maxtorque: {
              required: 'Please enter maxtorque!',
              number: 'Invalid format!',
              minlength: 'Invalid!',
              maxlength: 'Invalid!'
          },
          transmission: {
              required: 'Please enter transmission!',
              
          },
          gearbox: {
              required: 'Please enter gearbox!',
              number: 'Invalid format!',
              minlength: 'Invalid!',
              maxlength: 'Invalid!'
          },
          seat: {
              required: 'Please enter seat!',
              number: 'Invalid format!',
              minlength: 'Invalid!',
              maxlength: 'Invalid!'
          },
          ground: {
              required: 'Please enter ground!',
              number: 'Invalid format!',
              minlength: 'Invalid!',
              maxlength: 'Invalid!'
          },
          wheelbase: {
              required: 'Please enter wheelbase!',
              number: 'Invalid format!',
              minlength: 'Invalid!',
              maxlength: 'Invalid!'
          },
          weight: {
              required: 'Please enter weight!',
              number: 'Invalid format!',
              minlength: 'Invalid!',
              maxlength: 'Invalid!'
          },
          boot: {
              required: 'Please enter boot!',
              number: 'Invalid format!',
              minlength: 'Invalid!',
              maxlength: 'Invalid!'
          },
          length: {
              required: 'Please enter length!',
              number: 'Invalid format!',
              minlength: 'Invalid!',
              maxlength: 'Invalid!'
          },
          height: {
              required: 'Please enter height!',
              number: 'Invalid format!',
              minlength: 'Invalid!',
              maxlength: 'Invalid!'
          },
          width: {
              required: 'Please enter width!',
              number: 'Invalid format!',
              minlength: 'Invalid!',
              maxlength: 'Invalid!'
          },
          alloy: {
              required: 'Please enter alloy!'
              
          },
          abs: {
              required: 'Please enter abs!'
              
          },
          drive: {
              required: 'Please enter drive!'
              
          },
          touch: {
              required: 'Please enter touch!'
              
          },
          sunroof: {
              required: 'Please enter sunroof!'
             
          },
           camera: {
              required: 'Please enter camera!'
             
          },
           drls: {
              required: 'Please enter drls!'
              
          },
           cruise: {
              required: 'Please enter cruise!'
              
          },
          price : {
              required: 'Please enter price!',
              number: 'Invalid format!',
              minlength: 'Invalid!',
              maxlength: 'Invalid!'
          },

      },

  });
}
