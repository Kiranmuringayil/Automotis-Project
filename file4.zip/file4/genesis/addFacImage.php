 <?php
 session_start();
 if (isset($_SESSION['username'])) {
     include('head.php');
     ?>
     <div class="app-main__outer">
        <div class="app-main__inner">

            <div class="row">
                <div class="col-md-6">
                    <div class="main-card mb-3 card">
                        <div class="card-body"><h5 class="card-title">Add Batch</h5>
                            <form method="post" enctype="multipart/form-data">
                                <div class="position-relative form-group">
                                    <label for="facName"> Faculty </label>
                                    <select class="form-control" id="facName" name="facName" required>
                                        <option selected disabled>-- Select Faculty--</option> 
                                        <?php
                                        $sqlcategory=mysqli_query($con,"select * from faculty_tbl where fac_status='1'");
                                        $numcategory=mysqli_num_rows($sqlcategory);
                                        ?>
                                        <?php
                                        for ($i=0; $i <$numcategory ; $i++) 
                                        {  
                                            $rowcategory=mysqli_fetch_array($sqlcategory);
                                            ?>
                                            <option value="<?php echo $rowcategory['fac_id']; ?>"><?php echo $rowcategory["fac_name"]; ?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="position-relative form-group">
                                    <label for="exampleFile" class="">Choose Image</label>
                                    <input name="fileToUpload" id="fileToUpload" type="file" class="form-control-file">
                                </div>

                                <button class="mt-1 mb-2 mr-2 btn btn-outline-primary" name="btnAdd"> Upload</button>
                                <?php
                        
                                if (isset($_POST['btnAdd'])) {
                                   
                                    $facName = mysqli_escape_string($con,$_POST['facName']);
                                   //add image
                                $v1=rand(1111,9999);
                                $v2=rand(1111,9999);
                                $v3=$v1.$v2;
                                $v3=md5($v3);

                                $target_dir = "../uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);


$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image

    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    // Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 5000000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
  $imgpath=  "uploads/".$v3.".".$imageFileType;
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],$imgpath)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded."."<br>";
$imgpath=  "uploads/".$v3.".".$imageFileType;
 mysqli_query($con,"insert into facimg_tbl(fac_id,path) values('$facName','$imgpath')");


    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
   // header("Refresh:0; url=addBatch.php");
                                }
                                ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="main-card mb-3 card">
                    <div class="card-body">
                        <table class="table" id="example">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Dept Name</th>
                                    <th>Faculty</th>
                                    <th>Image</th>

                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                   <th>#</th>
                                   <th>Dept Name</th>
                                   <th>Faculty</th>
                                   <th>Image</th>

                               </tr>
                           </tfoot>
                           <tbody>
                            <?php
                            
                            $sel=mysqli_query($con,"select * from faculty_tbl,dept_tbl,facimg_tbl where dept_tbl.dept_id=faculty_tbl.dept_id and faculty_tbl.fac_id=facimg_tbl.fac_id");
                            if ($sel->num_rows>0) {
                                while ($row=$sel->fetch_assoc()) {
            //echo $row['test_name'];
                                    ?>

                                    <tr>
                                      <th scope="row"><?php echo $row['fac_id']; ?></th>
                                      <td><?php echo $row['dept_name']; ?></td>
                                      <td><?php echo $row['fac_name']; ?></td>
                                      <td><img src='<?php echo   $row["path"]; ?>' height="60px" style="border-radius: 15%"/></td>

                                  </tr>
                                  <?php
                              }
                          }
    //echo "No Data Found";
                          ?>

                      </tbody>
                  </table>
              </div>
          </div>


      </div>
  </div>


  <script src="myscript.js"></script>
</div>
</div>
<?php
include('foot.php');
}
else{
  header("location:Login.php");
}
?>