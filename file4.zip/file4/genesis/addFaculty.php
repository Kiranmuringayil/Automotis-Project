 <?php
  session_start();
if (isset($_SESSION['username'])) {
 include('head.php');                            
 ?>
 <div class="app-main__outer">
    <div class="app-main__inner">
        <div class="row">
            <div class="col-md-3 col-sm-8">
                                <div class="card mb-3 widget-chart widget-chart2 text-left card-btm-border card-shadow-success border-success">
                                    <div class="widget-chat-wrapper-outer">
                                        <div class="widget-chart-content pt-3 pl-3 pb-1">
                                            <div class="widget-chart-flex">
                                                <div class="widget-numbers">
                                                    <div class="widget-chart-flex">
                                                        <div class="fsize-4">
                                                            <span><?php
                    $query="SELECT count(*) AS cc from faculty_tbl";
                    $result=mysqli_query($con,$query);
                    $row=mysqli_fetch_array($result);
                    echo $row['cc'];
                    
                    ?></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <h6 class="widget-subheading mb-0 opacity-5">Total Faculty</h6></div>
                                        
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-8">
                                <div class="card mb-3 widget-chart widget-chart2 text-left card-btm-border card-shadow-success border-danger">
                                    <div class="widget-chat-wrapper-outer">
                                        <div class="widget-chart-content pt-3 pl-3 pb-1">
                                            <div class="widget-chart-flex">
                                                <div class="widget-numbers">
                                                    <div class="widget-chart-flex">
                                                        <div class="fsize-4">
                                                            <span><?php
                    $query="SELECT count(*) AS cc from faculty_tbl where fac_status='0'";
                    $result=mysqli_query($con,$query);
                    $row=mysqli_fetch_array($result);
                    echo $row['cc'];
                    
                    ?></span></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <h6 class="widget-subheading mb-0 opacity-5">Leaved Faculty</h6></div>
                                        
                                    </div>
                                </div>
                            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="main-card mb-3 card">
                    <div class="card-body"><h5 class="card-title">Add Faculty</h5>
                        <div class="row">
                            <div class="col-md-5">
                                <form method="post">
                                    <div class="position-relative form-group">
                                        <label for="selDept" class="col-form-label" >Department</label>
                                        <select class="form-control" id="selDept" name="selDept" required>
                                            <option selected disabled>Department</option>
                                            <?php
                                            $status='1';
                                            $sel=mysqli_query($con,"select * from dept_tbl where dept_status='$status'");
                                            if ($sel->num_rows>0) {
                                                while ($row=$sel->fetch_assoc()) {
                                                    ?>

                                                    <option value="<?php echo $row['dept_id']; ?>"><?php echo $row['dept_name']; ?></option>
                                                    <?php
                                                }
                                            }

                                            ?>
                                        </select>
                                    </div>
                                    <div class="position-relative form-group">
                                        <label for="userName"> Faculty Name </label>
                                        <input id="userName" required name="userName" placeholder="Faculty Name" type="text" class="form-control">
                                    </div>
                                    <div class="position-relative form-group">
                                        <label for="phno"> Phone Number </label>
                                        <input id="phno" name="phno" required min="5999999999" placeholder="Phone Number" type="number" class="form-control">
                                    </div>
                                    <div class="position-relative form-group">
                                        <label for="email"> Email </label>
                                        <input id="email" onblur="requiredField(this)" name="email" placeholder="Email" type="email" class="form-control">
                                    </div>
                                    <div class="position-relative form-group">
                                        <label for="gender"> Gender </label>
                                        <fieldset class="position-relative form-group">
                                                            <div class="position-relative form-check">
                                                                <label class="form-check-label">
                                                                    <input name="gender" value="male" type="radio" class="form-check-input" checked> Male
                                                                </label>
                                                            </div>
                                                            <div class="position-relative form-check">
                                                                <label class="form-check-label">
                                                                    <input name="gender" value="female" type="radio" class="form-check-input"> Female
                                                                </label>
                                                            </div>
                                                        </fieldset>
                                    </div>
                                    <div class="position-relative form-group">
                                        <label for="dob"> DoB</label>
                                        <input id="dob" name="dob" max="1997-12-31" type="date" class="form-control">
                                    </div>

                                </div>
                                <div class="col-md-5">

                                    <div class="position-relative form-group">
                                <label for="desig"> Designation </label>
                                <select class="form-control" id="desig" name="desig" required>
                                <option selected disabled>-- Select Designation--</option> 
                                <?php
                                            $sqlcategory=mysqli_query($con,"select * from desig_tbl");
                                            $numcategory=mysqli_num_rows($sqlcategory);
                                            ?>
                                            <?php
                                            for ($i=0; $i <$numcategory ; $i++) 
                                            {  
                                            $rowcategory=mysqli_fetch_array($sqlcategory);
                                            ?>
                                        <option value="<?php echo $rowcategory['desig_ig']; ?>"><?php echo $rowcategory["desig"]; ?></option>
                                         <?php
                                           }
                                             ?>
                                </select>
                            </div>
                                         <div class="position-relative form-group">
                                <label for="deptqualiName"> Qualification </label>
                                <select class="form-control" id="quali" name="quali" required>
                                <option selected disabled>-- Select Qualification--</option> 
                                <?php
                                            $sqlcategory=mysqli_query($con,"select * from qualify_tbl");
                                            $numcategory=mysqli_num_rows($sqlcategory);
                                            ?>
                                            <?php
                                            for ($i=0; $i <$numcategory ; $i++) 
                                            {  
                                            $rowcategory=mysqli_fetch_array($sqlcategory);
                                            ?>
                                        <option value="<?php echo $rowcategory['quali_id']; ?>"><?php echo $rowcategory["qualify"]; ?></option>
                                         <?php
                                           }
                                             ?>
                                </select>
                            </div>
                                        <div class="position-relative form-group">
                                            <label for="address"> Address </label>
                                            <input id="address" name="address" placeholder="Address" type="text" class="form-control"></div>
                                            <div class="position-relative form-group">
                                                <label for="city" >City</label>
                                                <input id="city" name="city" placeholder="City" type="text" class="form-control"></div>
                                                <div class="row">
                                                    <div class="position-relative form-group col-md-6">
                                                        <label for="district"> District </label>
                                                        <select class="form-control" id="district" name="district">
                                                                        <option selected disabled> -- --</option>
                                                                        <option value="Kasargod">Kasargod</option>
                                                                        <option value="Kannur">Kannur</option>
                                                                        <option value="Wayanad">Wayanad</option>
                                                                        <option value="Kozhikode">Kozhikode</option>
                                                                        <option value="Malappuram">Malappuram</option>
                                                                        <option value="Palakkad">Palakkad</option>
                                                                        <option value="Thrissur">Thrissur</option>
                                                                        <option value="Ernakulam">Ernakulam</option>
                                                                        <option value="Idukki">Idukki</option>
                                                                        <option value="Kottayam">Kottayam</option>
                                                                        <option value="Alappuzha">Alappuzha</option>
                                                                        <option value="Pathanamthitta">Pathanamthitta</option>
                                                                        <option value="Kollam">Kollam</option>
                                                                        <option value="Thiruvananthapuram">Thiruvananthapuram</option>
                                                                    </select></div>

                                                        <div class="position-relative form-group col-md-6">
                                                            <label for="state"> state </label>
                                                            <input id="state" name="state" placeholder="state" type="text" value="Kerala" class="form-control">

                                                        </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="position-relative form-group col-md-6">
                                                                <label for="country"> Country </label>
                                                                <input id="country" name="country" placeholder="country" value="India" type="text" class="form-control"></div>

                                                                <div class="position-relative form-group col-md-6">
                                                                    <label for="pin"> pin </label>
                                                                    <input id="pin" name="pin" placeholder="pin" type="text" class="form-control"></div>
                                                                </div>

                                                                <button class="mt-1 mb-2 mr-2 btn btn-outline-primary" name="btnAdd"> Add </button>
                                                                <?php
                                                                if (isset($_POST['btnAdd'])) {
                                                                    $status='1';
                                                                    $userName = mysqli_escape_string($con,$_POST['userName']);
                                                                    $phno = mysqli_real_escape_string($con,$_POST['phno']);
                                                                    $email = mysqli_real_escape_string($con,$_POST['email']);
                                                                    $dob = mysqli_real_escape_string($con,$_POST['dob']);
                                                                    $gender = mysqli_real_escape_string($con,$_POST['gender']);
                                                                    $address = mysqli_real_escape_string($con,$_POST['address']);
                                                                    $city = mysqli_real_escape_string($con,$_POST['city']);
                                                                    $district = mysqli_real_escape_string($con,$_POST['district']);
                                                                    $state = mysqli_real_escape_string($con,$_POST['state']);
                                                                    $country = mysqli_real_escape_string($con,$_POST['country']);
                                                                    $pin = mysqli_real_escape_string($con,$_POST['pin']);
                                                                    $desig = mysqli_real_escape_string($con,$_POST['desig']);
                                                                    $selDept=mysqli_real_escape_string($con,$_POST['selDept']);
                                                                    $quali=mysqli_real_escape_string($con,$_POST['quali']);

$empno=uniqid('AJC0E');
  
      $dobpass=str_replace("-", "", $dob);   
      echo $dobpass;
      $mdpass=md5($dobpass);   
      $type='1';                                                           

   $ins=mysqli_query($con,"INSERT INTO faculty_tbl(fac_name,fac_phno,fac_email,fac_gender,fac_dob, fac_qualify,fac_role,dept_id,fac_address,fac_city,fac_dist,fac_state, fac_country,fac_pin,fac_status,empno) VALUES ('$userName','$phno','$email','$gender','$dob','$quali','$desig','$selDept','$address','$city','$district','$state','$country','$pin','$status','$empno')");


   $ins2=mysqli_query($con,"insert into login_tbl(username,pass,user_type) values ('$email','$mdpass','$type')");
                                                                    if (!$ins && !$ins2) {
            # code...
                                                                        echo "Not inserted";
                                                                        //echo $ins;
                                 }

                                                                    header("Refresh:0; url=addFaculty.php");
                                                                    //echo $ins;
                                                                }
                                                                ?>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                         <div class="col-lg-12">
                        <div class="main-card mb-3 card">
                            <div class="card-body table-responsive">
                                <table class="mb-0 table table-bordered" id="example1">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Dept Name</th>
                                            <th>Faculty</th>
                                            <th>Emp Number</th>
                                            <th>Designation</th>
                                            
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                           <th>#</th>
                                            <th>Dept Name</th>
                                            <th>Faculty</th>
                                            <th>Emp Number</th>
                                            <th>Designation</th>
                                            
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php
                                        $status='1';
    $sel=mysqli_query($con,"select * from faculty_tbl,dept_tbl,desig_tbl where dept_tbl.dept_id=faculty_tbl.dept_id and faculty_tbl.fac_role=desig_tbl.desig_ig and fac_status='$status'");
    if ($sel->num_rows>0) {
        while ($row=$sel->fetch_assoc()) {
            //echo $row['test_name'];
            ?>
        
    <tr>
      <th scope="row"><?php echo $row['fac_id']; ?></th>
      <td><?php echo $row['dept_name']; ?></td>
      <td><?php echo $row['fac_name']; ?></td>
      <td><?php echo $row['empno']; ?></td>
      <td><?php echo $row['desig']; ?></td>
    </tr>
   <?php
   }
    }
    //echo "No Data Found";
    ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        

                    </div>

                                    </div>

<!--script type="text/javascript">
    function changeDept() {
        xmlhttp = new XMLHttpRequest();
        xmlhttp.open("GET","ajax.php?dept="+documet.getElementById("dept_list"),false);
        xmlhttp.send(null);

        documet.getElementById("batchDiv").innerHTML = xmlhttp.responseText;
        alert(xmlhttp.responseText);
    }
</script-->

</div>
</div>
<?php
include('foot.php');
}
else{
  header("location:Login.php");
}
?>

