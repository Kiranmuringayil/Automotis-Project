<?php
session_start();
include('co.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
    

</head>
<style>
    .error{
        color: red;
        font-style: italic;
    }
    
</style>
<body>

    <div class="main">
        <div class="container">
            <div class="signup-content">
                <div class="signup-img">
                    <img src="images/wp.jpg" alt="">
                    
                </div>
                <div class="signup-form">
                    <form action="usereg.php" method="POST" class="register-form" id="register-form" >
                        <h2>user registration form</h2>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="name">Name :</label>
                                <input type="text" name="name" id="name" placeholder="Enter name" required/>
                            </div>
                        </div>
                        
                        
                        <div class="form-group">
                            <label for="state">State :</label>
                            <select class="form-control" id="state" name="state"  required>
                                <option selected disabled>-- Select State --</option> 
                                <?php
                                            $sqlcategory=mysqli_query($con,"select * from state");
                                            $numcategory=mysqli_num_rows($sqlcategory);
                                            ?>
                                            <?php
                                            for ($i=0; $i <$numcategory ; $i++) 
                                            {  
                                            $rowcategory=mysqli_fetch_array($sqlcategory);
                                            ?>
                                        <option value="<?php echo $rowcategory['stateid']; ?>"><?php echo $rowcategory["state"]; ?></option>
                                         <?php
                                           }
                                             ?>
                                </select>
                        </div>
                        
                        <div class="form-group">
                            <label for="city">City:</label>
                            <input type="text" name="city" placeholder="Enter city" id="city">
                        </div>
                        

                        <div class="form-group">
                            <label for="contact">Contact number :</label>
                            <input type="text" name="contact" placeholder="Enter phone number" id="contact">
                        </div>

                        <div class="form-group">
                            <label for="email">Email ID :</label>
                            <input type="email" name="email" placeholder="Enter email id" id="email" />
                        </div>

                        <div class="form-group">
                            <label for="username">Username :</label>
                            <input type="text" name="username" placeholder="Enter username" id="username">
                        </div>
                        <div class="form-group">
                            <label for="password">Password :</label>
                            <input type="password" name="password" placeholder="Enter password" id="password" />
                        </div>
                        <div class="form-group">
                            <label for="confirm">Confirm Password :</label>
                            <input type="password" name="confirm" placeholder="Enter confirm password" id="confirm" />
                        </div>
                        <div class="form-submit">
                            <input type="submit" value="Register" class="submit" name="submit" id="submit" />
                            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
                            </script>
            
    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <script src="register.js"></script>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>


</body>
</html>
