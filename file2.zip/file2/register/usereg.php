<?php 
include 'co.php'; 
if(isset($_POST['submit']))
{
  $a=$_POST['name'];
  $b=$_POST['state'];
  $c=$_POST['city'];
  $d=$_POST['contact'];
  $e=$_POST['email'];
  $g=$_POST['username'];
  $h=$_POST['password'];
  $p=md5($h);
   //echo "<script>alert('$g');</script>";
  $sql="select * from login_tb where username='$g'";
  $result=mysqli_query($con,$sql);
  $rowcount=mysqli_num_rows($result);
  if($rowcount==0)
  {
$sq="insert into login_tb(username,password)values('$g','$p')";
if(mysqli_query($con,$sq))
{
  $s=mysqli_query($con,"select loginid from login_tb where username='$g'");
  $r=mysqli_fetch_array($s,MYSQLI_ASSOC);
  $lid=$r['loginid'];
  //echo "<script>alert('$lid');</script>";
$sql="insert into register_tb(loginid,name,stateid,city,contno,emailid,username,password,status)values('$lid','$a','$b','$c','$d','$e','$g','$p',0)";
 $ch=mysqli_query($con,$sql);
if($ch)
{?>
   <script>
 alert("Registration Successfull");
 window.location='../login.php';
</script>
  <?php
}
else
{
  echo"error:".$sql."<br>".mysqli_error($con);
}
}
}
else
{
  ?>
  <script>alert("User already exist!")
  window.location="http://localhost/car%20comp/register/ureg.php";
</script>
<?php
}
}
mysqli_close($con);
?>
