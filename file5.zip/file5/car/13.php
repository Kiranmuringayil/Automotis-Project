<!DOCTYPE html>
<html class="no-js" lang="en">


<!-- Mirrored from demosly.com/xicia/carlisting/car/13 by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 09 Oct 2019 07:11:50 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<!-- Meta Tags -->
	<meta name="viewport" content="width=device-width,initial-scale=1.0" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />

	
	<!-- Favicon -->
	<link href="../assets/uploads/favicon.png" rel="shortcut icon" type="image/png">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="../css/jquery-ui.css">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/lightbox.min.css">
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/normalize.css">
	<link rel="stylesheet" href="../css/slicknav.min.css">
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="../css/responsive.css">
	<link rel="stylesheet" href="../css/chosen.css">
	<link rel="stylesheet" href="../css/datatable.min.css">


	
	<script type="text/javascript" src="../../../../platform-api.sharethis.com/js/sharethis.js#property=5993ef01e2587a001253a261&product=inline-share-buttons"></script>

</head>

<body>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "../../../../connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10&appId=323620764400430";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
	<!--Preloader Start-->
	<div id="preloader">
		<div id="status" style="background-image: url(../img/preloader/3.gif)"></div>
	</div>
	<!--Preloader End-->

	<!--Top-Header Start-->
	
<!--Menu Start-->
	<div class="menu-area">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-12 col-xs-12">
					<div class="logo">
						<a href="../../index.php"><img src="../assets/uploads/logo (4).png" alt=""></a>
					</div>
				</div>
				<div class="col-md-8 col-sm-9">
					<div class="menu">
						<ul id="nav" class="main-menu">
							
												<li>
												<a href="../../index.php">
												<span class="menu-title">
													HOME
												</span>
												</a>
												</li>
												
											<li>
											<a href="../page/new-car.html	">
												<span class="menu-title">
													CARS
												</span>
												</a>
												</li>
												<li>
											<a href="../../cmpr.php">
												<span class="menu-title">
													COMPARE CARS
												</span>
												</a>
												</li>
												<li>
											<a href="../../thumber/index.html">
												<span class="menu-title">
													GALLERY
												</span>
											</a>
											</li>
											<li>
											<a href="../page/about-us.html">
												<span class="menu-title">
													ABOUT
												</span>
											</a>
											</li>
											<li>
											<a href="../../login.php">
												<span class="menu-title">
													LOGIN
												</span>
											</a>
											</li>
											
										</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	

<!--Banner Start-->
<div class="banner-slider" style="background-image: url(../assets/uploads/audi.jpg)">
	<div class="bg"></div>
	<div class="bannder-table">
		<div class="banner-text">
			<h1>Car Detail</h1>
		</div>
	</div>
</div>

<!--Car Detail Start-->
<div class="car-detail bg-area">
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-sm-12">
				<div class="car-detail-mainbar">
					<div class="car-detail-name">
						<h2>MG Hector</h2>
						<div class="car-detail-price">
							<p>
																	Diesel																
							</p>
						</div>
					</div>

					<div class="car-detail-gallery owl-carousel">
						<div class="car-detail-photo" style="background-image: url(../assets/uploads/cars/hector.jpg)">
							<div class="lightbox-item">
								<a href="../assets/uploads/cars/hector.jpg" data-lightbox="lightbox-item"><i class="fa fa-search-plus"></i></a>
							</div>
						</div>
													<div class="car-detail-photo" style="background-image: url(../assets/uploads/other-cars/hector.jpg)">
								<div class="lightbox-item">
									<a href="../assets/uploads/other-cars/hector.jpg" data-lightbox="lightbox-item"><i class="fa fa-search-plus"></i></a>
								</div>
							</div>
														<div class="car-detail-photo" style="background-image: url(../assets/uploads/other-cars/hector1.jpg)">
								<div class="lightbox-item">
									<a href="../assets/uploads/other-cars/hector1.jpg" data-lightbox="lightbox-item"><i class="fa fa-search-plus"></i></a>
								</div>
							</div>
													
					</div>

					
				</div>

				<!-- Related Cars -->
				<div class="related-ads">
					<div class="related-ads-headline">
						<h2>Related Cars</h2>
					</div>
											<div class="row listing-item">
							<div class="col-md-4 col-sm-4 listing-photo" style="background-image: url(../assets/uploads/cars/seltos.jpg)"></div>
							
							<div class="col-md-4 col-sm-4 listing-text">
								<h2>Kia Seltos</h2>
																<ul>
									<li>Type: <span>SUV</span></li>
									<li>Mileage: <span>17.4</span></li>
									<li>Year: <span>2019</span></li>
								</ul>
							</div>
							<div class="col-md-4 col-sm-4 listing-price">
								<h2>
																			Diesel																	</h2>
								<a href="8.php">View Detail</a>
							</div>
							
						</div>
												<div class="row listing-item">
							<div class="col-md-4 col-sm-4 listing-photo" style="background-image: url(../assets/uploads/cars/harrier.jpg)"></div>
							
							<div class="col-md-4 col-sm-4 listing-text">
								<h2> Tata Harrier</h2>
																<ul>
									<li>Type: <span>Sedan</span></li>
									<li>Mileage: <span>20.1</span></li>
									<li>Year: <span>2019</span></li>
								</ul>
							</div>
							<div class="col-md-4 col-sm-4 listing-price">
								<h2>
																			Diesel																	</h2>
								<a href="12.php">View Detail</a>
							</div>
							
						</div>
										</div>
			</div>

			<div class="col-md-4 col-sm-12">
				<div class="car-detail-sidebar">
					<div class="detail-item car-detail-list">
						<h3>Car Details</h3>
						<table>
							<tbody>
								<tr>
									<td><span>Engine</span></td>
									<td>2.0L Turbocharged Diesel</td>
								</tr>
								<tr>
									<td><span>Fuel Type</span></td>
									<td>Diesel</td>
								</tr>
								<tr>
									<td><span>Displacement</span></td>
									<td>1956cc</td>
								</tr>
																 
								<tr>
									<td><span>Body Type</span></td>
									<td>SUV</td>
								</tr>
								<tr>
									<td><span>Transmission</span></td>
									<td>Manual</td>
								</tr>
								
								<tr>
									<td><span>Gearbox</span></td>
									<td>6 speed</td>										
								</tr>
								<tr>
									<td><span>Max Power</span></td>
									<td>168 bhp @ 3750 rpm</td>
								</tr>
								<tr>
									<td><span>Max Torque</span></td>
									<td>350 Nm @ 1750 rpm</td>																		
								</tr>
								<tr>
									<td><span>Milage (ARAI)</span></td>
									<td>17.41</td>
																																							
								</tr>
								<tr>
									<td><span>Ground Clearance (mm)</span></td>
									<td>192</td>											
								</tr>
								<tr>
									<td><span>Wheelbase (mm)</span></td>
									<td>2750</td>																			
								</tr>
								<tr>
									<td><span>Kerb Weight (kg)</span></td>
									<td>----</td>
																																								
								</tr>
								<tr>
									<td><span>Bootspace (ltrs)</span></td>
									<td>----</td>
																																								
								</tr>
								<tr>
									<td><span>Length (mm)</span></td>
									<td>4655</td>																																								
								</tr>
								<tr>
									<td><span>Height (mm)</span></td>
									<td>1760</td>																																								
								</tr>
								<tr>
									<td><span>Width (mm)</span></td>
									<td>1835</td>												
								</tr>
								<tr>
									<td><span>Tyres</span></td>
									<td>Alloy Wheels</td>
																			
								</tr>
								<tr>
									<td><span>Seats</span></td>
									<td>5</td>
								</tr>
								<tr>
									<td><span>Power Windows</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>ABS</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Central Lock</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>All Wheel Drive</span></td>
									<td>No</td>
								</tr>
								<tr>
									<td><span>Touch Screen Navigation</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Sunroof</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Reverse Camera</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Fog Light</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>DRLS</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Cruise Control</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Electric ORVM</span></td>
									<td>Yes</td>
								</tr>
								<tr>
									<td><span>Ex-Showroom price (Del)</span></td>
									<td>13.48 Lakhs</td>
								</tr>
							</tbody>
						</table>
					</div>
					
				</div>
			</div>
		</div>
	</div>
</div>
<!--Car Detail End-->

	
	<!--Newsletters Start-->
	
	<!--Newsletters End-->

	<!--Footer-Area Start-->
	<div class="footer-area">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-3">
					
				</div>
				<div class="col-md-3 col-sm-3">
					<div class="footer-item footer-service">
						<h2>Contact</h2>
						<ul>
							<li>Automotis-compare.com</li>
							<li>(+91)9495762466</li>
							
						</ul>
					</div>
				</div>
				<div class="col-md-3 col-sm-3">
					
				</div>
				<div class="col-md-3 col-sm-3">
					<div class="footer-item footer-service">
						<h2>Social Media</h2>
						<div class="footer-social-link">
							<ul>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li><li><a href="#"><i class="fa fa-twitter"></i></a></li><li><a href="#"><i class="fa fa-linkedin"></i></a></li><li><a href="#"><i class="fa fa-google-plus"></i></a></li><li><a href="#"><i class="fa fa-pinterest"></i></a></li>							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="copyright">
					<p>Copyright © 2019. All Rights Reserved.</p>
				</div>
			</div>
		</div>
	</div>

	<!--Footer-Area End-->


	<!--Scroll-Top-->
	<div class="scroll-top">
		<div class="scroll"></div>
	</div>
	<!--Scroll-Top-->


	

	<!--Js-->
	<script src="../js/jquery-2.2.4.min.js"></script>
	<script src="../js/jquery-ui.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/chosen.jquery.js"></script>
	<script src="../js/docsupport/init.js"></script>
	<script src="../js/lightbox.min.js"></script>
	<script src="../js/jquery.dataTables.min.js"></script>
	<script src="../js/owl.carousel.min.js"></script>
	<script src="../js/jquery.slicknav.min.js"></script>
	<script src="../js/jquery.filterizr.min.js"></script>
	<script src="../js/jquery.collapse.js"></script>
	<script src="../js/custom.js"></script>

	<script>
		function confirmDelete()
		{
		    return confirm("Do you sure want to delete this data?");
		}

	</script>


	
</body>


<!-- Mirrored from demosly.com/xicia/carlisting/car/13 by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 09 Oct 2019 07:11:52 GMT -->
</html>