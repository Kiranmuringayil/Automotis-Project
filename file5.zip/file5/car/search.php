<?php
session_start();
if(isset($_SESSION['username']))
{
$se=$_GET['search'];
//echo $id;
include('../../genesis/config/conn.php');
?>
<!DOCTYPE html>
<html class="no-js" lang="en">


<!-- Mirrored from demosly.com/xicia/carlisting/car/19 by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 09 Oct 2019 07:11:41 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
  <!-- Meta Tags -->
  <meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <meta http-equiv="content-type" content="text/html; charset=UTF-8" />

  
  <!-- Favicon -->
  <link href="../assets/uploads/favicon.png" rel="shortcut icon" type="image/png">

  <!-- Stylesheets -->
  <link rel="stylesheet" href="../css/jquery-ui.css">
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/lightbox.min.css">
  <link rel="stylesheet" href="../css/owl.carousel.min.css">
  <link rel="stylesheet" href="../css/normalize.css">
  <link rel="stylesheet" href="../css/slicknav.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../css/responsive.css">
  <link rel="stylesheet" href="../css/chosen.css">
  <link rel="stylesheet" href="../css/datatable.min.css">


  
  <script type="text/javascript" src="../../../../platform-api.sharethis.com/js/sharethis.js#property=5993ef01e2587a001253a261&product=inline-share-buttons"></script>

</head>

<body>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "../../../../connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10&appId=323620764400430";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
  <!--Preloader Start-->
  <div id="preloader">
    <div id="status" style="background-image: url(../img/preloader/3.gif)"></div>
  </div>
  <!--Preloader End-->

  <!--Top-Header Start-->
  
<!--Menu Start-->
  <div class="menu-area">
    <div class="container">
      <div class="row">
        <div class="col-md-4 col-sm-12 col-xs-12">
          <div class="logo">
            <a href="../../index.php"><img src="../assets/uploads/logo (4).png" alt=""></a>
          </div>
        </div>
        <div class="col-md-8 col-sm-9">
          <div class="menu">
            <ul id="nav" class="main-menu">
              
                        <li>
                        <a href="../../uhome.php">
                        <span class="menu-title">
                          HOME
                        </span>
                        </a>
                        </li>
                        
                        <li>
                      <a href="../../ucompare.php">
                        <span class="menu-title">
                          COMPARE
                        </span>
                        </a>
                        </li>
                        <li>
                      <a href="../page/usedcar.php">
                        <span class="menu-title">
                          USED CARS
                        </span>
                        </a>
                        </li>
                        <li>
                      <a href="../../feedback.php">
                        <span class="menu-title">
                          FEEDBACK
                        </span>
                        </a>
                        </li>
                          <li>
                      <a href="../../uprofile.php">
                        <span class="menu-title">
                          PROFILE
                        </span>
                        </a>
                        </li>
                      
                      <li>
                      <a href="../../logout.php">
                        <span class="menu-title">
                          LOGOUT
                        </span>
                      </a>
                      </li>
                      
                    </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  

<!--Banner Start-->
<div class="banner-slider" style="background-image: url(../assets/uploads/audi.jpg)">
  <div class="bg"></div>
  <div class="bannder-table">
    <div class="banner-text">
      <h1>Car Detail</h1>
    </div>
  </div>
</div>

<!--Car Detail Start-->
<div class="car-detail bg-area">
  <div class="container">
    <div class="row">
      <div class="col-md-8 col-sm-12">
        <div class="car-detail-mainbar">
          <div class="car-detail-name">
            <?php
                      include('../../genesis/config/conn.php');

                    
                        $se=$_GET['search'];
                      

        $sq2="SELECT * FROM car_models,type,fuel,company,transmission WHERE car_models.type=type.typeid and car_models.fuel=fuel.fuelid and car_models.transmission=transmission.transid and car_models.compid=company.compid and `model` LIKE '%".$se."%'";
                $result=mysqli_query($con,$sq2);

        //$rowcount=mysqli_num_rows($result);
        if($result->num_rows>0)
        {
           //echo'<script>alert('.$selres->num_rows.');</script>';
           
           while($row=$result->fetch_assoc())
           {
         
            ?>     
                        
                          


            <h2><?php echo $row['comp_name'].' '.$row['model']; ?></h2>
            <div class="car-detail-price">
              <p>
                                  <?php echo $row['fuel_type'];?>                               
              </p>
            </div>
          </div>

          <div class="car-detail-gallery owl-carousel">
            <div class="car-detail-photo" style="background-image: url(../<?php echo $row['image'];?>)">
              <div class="lightbox-item">
                <a href="../<?php echo $row['image'];?>" data-lightbox="lightbox-item"><i class="fa fa-search-plus"></i></a>
              </div>
            </div>
                          <div class="car-detail-photo" style="background-image: url(../<?php echo $row['image'];?>)">
                <div class="lightbox-item">
                  <a href="../<?php echo $row['image'];?>" data-lightbox="lightbox-item"><i class="fa fa-search-plus"></i></a>
                </div>
              </div>
                            <div class="car-detail-photo" style="background-image: url(../<?php echo $row['image'];?>)">
                <div class="lightbox-item">
                  <a href="../<?php echo $row['image'];?>" data-lightbox="lightbox-item"><i class="fa fa-search-plus"></i></a>
                </div>
              </div>
                          
          </div>

          
        </div>

        <!-- Related Cars -->
        
                    
      </div>

      <div class="col-md-4 col-sm-12">
        <div class="car-detail-sidebar">
          <div class="detail-item car-detail-list">
            <h3>Car Details</h3>
            <table>
              <tbody>
                
                <tr>
                  <td><span>Fuel Type</span></td>
                  <td><?php echo $row['fuel_type'];?></td>
                </tr>
                <tr>
                  <td><span>Displacement</span></td>
                  <td><?php echo $row['displacement'];?></td>
                </tr>
                                 
                <tr>
                  <td><span>Body Type</span></td>
                  <td><?php echo $row['type'];?></td>
                </tr>
                <tr>
                  <td><span>Transmission</span></td>
                  <td><?php echo $row['transmission'];?></td>
                </tr>
                
                <tr>
                  <td><span>Gearbox</span></td>
                  <td><?php echo $row['gearbox'];?></td>                    
                </tr>
                <tr>
                  <td><span>Max Power</span></td>
                  <td><?php echo $row['maxpower'];?></td>
                </tr>
                <tr>
                  <td><span>Max Torque</span></td>
                  <td><?php echo $row['maxtorque'];?></td>                                    
                </tr>
                <tr>
                  <td><span>Milage (ARAI)</span></td>
                  <td><?php echo $row['milage'];?></td>
                                                                              
                </tr>
                <tr>
                  <td><span>Ground Clearance (mm)</span></td>
                  <td><?php echo $row['ground'];?></td>                     
                </tr>
                <tr>
                  <td><span>Wheelbase (mm)</span></td>
                  <td><?php echo $row['wheelbase'];?></td>                                      
                </tr>
                <tr>
                  <td><span>Kerb Weight (kg)</span></td>
                  <td><?php echo $row['weight'];?></td>
                                                                                
                </tr>
                <tr>
                  <td><span>Bootspace (ltrs)</span></td>
                  <td><?php echo $row['boot'];?></td>
                                                                                
                </tr>
                <tr>
                  <td><span>Length (mm)</span></td>
                  <td><?php echo $row['length'];?></td>                                                                               
                </tr>
                <tr>
                  <td><span>Height (mm)</span></td>
                  <td><?php echo $row['height'];?></td>                                                                               
                </tr>
                <tr>
                  <td><span>Width (mm)</span></td>
                  <td><?php echo $row['width'];?></td>                        
                </tr>
                <tr>
                  <td><span>Alloy Wheels</span></td>
                  <td><?php echo $row['alloy'];?></td>
                                      
                </tr>
                <tr>
                  <td><span>Seats</span></td>
                  <td><?php echo $row['seat'];?></td>
                </tr>
                
                <tr>
                  <td><span>ABS</span></td>
                  <td><?php echo $row['abs'];?></td>
                </tr>
                
                <tr>
                  <td><span>All Wheel Drive</span></td>
                  <td><?php echo $row['drive'];?></td>
                </tr>
                <tr>
                  <td><span>Touch Screen Navigation</span></td>
                  <td><?php echo $row['touch'];?></td>
                </tr>
                <tr>
                  <td><span>Sunroof</span></td>
                  <td><?php echo $row['sunroof'];?></td>
                </tr>
                <tr>
                  <td><span>Reverse Camera</span></td>
                  <td><?php echo $row['camera'];?></td>
                </tr>
              
                <tr>
                  <td><span>DRLS</span></td>
                  <td><?php echo $row['drls'];?></td>
                </tr>
                <tr>
                  <td><span>Cruise Control</span></td>
                  <td><?php echo $row['cruise'];?></td>
                </tr>
                
                <tr>
                  <td><span>Ex-Showroom price (Del)</span></td>
                  <td><?php echo $row['price'];?></td>
                </tr>
              </tbody>
            </table>
          </div>
          
        </div>
      </div>
      <?php          
            }   
        }
          else
          { 
               echo "<script>alert('No results found')</script>";
               echo "<script>window.location.href='../../uhome.php'</script>";
        } 
    
    
    ?>
    </div>
  </div>
</div>
<!--Car Detail End-->

  
  <!--Newsletters Start-->
  
  <!--Newsletters End-->

  <!--Footer-Area Start-->
  <div class="footer-area">
    <div class="container">
      <div class="row">
        <div class="col-md-3 col-sm-3">
          
        </div>
        <div class="col-md-3 col-sm-3">
          <div class="footer-item footer-service">
            <h2>Contact</h2>
            <ul>
              <li>Automotis-compare.com</li>
              <li>(+91)9495762466</li>
              
            </ul>
          </div>
        </div>
        <div class="col-md-3 col-sm-3">
          
        </div>
        <div class="col-md-3 col-sm-3">
          <div class="footer-item footer-service">
            <h2>Social Media</h2>
            <div class="footer-social-link">
              <ul>
                <li><a href="#"><i class="fa fa-facebook"></i></a></li><li><a href="#"><i class="fa fa-twitter"></i></a></li><li><a href="#"><i class="fa fa-linkedin"></i></a></li><li><a href="#"><i class="fa fa-google-plus"></i></a></li><li><a href="#"><i class="fa fa-pinterest"></i></a></li>              </ul>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="copyright">
          <p>Copyright © 2019. All Rights Reserved.</p>
        </div>
      </div>
    </div>
  </div>

  <!--Footer-Area End-->


  <!--Scroll-Top-->
  <div class="scroll-top">
    <div class="scroll"></div>
  </div>
  <!--Scroll-Top-->


  <!--Js-->
  <script src="../js/jquery-2.2.4.min.js"></script>
  <script src="../js/jquery-ui.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/chosen.jquery.js"></script>
  <script src="../js/docsupport/init.js"></script>
  <script src="../js/lightbox.min.js"></script>
  <script src="../js/jquery.dataTables.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.slicknav.min.js"></script>
  <script src="../js/jquery.filterizr.min.js"></script>
  <script src="../js/jquery.collapse.js"></script>
  <script src="../js/custom.js"></script>

  <script>
    function confirmDelete()
    {
        return confirm("Do you sure want to delete this data?");
    }
  </script>
</body>
</html>
<?php
  }
  else
  {
  header("location:login.php");
  }

?>