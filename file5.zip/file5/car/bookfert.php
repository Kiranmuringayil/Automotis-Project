<?php
$id=$_GET['id'];
//echo $id;
include("../../co.php");
?>
<!DOCTYPE html>
<?php
require_once($_SERVER['DOCUMENT_ROOT']."/car comp/carlisting/page/RazorpayKit/RazorpayKit/razorpay-php/config.php");
?>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>HTML5 Contact Form</title>
  <link rel="stylesheet" href="../css/bookfert.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="container">  
  <form id="contact" action="" method="post">
      <?php
              $sel=mysqli_query($con,"SELECT * FROM used_car,type,fuel,company,transmission WHERE used_car.type=type.typeid and used_car.fuel=fuel.fuelid and used_car.transmission=transmission.transid and used_car.compid=company.compid and used_car.ucar_id='$id'");
          if ($sel->num_rows>0) {
            while ($row=$sel->fetch_assoc()) {
              ?>
    <h3>BOOK THE CAR</h3>
    <h4></h4>
    <fieldset>
    <label for="first_name"> Company</label>
      <input  type="text" tabindex="2"  name="company" value="<?php
      echo $row['comp_name'];
      ?> " readonly>
    </fieldset>
    <fieldset>
    <label for="first_name">Model</label>
    <input  type="hidden"  id="model" name="model" value="  <?php 
      echo $row['model'];
  ?>" readonly>
      <input  type="text" tabindex="1" value="  <?php 
      echo $row['model'];
  ?>" readonly>
    </fieldset>
    <fieldset>
    <label for="first_name">Year</label>
      <input  type="text" tabindex="2" name="year" value="<?php
      echo $row['Year'];
      ?>" readonly>
    </fieldset>
    <fieldset>
    <label for="first_name">Price</label>
      <input  type="text" tabindex="2" id="price" name="price" value="<?php
      echo $row['price'];
      ?> L" readonly>
    </fieldset>
    <fieldset>
      <input type="hidden" id="pay" name="pay" value="10000"/>
      <button name="submit" type="submit" id="contact-submit">Confirm Booking</button></a>
    </fieldset>
    <?php 
  }
} 
?>
  
 
  
</div>
<!-- partial -->
  <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script>
        $(document).ready(function(){

            $('form').submit(function (e){

                var totalAmount = $("#pay").val();//total amount eduth oru variablililu vekkuka


        var options={
        "key": "rzp_test_XgYjoI4qQZ5sZU",//ivide payment gatewayil ninnolla key kodukkuka
        "amount": totalAmount*100,//amount into 100 cheythale actual amount kanikku 
        "name": "Automotis",//ithoke set cheyyuka a gatewayil kainikkanda reethilu
        "description": "Used car advance payment",
        "currency":"INR",// ithelu thottekkallu
        "image": "../assets/uploads/logo (4).png",//icon mattan
        "handler": function (response)
        {
            $.ajax({
            url: '/car comp/carlisting/page/RazorpayKit/RazorpayKit/checkoutsuccess.php',//ivide nammade payment tablilinte code oke kedakkunna php file specify cheyyuka
            type: 'POST',
            data: {
                razorpay_payment_id:response.razorpay_payment_id ,//ith payment gateway thannne genarate cheytholum
                 totalAmount : totalAmount ,// baaki nammade variables
                
            }, 
            success: function (msg)
            {
               if(msg)
               {
              alert("Payment Success "+msg);
              window.location.href="bookfertpro.php?id="+ucar_id;
               }
               else
               {
              alert("Payment Error");
               }
            
            }
        });
      
    },
    "theme": {
        "color": "#734a9c"//ith color set cheyyan
    }
    };



   var rzp1 = new Razorpay(options);
   rzp1.open();// e code payment gateway open cheyyum
   e.preventDefault();

            });

        });
    </script>
    </form>
</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

</html>