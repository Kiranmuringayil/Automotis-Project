<!DOCTYPE html>
<html class="no-js" lang="en">


<!-- Mirrored from demosly.com/xicia/carlisting/forget-password.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 09 Oct 2019 07:12:27 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<!-- Meta Tags -->
	<meta name="viewport" content="width=device-width,initial-scale=1.0" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />

	
	<!-- Favicon -->
	<link href="assets/uploads/favicon.png" rel="shortcut icon" type="image/png">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/jquery-ui.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/lightbox.min.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/normalize.css">
	<link rel="stylesheet" href="css/slicknav.min.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">
	<link rel="stylesheet" href="css/chosen.css">
	<link rel="stylesheet" href="css/datatable.min.css">


	
	<script type="text/javascript" src="../../../platform-api.sharethis.com/js/sharethis.js#property=5993ef01e2587a001253a261&product=inline-share-buttons"></script>

</head>

<body>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "../../../connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10&appId=323620764400430";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
	<!--Preloader Start-->
	<div id="preloader">
		<div id="status" style="background-image: url(img/preloader/3.gif)"></div>
	</div>
	<!--Preloader End-->

	<!--Top-Header Start-->
	<div class="top-header">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-sm-6 col-xs-12">
					<div class="top-header-left">
						<p><i class="fa fa-phone"></i> 123-456-7878</p>
						<p><i class="fa fa-envelope-o"></i> info@yourwebsite.com</p>
					</div>
				</div>
				<div class="col-md-6 col-sm-6 col-xs-12">
					<div class="top-header-right">
						
													<a href="registration.html"><i class="fa fa-sign-in"></i>Sign Up</a>
							<a href="login.html"><i class="fa fa-sign-in"></i>Sign In</a>
											</div>
				</div>
			</div>
		</div>
	</div>

	<!--Menu Start-->
	<div class="menu-area">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-12 col-xs-12">
					<div class="logo">
						<a href="index.html"><img src="assets/uploads/logo.png" alt=""></a>
					</div>
				</div>
				<div class="col-md-8 col-sm-9">
					<div class="menu">
						<ul id="nav" class="main-menu">
							
							<li><a href="index.html">
												<span class="menu-title">
													Home
												</span>
												</a></li><li></li><li>
											<a href="page/about-us.html">
												<span class="menu-title">
													About Us
												</span>
											</a>
											</li><li></li><li><a href="#">
												<span class="menu-title">
													Cars
												</span>
												</a><ul><li><a href="page/new-car.html">New Car</a></li><li><a href="page/old-car.html">Old Car</a></li></ul></li><li>
											<a href="page/testimonial.html">
												<span class="menu-title">
													Testimonial
												</span>
											</a>
											</li><li>
											<a href="page/faq.html">
												<span class="menu-title">
													FAQ
												</span>
											</a>
											</li><li>
											<a href="page/pricing.html">
												<span class="menu-title">
													Pricing
												</span>
											</a>
											</li><li>
											<a href="page/blog.html">
												<span class="menu-title">
													Blog
												</span>
											</a>
											</li><li>
											<a href="page/contact-us.html">
												<span class="menu-title">
													Contact Us
												</span>
											</a>
											</li>						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>



<div class="banner-slider" style="background-image: url(assets/uploads/banner_forget_password.jpg)">
	<div class="bg"></div>
	<div class="bannder-table">
		<div class="banner-text">
			<h1>Forget Password</h1>
		</div>
	</div>
</div>

<div class="login-area bg-area">
	<div class="container">
		<div class="row">
						<div class="col-md-offset-3 col-md-5">
				<div class="login-form">
					<form action="#" method="post">
						<div class="form-row">
							<div class="form-group">
								<label for="">Email Address</label>
								<input autocomplete="off" type="email" class="form-control" placeholder="Enter Email Address" name="seller_email">
							</div>
							<button type="submit" class="btn btn-primary" name="form1">Submit</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

	
	<!--Newsletters Start-->
	<div class="newsletter-area">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="newsletter-headline">
						<h2>Newsletter</h2>
												<p>
							Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquid fugit expedita, iure ullam cum vero ex sint aperiam maxime.						</p>
											</div>
					<div class="newsletter-submit">
												<form action="#" method="post">
							<input type="text" placeholder="Enter Your Email" name="email_subscribe">
							<input type="submit" value="Submit" name="form_subscribe">
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--Newsletters End-->

	<!--Footer-Area Start-->
	<div class="footer-area">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-3">
					<div class="footer-item footer-service">
						<h2>Latest News</h2>
						<ul class="fmain">
															<li><a href="news/lorem-ipsum-dolor-sit-amet.html">Lorem ipsum dolor sit amet</a></li>
																<li><a href="news/an-labores-explicari-qui-eu.html">An labores explicari qui eu</a></li>
																<li><a href="news/nostrum-copiosae-argumentum-has.html">Nostrum copiosae argumentum has</a></li>
														</ul>
					</div>
				</div>
				<div class="col-md-3 col-sm-3">
					<div class="footer-item footer-service">
						<h2>Popular News</h2>
						<ul class="fmain">
															<li><a href="news/tollit-cetero-cu-usu-etiam-evertitur.html">Tollit cetero cu usu etiam evertitur</a></li>
																<li><a href="news/lorem-ipsum-dolor-sit-amet.html">Lorem ipsum dolor sit amet</a></li>
																<li><a href="news/cu-vel-choro-exerci-pri-et-oratio-iisque.html">Cu vel choro exerci pri et oratio iisque</a></li>
														</ul>
					</div>
				</div>
				<div class="col-md-3 col-sm-3">
					<div class="footer-item footer-service">
						<h2>Contact</h2>
						<ul>
							<li>Address: ABC Steet, NewYork.</li>
							<li>Email: info@yourwebsite.com</li>
							<li>Phone: 123-456-7878</li>
							<li>Fax: 123-456-7890</li>
						</ul>
					</div>
				</div>
				<div class="col-md-3 col-sm-3">
					<div class="footer-item footer-service">
						<h2>Social Media</h2>
						<div class="footer-social-link">
							<ul>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li><li><a href="#"><i class="fa fa-twitter"></i></a></li><li><a href="#"><i class="fa fa-linkedin"></i></a></li><li><a href="#"><i class="fa fa-google-plus"></i></a></li><li><a href="#"><i class="fa fa-pinterest"></i></a></li>							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="copyright">
					<p>Copyright © 2017. All Rights Reserved.</p>
				</div>
			</div>
		</div>
	</div>

	<!--Footer-Area End-->


	<!--Scroll-Top-->
	<div class="scroll-top">
		<div class="scroll"></div>
	</div>
	<!--Scroll-Top-->


	

	<!--Js-->
	<script src="js/jquery-2.2.4.min.js"></script>
	<script src="js/jquery-ui.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chosen.jquery.js"></script>
	<script src="js/docsupport/init.js"></script>
	<script src="js/lightbox.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.slicknav.min.js"></script>
	<script src="js/jquery.filterizr.min.js"></script>
	<script src="js/jquery.collapse.js"></script>
	<script src="js/custom.js"></script>

	<script>
		function confirmDelete()
		{
		    return confirm("Do you sure want to delete this data?");
		}

	</script>


	
</body>


<!-- Mirrored from demosly.com/xicia/carlisting/forget-password.php by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 09 Oct 2019 07:12:27 GMT -->
</html>