<?php
$category=$_GET['category'];
//echo $id;
include('../../genesis/config/conn.php');
?>
<div class="content-intro bg-white p-t-77 p-b-133">
			<div class="container">
				<div class="row">
					<div class="col-md-4 p-t-30">
						<!-- Block1 -->
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/category.php?category=SUV"><img src="pics/ford.jpeg" alt="IMG-INTRO"></a>
							</div>

							<div class="wrap-text-blo1 p-t-35">
								<a href="carlisting/page/category.php?category=SUV"><h4 class="txt5 color0-hov trans-0-4 m-b-13">
									SUV
								</h4></a>

								<p class="m-b-20">
									
								</p>

								
							</div>
						</div>
					</div>

					<div class="col-md-4 p-t-30">
						<!-- Block1 -->
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/category.php?category=MUV"><img src="pics/Innova.jpg" alt="IMG-INTRO"></a>
							</div>

							<div class="wrap-text-blo1 p-t-35">
								<a href="carlisting/page/category.php?category=MUV"><h4 class="txt5 color0-hov trans-0-4 m-b-13">
									MUV
								</h4></a>

								<p class="m-b-20">
									
								</p>

								
							</div>
						</div>
					</div>


<div class="col-md-4 p-t-30">
						<!-- Block1 -->
						<div class="blo1">
							<div class="wrap-pic-blo1 bo-rad-10 hov-img-zoom">
								<a href="carlisting/page/category.php?category=Sedan"><img src="pics/Ciaz.jpg" alt="IMG-INTRO"></a>
							</div>

							<div class="wrap-text-blo1 p-t-35">
								<a href="carlisting/page/category.php?category=Sedan"><h4 class="txt5 color0-hov trans-0-4 m-b-13">
									SEDAN
								</h4></a>

								<p class="m-b-20">
									
								</p>

								
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>