<?php
session_start();
if(isset($_SESSION['username']))
{
//echo $id;
include('../../genesis/config/conn.php');
?>
<!DOCTYPE html>
<html class="no-js" lang="en">



<!-- Mirrored from demosly.com/xicia/carlisting/page/new-car by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 09 Oct 2019 07:10:53 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<style type="text/css">
    .button {
    background-color: green;
  border: none;
  color: white;
  padding: 4px 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 18px;
}

</style>
	<!-- Meta Tags -->
	<meta name="viewport" content="width=device-width,initial-scale=1.0" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />

	<meta name="description" content=""><meta name="keywords" content=""><title>New Cars - CarListing Website</title>
	<!-- Favicon -->
	<link href="../assets/uploads/favicon.png" rel="shortcut icon" type="image/png">
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
	<!-- Stylesheets -->
	<link rel="stylesheet" href="../css/jquery-ui.css">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/lightbox.min.css">
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/normalize.css">
	<link rel="stylesheet" href="../css/slicknav.min.css">
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="../css/responsive.css">
	<link rel="stylesheet" href="../css/chosen.css">
	<link rel="stylesheet" href="../css/datatable.min.css">


	
	<script type="text/javascript" src="../../../../platform-api.sharethis.com/js/sharethis.js#property=5993ef01e2587a001253a261&product=inline-share-buttons"></script>

</head>

<body>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "../../../../../connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10&appId=323620764400430";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
	<!--Preloader Start-->
	<div id="preloader">
		<div id="status" style="background-image: url(../img/preloader/3.gif)"></div>
	</div>


	<!--Menu Start-->
	<div class="menu-area">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-12 col-xs-12">
					<div class="logo">
						<a href="../../uhome.php"><img src="../assets/uploads/logo (4).png" alt=""></a>

					</div>
				</div>

				<div class="col-md-8 col-sm-9">
					<div class="menu">

						<ul id="nav" class="main-menu">

							
												<li>

												<a href="../../uhome.php">
												<span class="menu-title">
													HOME
												</span>
												</a>
												</li>
												<li>
											<a href="usedcar.php">
												<span class="menu-title">
													USED CAR
												</span>
												</a>
												</li>
											
												<li>
											<a href="../../ucompare.php">
												<span class="menu-title">
													COMPARE
												</span>
												</a>
												</li>
													<li>
											<a href="../../feedback.php">
												<span class="menu-title">
													FEEDBACK
												</span>
												</a>
												</li>
													<li>
											<a href="../../uprofile.php">
												<span class="menu-title">
													PROFILE
												</span>
												</a>
												</li>

											<li>
											<a href="../../logout.php">
												<span class="menu-title">
													LOGOUT
												</span>
											</a>

											</li>

											
										</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	

<!--Banner Start-->
<!--div class="banner-slider" style="background-image: url(../assets/uploads/audi.jpg)">
	<div class="bg"></div>
	<div class="bannder-table">
		<div class="banner-text">
			<h1>Used Car</h1>
		</div>
	</div>
</div>

<!--Banner End-->


        <div class="col-sm-8 col-sm-12">
<div class="col-lg-12">
	<br>
	<br>
	<br>
	<br>

                        <div class="main-card mb-12 card">
                            <div class="card-body">
                            	<center><b>MY BOOKINGS</b></center>
                            	<br>
                            	<br>
                            	<br>
                                <table class="table" id="example1">
                                    <thead>
                                        <tr>
                                            
                                            <th>COMPANY</th>
                                            <th>MODEL</th>
                                            <th>YEAR</th>
                                            <th>PRICE</th>
                                            <th>USERNAME</th>
                                            <th>DATE</th>
                                            
                                        </tr>
                                    </thead>
                                    
                                    
<?php
$uid=$_SESSION['username'];
 $sel="SELECT * FROM `carbooking` where `username`='$uid'";          
$res=mysqli_query($con,$sel);
$rowcount=mysqli_num_rows($res);
if($rowcount==0)
{
	echo '<script language="javascript">';
	echo 'alert("No Bookings")';
	echo '</script>';
	echo "<script>window.location.href='usedcar.php'</script>";
}
else
{
while($row=mysqli_fetch_array($res,MYSQLI_ASSOC))
{
    $company=$row['company'];
    $model=$row['model'];
    $year=$row['year'];
    $price=$row['price'];
    $uid=$row['username'];
    $date=$row['date'];
    $i=$row['bill'];

   // echo"$b";


?>
<tr>
   
<td> 
   <?php 
echo $company;
    ?>
  </td>
  
<td>
<?php
echo $model;
?>
</td>

<td>
<?php
echo $year; 
?>
</td>

<td>
<?php
echo $price;
?>
</td>
<td>
<?php
echo $uid;
?>
</td>
<td>
<?php
echo $date;
?>
</td>

    <td><td><td>
<a href="<?php echo $i; ?>" class="button"> Download</a>
<a href="cancel.php?model=<?php echo $row['model'];?>" class="button"> Cancel Booking</a>

</tr>
<?php
}
   }

?>


                                </table>
                            </div>
                        </div>
                        

                    
                        
</div>
</div>
                </div>

<div class="clearfix"></div>


</div><!-- /#right-panel -->

						
							<!-- 					<div class="col-md-6 col-sm-12 listing-item-car-condition">
							<div class="row listing-item">
								<div class="col-md-4 col-sm-4 col-xs-12 listing-photo" style="background-image: url(../assets/uploads/cars/brezza.jpg)"></div>
								
								<div class="col-md-4 col-sm-4 col-xs-6 listing-text">
									<h2>Maruti Suzuki Vitara Brezza</h2>
									<ul>
										<li>Type: <span>SUV</span></li>
										<li>Mileage: <span>24.29</span></li>
										<li>Year: <span>2019</span></li>
									</ul>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6 listing-price">
									<h2>
																			Diesel																		</h2>
									<a href="../car/18.html">View Detail</a>
								</div>									
							</div>
						</div>
												<div class="col-md-6 col-sm-12 listing-item-car-condition">
							<div class="row listing-item">
								<div class="col-md-4 col-sm-4 col-xs-12 listing-photo" style="background-image: url(../assets/uploads/cars/hector.jpg)"></div>
								
								<div class="col-md-4 col-sm-4 col-xs-6 listing-text">
									<h2>MG Hector</h2>
									<ul>
										<li>Type: <span>SUV</span></li>
										<li>Mileage: <span>Not Specified</span></li>
										<li>Year: <span>2019</span></li>
									</ul>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6 listing-price">
									<h2>
																					Diesel																			</h2>
									<a href="../car/13.php">View Detail</a>
								</div>									
							</div>
						</div>
												<div class="col-md-6 col-sm-12 listing-item-car-condition">
							<div class="row listing-item">
								<div class="col-md-4 col-sm-4 col-xs-12 listing-photo" style="background-image: url(../assets/uploads/cars/harrier.jpg)"></div>
								
								<div class="col-md-4 col-sm-4 col-xs-6 listing-text">
									<h2>Tata Harrier</h2>
									<ul>
										<li>Type: <span>SUV</span></li>
										<li>Mileage: <span>Not Specified</span></li>
										<li>Year: <span>2019</span></li>
									</ul>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6 listing-price">
									<h2>
																					Diesel
																												</h2>
									<a href="../car/12.php">View Detail</a>
								</div>									
							</div>
						</div>
						<div class="col-md-6 col-sm-12 listing-item-car-condition">
							<div class="row listing-item">
								<div class="col-md-4 col-sm-4 col-xs-12 listing-photo" style="background-image: url(../assets/uploads/cars/seltos.jpg)"></div>
								
								<div class="col-md-4 col-sm-4 col-xs-6 listing-text">
									<h2>Kia Seltos</h2>
									<ul>
										<li>Type: <span>SUV</span></li>
										<li>Mileage: <span>20.1</span></li>
										<li>Year: <span>2019</span></li>
									</ul>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6 listing-price">
									<h2>
											Diesel																			</h2>
									<a href="../car/8.php">View Detail</a>
								</div>									
							</div>
						</div> -->
										
		</div>
	</div>
</div>




	



	<!--Scroll-Top-->
	<div class="scroll-top">
		<div class="scroll"></div>
	</div>
	<!--Scroll-Top-->


	

	<!--Js-->
	<script src="../js/jquery-2.2.4.min.js"></script>
	<script src="../js/jquery-ui.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/chosen.jquery.js"></script>
	<script src="../js/docsupport/init.js"></script>
	<script src="../js/lightbox.min.js"></script>
	<script src="../js/jquery.dataTables.min.js"></script>
	<script src="../js/owl.carousel.min.js"></script>
	<script src="../js/jquery.slicknav.min.js"></script>
	<script src="../js/jquery.filterizr.min.js"></script>
	<script src="../js/jquery.collapse.js"></script>
	<script src="../js/custom.js"></script>

	<script>
		function confirmDelete()
		{
		    return confirm("Do you sure want to delete this data?");
		}

	</script>

</body>

</html>
<?php
	}
	else
	{
	header("location:login.php");
	}
?>