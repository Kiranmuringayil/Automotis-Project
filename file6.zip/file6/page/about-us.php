<?php
include('../../genesis/config/conn.php');
?>
<!DOCTYPE html>
<html class="no-js" lang="en">


<!-- Mirrored from demosly.com/xicia/carlisting/page/about-us by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 09 Oct 2019 07:10:46 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<!-- Meta Tags -->
	<meta name="viewport" content="width=device-width,initial-scale=1.0" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />

	
	<!-- Favicon -->
	<link href="../assets/uploads/favicon.png" rel="shortcut icon" type="image/png">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="../css/jquery-ui.css">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/lightbox.min.css">
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/normalize.css">
	<link rel="stylesheet" href="../css/slicknav.min.css">
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="../css/responsive.css">
	<link rel="stylesheet" href="../css/chosen.css">
	<link rel="stylesheet" href="../css/datatable.min.css">


	
	<script type="text/javascript" src="../../../../platform-api.sharethis.com/js/sharethis.js#property=5993ef01e2587a001253a261&product=inline-share-buttons"></script>

</head>

<body>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "../../../../connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10&appId=323620764400430";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
	<!--Preloader Start-->
	
	<!--Preloader End-->

	<!--Top-Header Start-->
	

	<!--Menu Start-->
	<div class="menu-area">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-12 col-xs-12">
					<div class="logo">
						<a href="../../index.php"><img src="../assets/uploads/logo (4).png" alt=""></a>
					</div>
				</div>
				<div class="col-md-8 col-sm-9">
					<div class="menu">
						<ul id="nav" class="main-menu">
							
												<li>
												<a href="../../index.php">
												<span class="menu-title">
													HOME
												</span>
												</a>
												</li>
												
											<li>
											<a href="../../new-car.php">
												<span class="menu-title">
													CARS
												</span>
												</a>
												</li>
												<li>
											<a href="../../cmpr.php">
												<span class="menu-title">
													COMPARE 
												</span>
												</a>
												</li>
												<li>
											<a href="../../login.php">
												<span class="menu-title">
													USED CARS
												</span>
												</a>
												</li>
												<li>
											<a href="../../thumber/index.html">
												<span class="menu-title">
													GALLERY
												</span>
											</a>
											</li>
											
											<li>
											<a href="../../login.php">
												<span class="menu-title">
													LOGIN
												</span>
											</a>
											</li>
											
										</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	

<!--Banner Start-->
<div class="banner-slider" style="background-image: url(../assets/uploads/audi.jpg)">
	<div class="bg"></div>
	<div class="bannder-table">
		<div class="banner-text">
			<h1>About Us</h1>
		</div>
	</div>
</div>
<!--Banner End-->


<div class="about-area">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="about-text">
					<p>Automotis is a  complete automart website. Established since 2020. The system provide a car comparison system for getting a right choice. User needs to select two cars and the system will generate the features of two cars. The user can search for a particular car to view its features. The user can book used cars online. The system will adverise only truly valued used cars. This system helps the user to make best decision before buying.
					</p>
					<br>
					<br>
					<div class="col-sm-8 col-sm-12">
					<div class="col-lg-12">
                        <div class="main-card mb-12 card">
                            <div class="card-body">
                                <table class="table" id="example1">
                                    <thead><b>User Reviews</b><br><br>
                                       <tr>
                                            <th>User</th>
                                            <th>Feedback </th>
                                            <th>Date</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody>
                                        <?php
                                        
    $sel=mysqli_query($con,"select * from feedback_tb");
    if($sel->num_rows>0) {
        while ($row=$sel->fetch_assoc()) {
            //echo $row['test_name'];
            ?>
          
    <tr>
      <!--<th scope="row"><?php echo $row['feedback_id']; ?></th>-->
      <td><?php echo $row['loginid']; ?></td>
      <td><?php echo $row['feedback']; ?></td>
      <td><?php echo $row['date']; ?></td>

      <!--<td><a href="edtmodel.php?key=<?php echo $row['feedback_id'] ?>"><button title="View Details" class="fa fa-eye mb-1 mr-1 btn btn-outline-success"></button></a></td>-->
    </tr>
   <?php
   }
    }
    //echo "No Data Found";
    ?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        

                    
                        
</div>
</div>
				</div>
			</div>
		</div>
	</div>
</div>

	<!--Newsletters Start-->
	
	<!--Newsletters End-->

	<!--Footer-Area Start-->
	<div class="footer-area">
		<div class="container">
			<div class="row">
				<div class="col-md-3 col-sm-3">
					
				</div>
				
				<div class="col-md-3 col-sm-3">
					<div class="footer-item footer-service">
						<h2>Contact</h2>
						<ul>
							<li>automotis-compare.com</li>
							<li>Phone:(+91)9495762466</li>
						</ul>
					</div>
				</div>
				<div class="col-md-3 col-sm-3">
					<div class="footer-item footer-service">
						<h2>Social Media</h2>
						<div class="footer-social-link">
							<ul>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li><li><a href="#"><i class="fa fa-twitter"></i></a></li><li><a href="#"><i class="fa fa-linkedin"></i></a></li><li><a href="#"><i class="fa fa-google-plus"></i></a></li><li><a href="#"><i class="fa fa-pinterest"></i></a></li>							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="copyright">
					<p>Copyright © 2020. All Rights Reserved.</p>
				</div>
			</div>
		</div>
	</div>

	<!--Footer-Area End-->


	<!--Scroll-Top-->
	<div class="scroll-top">
		<div class="scroll"></div>
	</div>
	<!--Scroll-Top-->


	

	<!--Js-->
	<script src="../js/jquery-2.2.4.min.js"></script>
	<script src="../js/jquery-ui.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/chosen.jquery.js"></script>
	<script src="../js/docsupport/init.js"></script>
	<script src="../js/lightbox.min.js"></script>
	<script src="../js/jquery.dataTables.min.js"></script>
	<script src="../js/owl.carousel.min.js"></script>
	<script src="../js/jquery.slicknav.min.js"></script>
	<script src="../js/jquery.filterizr.min.js"></script>
	<script src="../js/jquery.collapse.js"></script>
	<script src="../js/custom.js"></script>

	<script>
		function confirmDelete()
		{
		    return confirm("Do you sure want to delete this data?");
		}

	</script>


	
</body>


<!-- Mirrored from demosly.com/xicia/carlisting/page/about-us by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 09 Oct 2019 07:10:53 GMT -->
</html>


