<?php
session_start();
if(isset($_SESSION['username']))
$id=$_GET['id'];
{
$db = mysqli_connect('localhost', 'root', '', 'automotis');

}
?>
<html>
<body>
<?php
// initializing variables

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'automotis');
if($db)
if (isset($_POST['submit']))
{
 // receive all input values from the form
        $id=mysqli_real_escape_string($db, $_POST['company']);
        $date=date('Y-m-d');
        $uid=$_SESSION['username'];
        $model=mysqli_real_escape_string($db, $_POST['model']);
        $year=mysqli_real_escape_string($db, $_POST['year']);
        $price=mysqli_real_escape_string($db, $_POST['price']);

        

  $query="INSERT INTO `carbooking`(`bookid`, `company`, `model`, `year`, `price`, `username`, `date`,`status`) VALUES (NULL,'$id','$model','$year','$price','$uid','$date','1')";

$res= mysqli_query($db, $query);
  
  if($res)
  {
    $sq= "UPDATE `used_car` SET `status`= '0' WHERE `model`='$model'";
    $sql=mysqli_query($db, $sq);
    if($sql)
    {
      echo '<script language="javascript">';
      echo 'alert("Booking successfull")';
      //header("location:http://localhost/kalappa/user/pay/pay.php");
      //$_SESSION['id']=$id;
      echo '</script>';
    }
    
  } 
}


?>  
</body>
</html>