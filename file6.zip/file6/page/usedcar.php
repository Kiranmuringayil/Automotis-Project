<?php
session_start();
if(isset($_SESSION['username']))
{
//echo $id;
include('../../genesis/config/conn.php');
?>
<!DOCTYPE html>
<html class="no-js" lang="en">



<!-- Mirrored from demosly.com/xicia/carlisting/page/new-car by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 09 Oct 2019 07:10:53 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<!-- Meta Tags -->
	<meta name="viewport" content="width=device-width,initial-scale=1.0" />
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" />

	<meta name="description" content=""><meta name="keywords" content=""><title>New Cars - CarListing Website</title>
	<!-- Favicon -->
	<link href="../assets/uploads/favicon.png" rel="shortcut icon" type="image/png">

	<!-- Stylesheets -->
	<link rel="stylesheet" href="../css/jquery-ui.css">
	<link rel="stylesheet" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/lightbox.min.css">
	<link rel="stylesheet" href="../css/owl.carousel.min.css">
	<link rel="stylesheet" href="../css/normalize.css">
	<link rel="stylesheet" href="../css/slicknav.min.css">
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="../css/responsive.css">
	<link rel="stylesheet" href="../css/chosen.css">
	<link rel="stylesheet" href="../css/datatable.min.css">


	
	<script type="text/javascript" src="../../../../platform-api.sharethis.com/js/sharethis.js#property=5993ef01e2587a001253a261&product=inline-share-buttons"></script>

</head>

<body>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "../../../../connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.10&appId=323620764400430";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
	<!--Preloader Start-->
	<div id="preloader">
		<div id="status" style="background-image: url(../img/preloader/3.gif)"></div>
	</div>


	<!--Menu Start-->
	<div class="menu-area">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-12 col-xs-12">
					<div class="logo">
						<a href="../../index.php"><img src="../assets/uploads/logo (4).png" alt=""></a>

					</div>
				</div>

				<div class="col-md-8 col-sm-9">
					<div class="menu">

						<ul id="nav" class="main-menu">

							
												<li>

												<a href="../../uhome.php">
												<span class="menu-title">
													HOME
												</span>
												</a>
												</li>
												
											
												<li>
											<a href="../../ucompare.php">
												<span class="menu-title">
													COMPARE
												</span>
												</a>
												</li>
													<li>
											<a href="../../feedback.php">
												<span class="menu-title">
													FEEDBACK
												</span>
												</a>
												</li>
													<li>
											<a href="../../uprofile.php">
												<span class="menu-title">
													PROFILE
												</span>
												</a>
												</li>
												<li>
											<a href="bill.php">
												<span class="menu-title">
													MY BOOKINGS
												</span>
												</a>
												</li>
												

											<li>
											<a href="../../logout.php">
												<span class="menu-title">
													LOGOUT
												</span>
											</a>

											</li>

											
										</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	

<!--Banner Start-->
<!--div class="banner-slider" style="background-image: url(../assets/uploads/audi.jpg)">
	<div class="bg"></div>
	<div class="bannder-table">
		<div class="banner-text">
			<h1>Used Car</h1>
		</div>
	</div>
</div>

<!--Banner End-->



<!--Featured Old Car Start-->
	
<div class="featured-area">

		<div class="container">
			<div class="row">
				<div class="headline">
					<h2><span>Search</span> Old Cars</h2>
				</div>
				<div class="featured-gallery owl-carousel">
				
				<?php
							$sel=mysqli_query($con,"SELECT * FROM used_car,fuel,company WHERE used_car.fuel=fuel.fuelid and used_car.compid=company.compid and used_car.status='1'");
					if ($sel->num_rows>0) {
						while ($row=$sel->fetch_assoc()) {
							?>
						<div class="featured-item"> 
							<div class="featured-car-name">
								<h2><?php echo $row['comp_name']." ".$row['model'];?></h2>
							</div>
							<div class="featured-photo" style="background-image: url(../<?php echo $row['image'];?>)"></div>
							<div class="featured-price">
								<h2>RS : <?php echo $row['price'];?> Lakhs</h2>
							</div>

							<div class="car-type">
								<ul>
									<li>Year: <span><?php echo $row['Year'];?></span></li>
									<li>KM: <span><?php echo $row['kmdriven'];?></span></li>
									<li>Fuel: <span><?php echo $row['fuel_type'];?></span></li>
								</ul>
							</div>
							<div class="featured-link">
								<a href="../car/ucardetails.php?id=<?php echo $row['ucar_id'];?>">View Details</a>
							</div>								
						</div>
						  
						<?php
					}
				}
						?>						
				
			</div>
		</div>
	</div>
</div>

<!--Featured Old Car Start-->
	<div class="featured-area">
		<div class="container">
			<div class="row">
				<div class="headline">
					<h2><span>Filter</span> Your search</h2>
				</div>
				<div class="featured-gallery owl-carousel">
					
						<div class="featured-item">
							<div class="featured-car-name">
								<h2>Maruti Suzuki</h2>
							</div>
							<div class="featured-photo"><a href="usedbrand.php?brand=Maruti Suzuki"><img src="../logo/maruti.png" alt="IMG-INTRO"></a> </div>
							
							
						</div>
						<div class="featured-item">
							<div class="featured-car-name">
								<h2> Hyundai</h2>
							</div>
							<div class="featured-photo"><a href="usedbrand.php?brand=Hyundai"><img src="../logo/hynd.png" alt="IMG-INTRO"></a> </div>

						
						</div>
							
						<div class="featured-item">
							<div class="featured-car-name">
								<h2>Tata Motors</h2>
							</div>
							<div class="featured-photo"><a href="usedbrand.php?brand=Tata Motors"><img src="../logo/Tata-Group-logo-3840x2160.png" alt="IMG-INTRO"></a> </div>
							
							
						</div>
						<div class="featured-item">
							<div class="featured-car-name">
								<h2>Honda</h2>
							</div>
							<div class="featured-photo"><a href="usedbrand.php?brand=Honda"><img src="../logo/honda1.jpg" alt="IMG-INTRO"></a> </div>
							
							
						</div>
							<div class="featured-item">
							<div class="featured-car-name">
								<h2>Toyota</h2>
							</div>
							<div class="featured-photo"><a href="usedbrand.php?brand=Toyota"><img src="../logo/toyot.jpg" alt="IMG-INTRO"></a> </div>
							
							
						</div>
						<div class="featured-item">
							<div class="featured-car-name">
								<h2> Ford</h2>
							</div>
							<div class="featured-photo"><a href="usedbrand.php?brand=Ford"><img src="../logo/ford.jfif" alt="IMG-INTRO"></a> </div>
						</div>
						<div class="featured-item">
							<div class="featured-car-name">
								<h2>Mahindra</h2>
							</div>
							<div class="featured-photo"><a href="usedbrand.php?brand=Mahindra"><img src="../logo/Mahindra-logo.png" alt="IMG-INTRO"></a> </div>

							
						</div>
						
							
						
																	
				</div>
			</div>
		</div>
	</div>




<!--Featured Old Car Start-->
	

						
							<!-- 					<div class="col-md-6 col-sm-12 listing-item-car-condition">
							<div class="row listing-item">
								<div class="col-md-4 col-sm-4 col-xs-12 listing-photo" style="background-image: url(../assets/uploads/cars/brezza.jpg)"></div>
								
								<div class="col-md-4 col-sm-4 col-xs-6 listing-text">
									<h2>Maruti Suzuki Vitara Brezza</h2>
									<ul>
										<li>Type: <span>SUV</span></li>
										<li>Mileage: <span>24.29</span></li>
										<li>Year: <span>2019</span></li>
									</ul>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6 listing-price">
									<h2>
																			Diesel																		</h2>
									<a href="../car/18.html">View Detail</a>
								</div>									
							</div>
						</div>
												<div class="col-md-6 col-sm-12 listing-item-car-condition">
							<div class="row listing-item">
								<div class="col-md-4 col-sm-4 col-xs-12 listing-photo" style="background-image: url(../assets/uploads/cars/hector.jpg)"></div>
								
								<div class="col-md-4 col-sm-4 col-xs-6 listing-text">
									<h2>MG Hector</h2>
									<ul>
										<li>Type: <span>SUV</span></li>
										<li>Mileage: <span>Not Specified</span></li>
										<li>Year: <span>2019</span></li>
									</ul>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6 listing-price">
									<h2>
																					Diesel																			</h2>
									<a href="../car/13.php">View Detail</a>
								</div>									
							</div>
						</div>
												<div class="col-md-6 col-sm-12 listing-item-car-condition">
							<div class="row listing-item">
								<div class="col-md-4 col-sm-4 col-xs-12 listing-photo" style="background-image: url(../assets/uploads/cars/harrier.jpg)"></div>
								
								<div class="col-md-4 col-sm-4 col-xs-6 listing-text">
									<h2>Tata Harrier</h2>
									<ul>
										<li>Type: <span>SUV</span></li>
										<li>Mileage: <span>Not Specified</span></li>
										<li>Year: <span>2019</span></li>
									</ul>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6 listing-price">
									<h2>
																					Diesel
																												</h2>
									<a href="../car/12.php">View Detail</a>
								</div>									
							</div>
						</div>
						<div class="col-md-6 col-sm-12 listing-item-car-condition">
							<div class="row listing-item">
								<div class="col-md-4 col-sm-4 col-xs-12 listing-photo" style="background-image: url(../assets/uploads/cars/seltos.jpg)"></div>
								
								<div class="col-md-4 col-sm-4 col-xs-6 listing-text">
									<h2>Kia Seltos</h2>
									<ul>
										<li>Type: <span>SUV</span></li>
										<li>Mileage: <span>20.1</span></li>
										<li>Year: <span>2019</span></li>
									</ul>
								</div>
								<div class="col-md-4 col-sm-4 col-xs-6 listing-price">
									<h2>
											Diesel																			</h2>
									<a href="../car/8.php">View Detail</a>
								</div>									
							</div>
						</div> -->
										
		</div>
	</div>
</div>




	



	<!--Scroll-Top-->
	<div class="scroll-top">
		<div class="scroll"></div>
	</div>
	<!--Scroll-Top-->


	

	<!--Js-->
	<script src="../js/jquery-2.2.4.min.js"></script>
	<script src="../js/jquery-ui.js"></script>
	<script src="../js/bootstrap.min.js"></script>
	<script src="../js/chosen.jquery.js"></script>
	<script src="../js/docsupport/init.js"></script>
	<script src="../js/lightbox.min.js"></script>
	<script src="../js/jquery.dataTables.min.js"></script>
	<script src="../js/owl.carousel.min.js"></script>
	<script src="../js/jquery.slicknav.min.js"></script>
	<script src="../js/jquery.filterizr.min.js"></script>
	<script src="../js/jquery.collapse.js"></script>
	<script src="../js/custom.js"></script>

	<script>
		function confirmDelete()
		{
		    return confirm("Do you sure want to delete this data?");
		}

	</script>

</body>

</html>
<?php
	}
	else
	{
	header("location:login.php");
	}
?>