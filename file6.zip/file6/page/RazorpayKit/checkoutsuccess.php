<?php
include("C:/xampp/htdocs/car comp/co.php");
session_start();
if(isset($_SESSION['username']))
{
$uid=$_SESSION['username'];

//echo $id;


// eee codilanu payment gatewayde motham sambavom

require_once($_SERVER['DOCUMENT_ROOT']."/car comp/carlisting/page/RazorpayKit/RazorpayKit/razorpay-php/config.php");// ee config fiiliu ningalude secret keyum api keeyum set cheyyuka


include($_SERVER['DOCUMENT_ROOT']."/car comp/carlisting/page/RazorpayKit/RazorpayKit/razorpay-php/Razorpay.php");//ivide path set cheyyuka

$paymentid=$_POST['razorpay_payment_id'];//ithum ajax vazhi varunnatanu

use Razorpay\Api\Api;
$api = new Api('rzp_test_XgYjoI4qQZ5sZU', 'h6y1T2ot3ahlu553HcxNDr4B'); //enter your test key credentials here
$payment = $api->payment->fetch($paymentid); //post variable in index.php checkout.js
$text =  json_encode($payment->toArray());
$contact_number =  $payment->contact;
$contact_email  = $payment->email;
$currency       = $payment->currency;
$totalAmount    = $_POST["totalAmount"];
$ucar_id = $_POST["carId"];
$payment_method = $payment->method;
$razor_payment_id = $payment->id;
$created_date     = date('Y-m-d',$payment->created_at);

  //$i=1;
  //$id = $i;
echo"$ucar_id";

  //enter your database code here
 
if($razor_payment_id)
{
	$s=mysqli_query($con,"select * from used_car where ucar_id='$ucar_id'");
  	$r=mysqli_fetch_array($s,MYSQLI_ASSOC);
  	$
	$d=$r['model'];
  	$i=$r['year'];
  	$j=$r['price'];

  	$se=mysqli_query($con,"SELECT `loginid`, `username` FROM `login_tb` WHERE `loginid`='$uid'");
  	$re=mysqli_fetch_array($se,MYSQLI_ASSOC);
  	
  	$e=$re['username'];
  	$date=date('Y-m-d');
    
    $sql="INSERT INTO `carbooking`( `bookid`, `company`, `model`, `year`, `price`, `username`, `date`,`status`) VALUES (NULL,'$ucar_id','$d','$i','$j','$e','$date','1')";
    	if(mysqli_query($con,$sql))
    	{
    		$p="UPDATE `used_car` SET `status`=0 WHERE `ucar_id`='$ucar_id'";
    		$pquery=mysqli_query($con,$p);

           if($pquery)
           {
           }
      }
    }
    else
    {
      echo "error";
    }
?>