<?php

// eee codilanu payment gatewayde motham sambavom
require_once($_SERVER['DOCUMENT_ROOT']."/car comp/carlisting/page/TCPDF-master/TCPDF-master/tcpdf_import.php");

require_once($_SERVER['DOCUMENT_ROOT']."/car comp/carlisting/page/RazorpayKit/RazorpayKit/razorpay-php/config.php");// ee config fiiliu ningalude secret keyum api keeyum set cheyyuka
session_start();
if(isset($_SESSION['username']))
{
	$db = mysqli_connect('localhost', 'root', '', 'automotis');
}
include($_SERVER['DOCUMENT_ROOT']."/car comp/carlisting/page/RazorpayKit/RazorpayKit/razorpay-php/Razorpay.php");//ivide path set cheyyuka

$paymentid=$_POST['razorpay_payment_id'];//ithum ajax vazhi varunnatanu

use Razorpay\Api\Api;
$api = new Api('rzp_test_XgYjoI4qQZ5sZU', 'h6y1T2ot3ahlu553HcxNDr4B'); //enter your test key credentials here
$payment = $api->payment->fetch($paymentid); //post variable in index.php checkout.js
$text =  json_encode($payment->toArray());
$contact_number =  $payment->contact;
$contact_email  = $payment->email;
$currency       = $payment->currency;
$totalAmount    = $_POST["totalAmount"];
$id = $_POST["id"];
$company = $_POST["company"];
$model = $_POST["model"];
$year = $_POST["year"];
$price = $_POST["price"];
$date=date('Y-m-d');
$uid=$_SESSION['username'];
$payment_method = $payment->method;
$razor_payment_id = $payment->id;
$created_date     = date('Y-m-d',$payment->created_at);

if($razor_payment_id)
{
     //invoice 
  $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
  // set document information
  $pdf->SetCreator('');
  $pdf->SetAuthor('AUTOMOTIS');
  $pdf->SetTitle('BookingInvoice');
  $pdf->SetSubject("User");
  $pdf->SetKeywords('TCPDF, PDF, example, test, guide');
  
  // set default monospaced font
  $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
  // set margins
  $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
  $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
  $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
  // set auto page breaks
  $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
  // set image scale factor
  $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
  // set font
  $pdf->SetFont('helvetica', '', 10);
  // add a page
  $pdf->AddPage();
  // set style for barcode
  $style = array(
    'border' => 2,
    'vpadding' => 'auto',
    'hpadding' => 'auto',
    'fgcolor' => array(0,0,0),
    'bgcolor' => false, //array(255,255,255)
    'module_width' => 1, // width of a single module in points
    'module_height' => 1 // height of a single module in points
  );


  $abc='<BR><BR><BR><table border="1" cellpadding="2" cellspacing="2" nobr="true">
  <tr>
   <th colspan="4" align="center">AUTOMOTIS USED CAR BOOKING</th>
  </tr>
   <tr><td>Booking Date</td><td>Model</td><td>Username</td><td>Booking Amount</td>
  </tr>';
  $i=1;
  //$ddate = date('Y-m-d H:i:s', strtotime($date . ' +1 day'));
  $abc=$abc.'<tr><td>'.$date.'</td><td>'.$model.'</td><td>'.$uid.'</td><td>Rs '.$totalAmount.'</td></tr>';
  $abc=$abc.'<tr><td colspan="2">Total Amount</td><td colspan="2">Rs '.$totalAmount.'</td></tr></table>';
$pdf->writeHTML($abc, true, false, true, false, '');
$filename=$_SERVER['DOCUMENT_ROOT']."/car comp/carlisting/page/Bill/".$id.$razor_payment_id.".pdf";
$relname=$id.$razor_payment_id.".pdf";
$file="/car comp/carlisting/page/Bill/".$id.$razor_payment_id.".pdf";
$pdf->Output($filename, 'F');

if(file_exists($filename))
{
  //$i=1;
  //$id = $i;


  //enter your database code here
 $query="INSERT INTO `carbooking`(`bookid`,`ucar_id`, `company`, `model`, `year`, `price`, `username`, `date`,`bill`,`status`) VALUES (NULL,'$id','$company','$model','$year','$price','$uid','$date','$file','1')";

$res= mysqli_query($db, $query);
  
  if($res)
  {
    $sq= "UPDATE `used_car` SET `status`= NULL WHERE `ucar_id`='$id'";
    $sql=mysqli_query($db, $sq);
}
}
}
{
  echo $razor_payment_id;
}
?>