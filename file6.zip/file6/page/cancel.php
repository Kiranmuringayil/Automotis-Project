<?php
include('../../genesis/config/conn.php');
//$model=$_GET['model'];
$model = $_GET['model'];

$sq="DELETE FROM `carbooking` WHERE `model`='$model'";
if(mysqli_query($con,$sq))
    {
    	
    	$p="UPDATE `used_car` SET `status`=1 WHERE `model`='$model'";
    	$pquery=mysqli_query($con,$p);
    	
        if($pquery)
        {

    echo '<script language="javascript">';
    echo 'alert("Booking Cancelled")';
    echo '</script>';
    echo "<script>window.location.href='bill.php'</script>";
	}
}

?>
