<?php
session_start();
if(isset($_SESSION['username']))
{
include('../../genesis/config/conn.php');
//$id = $_GET['id'];

 	$s=mysqli_query($con,"select * from carbooking where bookid='$id'");
    $r=mysqli_fetch_array($s,MYSQLI_ASSOC);
    
  
  
$d=$r['model'];
	$del = "DELETE FROM `carbooking` WHERE  `model`='$id'";
    $res=mysqli_query($con,$del);
    if($res)
    {
     
     //$result=mysqli_query($con,"SELECT * FROM `used_car` WHERE `ucar_id`='$ucar_id'");
   			//$r=mysqli_fetch_array($result);
  		   $ucar_id = $_POST["carId"];
          $q="UPDATE `used_car` SET `status`=1 WHERE `model`='$id'";
          $query=mysqli_query($con,$q);
          if($query)
              {

echo '<script language="javascript">';
    echo 'alert("Booking Cancelled")';
    echo '</script>';
    echo "<script>window.location.href='bill.php'</script>";
  }
}
}
?>