<?php
session_start();
if(isset($_SESSION['username']))

{
?>



<?php
include ("../../co.php");

$uc=$_POST['ucar_id'];

$se="select * from used_car where ucar_id='$uc'";
$re=mysqli_query($con,$se);
$rowcount=mysqli_num_rows($re);
$s="select * from register_tb where userid='$id'";
$res=mysqli_query($con,$s);

?>

<!doctype html>

 <html class="no-js" lang="">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <meta name="description" content="Ela Admin - HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
    <link rel="shortcut icon" href="https://i.imgur.com/QRAUqs9.png">

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
    <link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="assets/css/style.css">

    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

   

</head>
<body>
      
        <div class="breadcrumbs">
            <div class="breadcrumbs-inner">
                <div class="row m-0">
                    <div class="col-sm-4">
                       
                    </div>
                   

        <div class="content">
            <div class="animated fadeIn">

                    </div>
                   

                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header"><strong>Booking</strong></div>
                            <?php
                    while($row1=mysqli_fetch_array($re))
                    {
                        while($row=mysqli_fetch_array($res))
                    {
                     
                     ?>
                    <form action="bikebooking.php" method="POST">
                        <input type="hidden" name="bikeid" value="<?php echo $b ; ?>">
                            <div class="card-body card-block">
                                <div class="form-group"><label for="company" class=" form-control-label">Booking Date</label><input type="date" id="date" placeholder="" class="form-control" name="date" ></div>
                                <div class="form-group"><label for="company" class=" form-control-label">Customer Name</label><input type="text" name="name" id="name" placeholder="" class="form-control" readonly="" value="<?php
                                    echo $row['name'];
                                    ?>" ></div>
                                <div class="form-group"><label for="vat" class=" form-control-label">Address</label><input type="text" id="add" name="add" placeholder="" readonly=""class="form-control" value="<?php
                                    echo $row['address'];
                                    ?>"> </div>
                                <div class="form-group"><label for="street" class=" form-control-label">Contact number</label><input type="text" id="num" name="num" placeholder="" readonly="" class="form-control" value="<?php
                                    echo $row['phone'];
                                    ?>"></div>
                                <div class="row form-group">
                                    <div class="col-8">
                                        <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                       
                                        <select id="branch" name="branch" placeholder="select branch" style="width: 200px;height: 35px">
                                          <option value="">--- SELECT BRANCH ----</option>
                                      <?php
                                      $q="SELECT * FROM `tbl_ branches`";
                                      $result=mysqli_query($con,$q);
                                      if($result->num_rows > 0)
                                      {


                                         while($row= $result->fetch_assoc())
                                 
                                       {
                                       ?>
                                        <option value="<?php echo $row['place']?>"><?php echo $row['place']?><?php
                                    }

                                      }


                                 
                                       ?>
                                        </select>
                                        <div class="select-dropdown" ></div>
                                    </div>
                                </div>
                            </div>
                                    </div>
                                </div>
                                    <div class="row form-group">
                                     <div class="col-8">
                                        <div class="form-group"><label for="city" class=" form-control-label">Bikename</label><input type="text" id="bname" name="bname" placeholder="" readonly="" class="form-control" value="<?php
                                    echo $row1['bname'];
                                    ?>"> </div>
                                    </div>
                               
                                   <div class="col-8">
                                        <div class="value">
                                <div class="input-group">
                                    <div class="rs-select2 js-select-simple select--no-search">
                                       
                                        <select id="branch" name="color" placeholder="select colour" style="width: 200px;height: 35px">
                                          <option value="">--- SELECT COLOUR ----</option>
                                      <?php
                                      $q="SELECT * FROM `tbl_color`";
                                      $result=mysqli_query($con,$q);
                                      if($result->num_rows > 0)
                                      {
                                        while($row= $result->fetch_assoc())
                                 
                                       {
                                       ?>
                                        <option value="<?php echo $row['color_name']?>"><?php echo $row['color_name']?><?php
                                    }

                                      }
                                       ?>
                                        </select>
                                        <div class="select-dropdown" ></div>
                                    </div>
                                </div>
                            </div>
                                    </div>
                                </div>

                               
                             
                           <!-- <div class="col-8">
                                        <div class="form-group"><label for="postal-code" class=" form-control-label">Colour</label><input type="text" id="color" name="color" placeholder="" class="form-control"></div>
                                    </div>
                                </div>-->
                            <div class="row form-group">
                                        <div class="col col-md-3"><label class=" form-control-label">ABS</label></div>
                                        <div class="col col-md-9">
                                            <div class="form-check-inline form-check">
                                                <label for="inline-checkbox1" class="form-check-label ">
                                                    <input type="checkbox" id="inline-checkbox1" name="yes" value="yes" class="form-check-input">Yes
                                                </label>
                                                <label for="inline-checkbox2" class="form-check-label ">
                                                    <input type="checkbox" id="inline-checkbox2" name="yes" value="no" class="form-check-input">NO
                                                </label>
                                               
                                            </div>
                                        </div>
                                   
                              <button type="submit" name="submit" class="btn btn-success btn-sm">Submit</button>
                                   
                               
                        </div>
                        <?php
                    }
                }
                    ?>
                    </div>
                 



        </div><!-- .animated -->
    </div><!-- .content -->

    <div class="clearfix"></div>

   <!-- <footer class="site-footer">
        <div class="footer-inner bg-white">
            <div class="row">
                <div class="col-sm-6">
                 &copy;
                </div>
                <div class="col-sm-6 text-right">
                     <a href="https://colorlib.com"></a>
                </div>
            </div>
        </div>
    </footer>-->

</div>
<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
<script src="assets/js/main.js"></script>


</body>
</html>
<?php
include 'co.php';
if(isset($_POST['submit']))
{
  $a=$_POST['date'];
  $e=$_POST['branch'];
  $c=$_POST['color'];
  $d=$_POST['yes'];
  $bikeid=$_POST['bikeid'];
  //$name=$_POST['bname'];


 
// $sql="INSERT INTO `tbl_booking`(`bkdate`, `bikeid`, `userid`, `branch`, `color`, `abs`, `status`) VALUES
//           ('$a','1','$id',$e','$c','$d',1)";

$sql="INSERT INTO `tbl_booking` (`bookid`, `bkdate`, `bikeid`, `userid`, `branch`, `color`, `abs`, `status`) VALUES (NULL, '$a', '$bikeid', '$id', '$e', '$c', '$d', '1');";
 $ch=mysqli_query($con,$sql);
if($ch)
{?>
<script>

 alert("Added Successfully");
  window.location='userpanel.php';
 
</script>
    <?php
}
else
{
  echo"error:".$sql."<br>".mysqli_error($con);

}
}
}
else
//header("location:../signinn.php");
?>

