<!DOCTYPE html>
<html>
<head>
	<title>Cashfree - PG Response Details</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	<h1 align="center">Thankyou</h1>	

	<?php  
		 $secretkey = "9f54679e2d5e725fb3f4e445e27547808ead5cc9";
		 $orderId = $_POST["orderId"];
		 $orderAmount = $_POST["orderAmount"];
		 $referenceId = $_POST["referenceId"];
		 $txStatus = $_POST["txStatus"];
		 $paymentMode = $_POST["paymentMode"];
		 $txMsg = $_POST["txMsg"];
		 $txTime = $_POST["txTime"];
		 $signature = $_POST["signature"];
		 $data = $orderId.$orderAmount.$referenceId.$txStatus.$paymentMode.$txMsg.$txTime;
		 $hash_hmac = hash_hmac('sha256', $data, $secretkey, true) ;
		 $computedSignature = base64_encode($hash_hmac);
		 
		
		//  if ($signature == $computedSignature) {
	 ?>
	<div class="container"> 
	<div class="panel panel-success">
	  <div class="panel-heading"><?php echo $txMsg; ?></div>
	  <div class="panel-body">
	  	<!-- <div class="container"> -->
	 		<table class="table table-hover">
			    <tbody>
			      <tr>
			        <td>Order ID</td>
			        <td><?php echo $orderId; ?></td>
			      </tr>
			      <tr>
			        <td>Order Amount</td>
			        <td><?php echo $orderAmount; ?></td>
			      </tr>
			      <tr>
			        <td>Reference ID</td>
			        <td><?php echo $referenceId; ?></td>
			      </tr>
			      <tr>
			        <td>Transaction Status</td>
			        <td><?php echo $txStatus; ?></td>
			      </tr>
			      <tr>
			        <td>Payment Mode </td>
			        <td><?php echo $paymentMode; ?></td>
			      </tr>
			      <tr>
			        <td>Message</td>
			        <td><?php echo $txMsg; ?></td>
			      </tr>
			      <tr>
			        <td>Transaction Time</td>
			        <td><?php echo $txTime; ?></td>
			      </tr>
				  <tr>
			        <td></td>
			        <td>
					<button class="btn btn-success btn-sm" onclick="bck();">Back</button>
		<button class="btn btn-success btn-sm" onclick="printReceipt();">Print Receipt</button>


					</td>
			      </tr>

			    </tbody>
			</table>
			<?php
ob_start();
session_start();
include '../admin1/viewClass.php';
$obj = new viewClass();

	$res=$obj->getLastBooking();
	$booking_details = mysqli_fetch_array($res, MYSQLI_ASSOC);
    $exp=explode("_",$orderId);
	$obj->car_id=$exp[0];
	$obj->customer_id=$exp[1];
	$obj->booking_id=$booking_details['id'];
    $obj->amount=$orderAmount;
    $obj->date=date('Y-m-d');
    $obj->txStatus=$txStatus;
    $obj->paymentMode=$paymentMode;
    $res=$obj->savePayment();
    
	if($res){
		if($txStatus=='SUCCESS'){
			echo "<script> alert('Payment Success..!!');
  			</script>";
		}else{
			echo "<script> alert('Payment Failed..Please try again..!!');
  			</script>";
		}
        
    }
	?>
		<!-- </div> -->

	   </div>
	</div>
	</div>
	<script>
	function printReceipt(){
		window.print();
	}
	function bck() {
		window.location.href="index.php";
	}
	</script>

</body>
</html>



